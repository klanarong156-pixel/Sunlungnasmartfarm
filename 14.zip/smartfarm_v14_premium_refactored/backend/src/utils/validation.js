/**
 * SmartFarm V14 Premium - Validation Utilities
 * IMPROVED: Added express-validator schemas for all routes
 */

'use strict';

const { body, param, query, validationResult } = require('express-validator');

/**
 * Middleware to check validation results
 */
const validate = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array().map(err => ({
        field: err.path,
        message: err.msg,
        value: err.value
      }))
    });
  }
  next();
};

/**
 * Sensor validation schemas
 */
const sensorValidation = {
  create: [
    body('device_id').trim().notEmpty().isLength({ max: 50 }),
    body('sensor_type').isIn(['temperature', 'humidity', 'soil_moisture', 'light', 'rain']),
    body('name').trim().notEmpty().isLength({ max: 100 }),
    body('unit').optional().trim().isLength({ max: 20 }),
    body('min_value').optional().isFloat(),
    body('max_value').optional().isFloat(),
    body('calibration_offset').optional().isFloat()
  ],
  update: [
    param('id').isInt({ min: 1 }),
    body('name').optional().trim().notEmpty().isLength({ max: 100 }),
    body('unit').optional().trim().isLength({ max: 20 }),
    body('min_value').optional().isFloat(),
    body('max_value').optional().isFloat(),
    body('calibration_offset').optional().isFloat(),
    body('is_active').optional().isBoolean()
  ],
  history: [
    param('id').isInt({ min: 1 }),
    query('days').optional().isInt({ min: 1, max: 365 }),
    query('limit').optional().isInt({ min: 1, max: 1000 })
  ]
};

/**
 * Pump validation schemas
 */
const pumpValidation = {
  create: [
    body('device_id').trim().notEmpty().isLength({ max: 50 }),
    body('name').trim().notEmpty().isLength({ max: 100 }),
    body('relay_pin').optional().isInt({ min: 0, max: 40 })
  ],
  start: [
    param('id').isInt({ min: 1 }),
    body('duration').optional().isInt({ min: 1, max: 86400 }).withMessage('Duration must be 1-86400 seconds')
  ],
  stop: [
    param('id').isInt({ min: 1 })
  ]
};

/**
 * Schedule validation schemas
 */
const scheduleValidation = {
  create: [
    body('pump_id').isInt({ min: 1 }),
    body('name').trim().notEmpty().isLength({ max: 100 }),
    body('cron_expression').trim().notEmpty().matches(/^(\*|[0-9,\-\/]+)\s+(\*|[0-9,\-\/]+)\s+(\*|[0-9,\-\/]+)\s+(\*|[0-9,\-\/]+)\s+(\*|[0-9,\-\/]+)$/)
      .withMessage('Invalid cron expression'),
    body('duration_seconds').isInt({ min: 1, max: 86400 }),
    body('is_active').optional().isBoolean()
  ],
  update: [
    param('id').isInt({ min: 1 }),
    body('name').optional().trim().notEmpty().isLength({ max: 100 }),
    body('cron_expression').optional().trim().notEmpty(),
    body('duration_seconds').optional().isInt({ min: 1, max: 86400 }),
    body('is_active').optional().isBoolean()
  ]
};

/**
 * Device validation schemas
 */
const deviceValidation = {
  create: [
    body('id').trim().notEmpty().isLength({ max: 50 }).matches(/^[a-zA-Z0-9_-]+$/),
    body('name').trim().notEmpty().isLength({ max: 100 }),
    body('location').optional().trim().isLength({ max: 200 }),
    body('firmware_version').optional().trim().isLength({ max: 20 })
  ],
  update: [
    param('id').trim().notEmpty(),
    body('name').optional().trim().notEmpty().isLength({ max: 100 }),
    body('location').optional().trim().isLength({ max: 200 }),
    body('is_active').optional().isBoolean()
  ]
};

/**
 * User validation schemas (admin)
 */
const userValidation = {
  create: [
    body('username').trim().notEmpty().isLength({ min: 3, max: 50 })
      .matches(/^[a-zA-Z0-9_]+$/),
    body('email').optional().isEmail().normalizeEmail(),
    body('password').isLength({ min: 8, max: 128 })
      .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/),
    body('role').isIn(['admin', 'operator', 'viewer']),
    body('full_name').optional().trim().isLength({ max: 100 })
  ],
  update: [
    param('id').isInt({ min: 1 }),
    body('email').optional().isEmail().normalizeEmail(),
    body('role').optional().isIn(['admin', 'operator', 'viewer']),
    body('full_name').optional().trim().isLength({ max: 100 }),
    body('is_active').optional().isBoolean()
  ]
};

/**
 * Settings validation
 */
const settingsValidation = {
  update: [
    body('key').trim().notEmpty().isLength({ max: 100 }),
    body('value').notEmpty()
  ]
};

/**
 * Pagination validation
 */
const paginationValidation = [
  query('limit').optional().isInt({ min: 1, max: 1000 }).toInt(),
  query('offset').optional().isInt({ min: 0 }).toInt(),
  query('page').optional().isInt({ min: 1 }).toInt()
];

/**
 * ID parameter validation
 */
const idValidation = [
  param('id').isInt({ min: 1 }).withMessage('ID must be a positive integer')
];

module.exports = {
  validate,
  sensorValidation,
  pumpValidation,
  scheduleValidation,
  deviceValidation,
  userValidation,
  settingsValidation,
  paginationValidation,
  idValidation
};
