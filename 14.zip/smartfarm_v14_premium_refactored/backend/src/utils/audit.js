/**
 * Audit Logger Utility
 * Records security and administrative actions in the database
 */

const Logger = require('./logger');
const logger = new Logger('Audit');

class AuditLogger {
  constructor(db) {
    this.db = db;
  }

  /**
   * Log an administrative or security action
   * @param {Object} params - Audit log parameters
   * @param {number} params.userId - ID of the user performing the action
   * @param {string} params.action - Action performed (e.g., 'CREATE_USER', 'DELETE_DEVICE')
   * @param {string} params.resourceType - Type of resource (e.g., 'user', 'device', 'sensor')
   * @param {string} params.resourceId - ID of the resource affected
   * @param {Object} params.changes - Details of changes made (optional)
   * @param {string} params.ipAddress - IP address of the user
   * @param {string} params.userAgent - User agent string
   * @param {string} params.status - Status of the action ('success', 'failure')
   */
  async log({
    userId,
    action,
    resourceType,
    resourceId,
    changes,
    ipAddress,
    userAgent,
    status = 'success'
  }) {
    try {
      const query = `
        INSERT INTO audit_logs (
          user_id, action, resource_type, resource_id, 
          changes, ip_address, user_agent, status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `;

      const changesStr = changes ? JSON.stringify(changes) : null;

      await this.db.run(query, [
        userId,
        action,
        resourceType,
        resourceId,
        changesStr,
        ipAddress,
        userAgent,
        status
      ]);

      logger.info('Audit log recorded', { userId, action, resourceType, status });
    } catch (error) {
      logger.error('Failed to record audit log', { error: error.message });
      // Don't throw error to prevent breaking the main flow
    }
  }

  /**
   * Get audit logs with filtering
   */
  async getLogs(filters = {}) {
    try {
      let query = `
        SELECT a.*, u.username 
        FROM audit_logs a
        LEFT JOIN users u ON a.user_id = u.id
        WHERE 1=1
      `;
      const params = [];

      if (filters.userId) {
        query += ' AND a.user_id = ?';
        params.push(filters.userId);
      }

      if (filters.action) {
        query += ' AND a.action = ?';
        params.push(filters.action);
      }

      if (filters.resourceType) {
        query += ' AND a.resource_type = ?';
        params.push(filters.resourceType);
      }

      query += ' ORDER BY a.created_at DESC LIMIT ? OFFSET ?';
      params.push(filters.limit || 100);
      params.push(filters.offset || 0);

      return await this.db.all(query, params);
    } catch (error) {
      logger.error('Failed to fetch audit logs', { error: error.message });
      throw error;
    }
  }
}

module.exports = AuditLogger;
