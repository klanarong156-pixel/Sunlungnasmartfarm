/**
 * Structured Logger Module
 * Provides ISO8601 formatted logging with levels and metadata
 */

const fs = require('fs');
const path = require('path');

class Logger {
  constructor(component, logDir = './logs') {
    this.component = component;
    this.logDir = logDir;
    this.logLevel = process.env.LOG_LEVEL || 'info';
    this.levels = { debug: 0, info: 1, warn: 2, error: 3 };
    
    // Create log directory if it doesn't exist
    if (!fs.existsSync(logDir)) {
      fs.mkdirSync(logDir, { recursive: true });
    }
  }

  /**
   * Format log message with ISO8601 timestamp
   */
  formatLog(level, message, metadata = {}) {
    const timestamp = new Date().toISOString();
    return {
      timestamp,
      level,
      component: this.component,
      message,
      metadata
    };
  }

  /**
   * Write log to file
   */
  writeToFile(logEntry) {
    const date = new Date().toISOString().split('T')[0];
    const logFile = path.join(this.logDir, `${date}.log`);
    const logLine = JSON.stringify(logEntry) + '\n';
    
    fs.appendFileSync(logFile, logLine, (err) => {
      if (err) console.error('Failed to write log file:', err);
    });
  }

  /**
   * Log message with level check
   */
  log(level, message, metadata = {}) {
    if (this.levels[level] < this.levels[this.logLevel]) {
      return;
    }

    const logEntry = this.formatLog(level, message, metadata);
    this.writeToFile(logEntry);

    // Console output with colors
    const colors = {
      debug: '\x1b[36m', // cyan
      info: '\x1b[32m',  // green
      warn: '\x1b[33m',  // yellow
      error: '\x1b[31m'  // red
    };
    const reset = '\x1b[0m';
    const color = colors[level] || reset;

    console.log(
      `${color}[${logEntry.timestamp}] [${level.toUpperCase()}] [${this.component}]${reset} ${message}`,
      Object.keys(metadata).length > 0 ? metadata : ''
    );
  }

  debug(message, metadata = {}) {
    this.log('debug', message, metadata);
  }

  info(message, metadata = {}) {
    this.log('info', message, metadata);
  }

  warn(message, metadata = {}) {
    this.log('warn', message, metadata);
  }

  error(message, metadata = {}) {
    this.log('error', message, metadata);
  }

  /**
   * Export logs to file
   */
  async exportLogs(startDate, endDate, outputPath) {
    try {
      const logs = [];
      const current = new Date(startDate);
      
      while (current <= endDate) {
        const dateStr = current.toISOString().split('T')[0];
        const logFile = path.join(this.logDir, `${dateStr}.log`);
        
        if (fs.existsSync(logFile)) {
          const content = fs.readFileSync(logFile, 'utf8');
          logs.push(...content.trim().split('\n').filter(line => line));
        }
        
        current.setDate(current.getDate() + 1);
      }

      fs.writeFileSync(outputPath, logs.join('\n'), 'utf8');
      return { success: true, count: logs.length };
    } catch (error) {
      this.error('Failed to export logs', { error: error.message });
      return { success: false, error: error.message };
    }
  }

  /**
   * Search logs by pattern
   */
  async searchLogs(pattern, limit = 100) {
    try {
      const logs = [];
      const regex = new RegExp(pattern, 'i');
      const files = fs.readdirSync(this.logDir).filter(f => f.endsWith('.log')).sort().reverse();

      for (const file of files) {
        if (logs.length >= limit) break;
        
        const logFile = path.join(this.logDir, file);
        const content = fs.readFileSync(logFile, 'utf8');
        const lines = content.trim().split('\n').filter(line => line);

        for (const line of lines) {
          if (logs.length >= limit) break;
          if (regex.test(line)) {
            try {
              logs.push(JSON.parse(line));
            } catch (e) {
              // Skip malformed lines
            }
          }
        }
      }

      return logs;
    } catch (error) {
      this.error('Failed to search logs', { error: error.message });
      return [];
    }
  }
}

module.exports = Logger;
