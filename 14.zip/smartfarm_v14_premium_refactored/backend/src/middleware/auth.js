/**
 * SmartFarm V14 Premium - Authentication & Middleware
 * IMPROVED: Added refresh token support, better error handling, input sanitization
 */

'use strict';

const jwt = require('jsonwebtoken');
const Logger = require('../utils/logger');
const logger = new Logger('Auth-Middleware');

/**
 * Verify JWT access token
 */
function verifyToken(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'No token provided', code: 'TOKEN_MISSING' });
  }

  const token = authHeader.split(' ')[1];
  if (!token) {
    return res.status(401).json({ error: 'Invalid token format', code: 'TOKEN_INVALID' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (error) {
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({ error: 'Token expired', code: 'TOKEN_EXPIRED' });
    }
    if (error.name === 'JsonWebTokenError') {
      return res.status(401).json({ error: 'Invalid token', code: 'TOKEN_INVALID' });
    }
    logger.error('Token verification error', { error: error.message });
    return res.status(401).json({ error: 'Authentication failed', code: 'AUTH_FAILED' });
  }
}

/**
 * Verify JWT refresh token
 */
function verifyRefreshToken(req, res, next) {
  const { refreshToken } = req.body;
  if (!refreshToken) {
    return res.status(401).json({ error: 'No refresh token provided', code: 'REFRESH_TOKEN_MISSING' });
  }

  try {
    const decoded = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET || process.env.JWT_SECRET);
    req.user = decoded;
    req.refreshToken = refreshToken;
    next();
  } catch (error) {
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({ error: 'Refresh token expired', code: 'REFRESH_TOKEN_EXPIRED' });
    }
    return res.status(401).json({ error: 'Invalid refresh token', code: 'REFRESH_TOKEN_INVALID' });
  }
}

/**
 * Require admin role
 */
function requireAdmin(req, res, next) {
  if (!req.user) {
    return res.status(401).json({ error: 'Unauthorized', code: 'UNAUTHORIZED' });
  }
  if (req.user.role !== 'admin') {
    logger.warn('Admin access denied', { userId: req.user?.id, role: req.user?.role });
    return res.status(403).json({ error: 'Admin access required', code: 'FORBIDDEN' });
  }
  next();
}

/**
 * Require operator or admin role
 */
function requireOperator(req, res, next) {
  if (!req.user) {
    return res.status(401).json({ error: 'Unauthorized', code: 'UNAUTHORIZED' });
  }
  if (!['admin', 'operator'].includes(req.user.role)) {
    logger.warn('Operator access denied', { userId: req.user?.id, role: req.user?.role });
    return res.status(403).json({ error: 'Operator access required', code: 'FORBIDDEN' });
  }
  next();
}

/**
 * Require any authenticated user
 */
function requireAuth(req, res, next) {
  if (!req.user) {
    return res.status(401).json({ error: 'Unauthorized', code: 'UNAUTHORIZED' });
  }
  next();
}

/**
 * Error handling middleware
 */
function errorHandler(err, req, res, next) {
  logger.error('Unhandled error', {
    error: err.message,
    stack: process.env.NODE_ENV !== 'production' ? err.stack : undefined,
    path: req.path,
    method: req.method
  });

  const statusCode = err.statusCode || err.status || 500;
  const message = process.env.NODE_ENV === 'production' && statusCode === 500
    ? 'Internal server error'
    : err.message || 'Internal server error';

  res.status(statusCode).json({
    error: message,
    code: err.code || 'INTERNAL_ERROR',
    status: statusCode,
    timestamp: new Date().toISOString(),
    ...(process.env.NODE_ENV !== 'production' && { stack: err.stack })
  });
}

/**
 * Request logging middleware
 */
function requestLogger(req, res, next) {
  const start = Date.now();
  const { method, path: reqPath, ip } = req;

  res.on('finish', () => {
    const duration = Date.now() - start;
    const level = res.statusCode >= 500 ? 'error' : res.statusCode >= 400 ? 'warn' : 'info';
    logger[level]('Request completed', {
      method,
      path: reqPath,
      status: res.statusCode,
      duration: `${duration}ms`,
      ip: req.ip || ip,
      userId: req.user?.id
    });
  });

  next();
}

module.exports = {
  verifyToken,
  verifyRefreshToken,
  requireAdmin,
  requireOperator,
  requireAuth,
  errorHandler,
  requestLogger
};
