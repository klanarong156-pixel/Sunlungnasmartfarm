/**
 * Automated Audit Log Middleware
 * Captures user actions on API resources
 */

const AuditLogger = require('../utils/audit');

const createAuditLogMiddleware = (db) => {
  const auditLogger = new AuditLogger(db);

  return (req, res, next) => {
    // Skip logging for GET requests and auth login
    if (req.method === 'GET' || req.path === '/api/auth/login') {
      return next();
    }

    // Capture original end function to log after response is sent
    const originalEnd = res.end;
    res.end = function(chunk, encoding) {
      res.end = originalEnd;
      res.end(chunk, encoding);

      // Only log if we have a user (authenticated)
      if (req.user) {
        const resourceType = req.path.split('/')[2] || 'unknown';
        const resourceId = req.params.id || req.body.id || null;
        
        auditLogger.log({
          userId: req.user.id,
          action: `${req.method}_${resourceType.toUpperCase()}`,
          resourceType,
          resourceId,
          changes: req.method !== 'DELETE' ? req.body : null,
          ipAddress: req.ip,
          userAgent: req.get('User-Agent'),
          status: res.statusCode < 400 ? 'success' : 'failure'
        });
      }
    };

    next();
  };
};

module.exports = createAuditLogMiddleware;
