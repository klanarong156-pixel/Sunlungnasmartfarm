/**
 * RBAC (Role-Based Access Control) Middleware
 * Handles permission checking and role-based routing
 */

const Logger = require('../utils/logger');
const logger = new Logger('RBAC');

/**
 * Check if user has specific permission
 * @param {Object} db - Database instance
 * @param {string} permissionName - Name of the permission to check
 */
const hasPermission = (db, permissionName) => {
  return async (req, res, next) => {
    try {
      const userId = req.user.id;
      
      const query = `
        SELECT p.name 
        FROM permissions p
        JOIN role_permissions rp ON p.id = rp.permission_id
        JOIN roles r ON rp.role_id = r.id
        JOIN users u ON r.id = u.role_id
        WHERE u.id = ? AND p.name = ?
      `;
      
      const permission = await db.get(query, [userId, permissionName]);
      
      if (!permission) {
        logger.warn('Permission denied', { userId, permissionName });
        return res.status(403).json({ 
          error: 'Access denied', 
          message: `Required permission: ${permissionName}` 
        });
      }
      
      next();
    } catch (error) {
      logger.error('RBAC check failed', { error: error.message });
      res.status(500).json({ error: 'Internal server error' });
    }
  };
};

/**
 * Check if user has one of the required roles
 * @param {Array<string>} roles - Array of allowed role names
 */
const hasRole = (roles) => {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      logger.warn('Role access denied', { 
        userId: req.user?.id, 
        userRole: req.user?.role,
        requiredRoles: roles 
      });
      return res.status(403).json({ 
        error: 'Access denied', 
        message: 'Insufficient role permissions' 
      });
    }
    next();
  };
};

module.exports = {
  hasPermission,
  hasRole
};
