/**
 * Database Initialization Module
 * Handles SQLite database setup, schema creation, and migrations
 */

const sqlite3 = require('sqlite3').verbose();
const fs = require('fs');
const path = require('path');
const Logger = require('../utils/logger');

const logger = new Logger('Database');

class Database {
  constructor(dbPath) {
    this.dbPath = dbPath;
    this.db = null;
  }

  /**
   * Initialize database connection and create schema
   */
  async initialize() {
    return new Promise((resolve, reject) => {
      // Create data directory if it doesn't exist
      const dataDir = path.dirname(this.dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      this.db = new sqlite3.Database(this.dbPath, (err) => {
        if (err) {
          logger.error('Failed to open database', { error: err.message });
          reject(err);
        } else {
          logger.info('Database connection established', { path: this.dbPath });
          this.createSchema()
            .then(() => {
              this.initializeDefaultData()
                .then(() => {
                  logger.info('Database initialized successfully');
                  resolve();
                })
                .catch(reject);
            })
            .catch(reject);
        }
      });
    });
  }

  /**
   * Create database schema from SQL file
   */
  async createSchema() {
    return new Promise((resolve, reject) => {
      const schemaPath = path.join(__dirname, 'schema.sql');
      const schema = fs.readFileSync(schemaPath, 'utf8');

      this.db.exec(schema, (err) => {
        if (err) {
          logger.error('Failed to create schema', { error: err.message });
          reject(err);
        } else {
          logger.info('Database schema created successfully');
          resolve();
        }
      });
    });
  }

  /**
   * Initialize default data
   */
  async initializeDefaultData() {
    return new Promise((resolve, reject) => {
      const adminPassword = require('bcryptjs').hashSync('admin123', 10);

      const queries = [
        {
          sql: 'INSERT OR IGNORE INTO users (username, email, password_hash, role, full_name) VALUES (?, ?, ?, ?, ?)',
          params: ['admin', 'admin@smartfarm.local', adminPassword, 'admin', 'Administrator']
        },
        {
          sql: 'INSERT OR IGNORE INTO settings (key, value, type, description) VALUES (?, ?, ?, ?)',
          params: ['farm_name', 'สวนลุงนะ ฟาร์ม', 'string', 'ชื่อฟาร์ม']
        },
        {
          sql: 'INSERT OR IGNORE INTO settings (key, value, type, description) VALUES (?, ?, ?, ?)',
          params: ['timezone', 'Asia/Bangkok', 'string', 'เขตเวลา']
        },
        {
          sql: 'INSERT OR IGNORE INTO settings (key, value, type, description) VALUES (?, ?, ?, ?)',
          params: ['language', 'th', 'string', 'ภาษา']
        },
        {
          sql: 'INSERT OR IGNORE INTO settings (key, value, type, description) VALUES (?, ?, ?, ?)',
          params: ['theme', 'dark', 'string', 'ธีม (dark/light/auto)']
        },
        {
          sql: 'INSERT OR IGNORE INTO settings (key, value, type, description) VALUES (?, ?, ?, ?)',
          params: ['mqtt_enabled', 'true', 'boolean', 'เปิดใช้ MQTT']
        },
        {
          sql: 'INSERT OR IGNORE INTO settings (key, value, type, description) VALUES (?, ?, ?, ?)',
          params: ['weather_enabled', 'true', 'boolean', 'เปิดใช้ข้อมูลสภาพอากาศ']
        },
        {
          sql: 'INSERT OR IGNORE INTO settings (key, value, type, description) VALUES (?, ?, ?, ?)',
          params: ['telegram_enabled', 'false', 'boolean', 'เปิดใช้ Telegram']
        }
      ];

      let completed = 0;
      queries.forEach((query) => {
        this.db.run(query.sql, query.params, (err) => {
          if (err) {
            logger.warn('Failed to insert default data', { error: err.message, query: query.sql });
          }
          completed++;
          if (completed === queries.length) {
            logger.info('Default data initialized');
            resolve();
          }
        });
      });
    });
  }

  /**
   * Run a query with parameters
   */
  run(sql, params = []) {
    return new Promise((resolve, reject) => {
      this.db.run(sql, params, function(err) {
        if (err) {
          reject(err);
        } else {
          resolve({ id: this.lastID, changes: this.changes });
        }
      });
    });
  }

  /**
   * Get a single row
   */
  get(sql, params = []) {
    return new Promise((resolve, reject) => {
      this.db.get(sql, params, (err, row) => {
        if (err) {
          reject(err);
        } else {
          resolve(row);
        }
      });
    });
  }

  /**
   * Get all rows
   */
  all(sql, params = []) {
    return new Promise((resolve, reject) => {
      this.db.all(sql, params, (err, rows) => {
        if (err) {
          reject(err);
        } else {
          resolve(rows || []);
        }
      });
    });
  }

  /**
   * Begin transaction
   */
  beginTransaction() {
    return this.run('BEGIN TRANSACTION');
  }

  /**
   * Commit transaction
   */
  commit() {
    return this.run('COMMIT');
  }

  /**
   * Rollback transaction
   */
  rollback() {
    return this.run('ROLLBACK');
  }

  /**
   * Close database connection
   */
  close() {
    return new Promise((resolve, reject) => {
      if (this.db) {
        this.db.close((err) => {
          if (err) {
            logger.error('Error closing database', { error: err.message });
            reject(err);
          } else {
            logger.info('Database connection closed');
            resolve();
          }
        });
      } else {
        resolve();
      }
    });
  }
}

module.exports = Database;
