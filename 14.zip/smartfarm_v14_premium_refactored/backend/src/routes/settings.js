/**
 * Settings Routes
 * Handles system settings, configuration, and preferences
 */

const express = require('express');
const Logger = require('../utils/logger');
const Validator = require('../utils/validation');
const { verifyToken, requireAdmin } = require('../middleware/auth');

const logger = new Logger('SettingsRoutes');

function createSettingsRoutes(db) {
  const router = express.Router();

  /**
   * GET /settings
   * Get all settings
   */
  router.get('/', verifyToken, async (req, res) => {
    try {
      const settings = await db.all('SELECT key, value, type, description FROM settings ORDER BY key');

      const result = {};
      settings.forEach(s => {
        result[s.key] = {
          value: s.type === 'boolean' ? s.value === 'true' : s.value,
          type: s.type,
          description: s.description
        };
      });

      res.json({ success: true, settings: result });
    } catch (error) {
      logger.error('Failed to fetch settings', { error: error.message });
      res.status(500).json({ error: 'Failed to fetch settings' });
    }
  });

  /**
   * GET /settings/:key
   * Get specific setting
   */
  router.get('/:key', verifyToken, async (req, res) => {
    try {
      const setting = await db.get(
        'SELECT key, value, type, description FROM settings WHERE key = ?',
        [req.params.key]
      );

      if (!setting) {
        return res.status(404).json({ error: 'Setting not found' });
      }

      res.json({
        success: true,
        setting: {
          key: setting.key,
          value: setting.type === 'boolean' ? setting.value === 'true' : setting.value,
          type: setting.type,
          description: setting.description
        }
      });
    } catch (error) {
      logger.error('Failed to fetch setting', { error: error.message });
      res.status(500).json({ error: 'Failed to fetch setting' });
    }
  });

  /**
   * PUT /settings/:key
   * Update specific setting
   */
  router.put('/:key', verifyToken, requireAdmin, async (req, res) => {
    try {
      const { value, type, description } = req.body;

      const validation = Validator.validateSettings({ key: req.params.key, value, type });
      if (!validation.valid) {
        return res.status(400).json({ error: validation.errors });
      }

      const stringValue = typeof value === 'string' ? value : String(value);

      await db.run(
        `INSERT OR REPLACE INTO settings (key, value, type, description)
         VALUES (?, ?, ?, ?)`,
        [req.params.key, stringValue, type || 'string', description || null]
      );

      logger.info('Setting updated', { key: req.params.key, value: stringValue });

      res.json({ success: true, message: 'Setting updated' });
    } catch (error) {
      logger.error('Failed to update setting', { error: error.message });
      res.status(500).json({ error: 'Failed to update setting' });
    }
  });

  /**
   * POST /settings/batch
   * Update multiple settings
   */
  router.post('/batch', verifyToken, requireAdmin, async (req, res) => {
    try {
      const { settings } = req.body;

      if (!Array.isArray(settings)) {
        return res.status(400).json({ error: 'Settings must be an array' });
      }

      await db.beginTransaction();

      for (const setting of settings) {
        const validation = Validator.validateSettings(setting);
        if (!validation.valid) {
          await db.rollback();
          return res.status(400).json({ error: validation.errors });
        }

        const stringValue = typeof setting.value === 'string' ? setting.value : String(setting.value);

        await db.run(
          `INSERT OR REPLACE INTO settings (key, value, type, description)
           VALUES (?, ?, ?, ?)`,
          [setting.key, stringValue, setting.type || 'string', setting.description || null]
        );
      }

      await db.commit();

      logger.info('Batch settings updated', { count: settings.length });

      res.json({ success: true, message: `${settings.length} settings updated` });
    } catch (error) {
      await db.rollback();
      logger.error('Failed to update batch settings', { error: error.message });
      res.status(500).json({ error: 'Failed to update settings' });
    }
  });

  /**
   * DELETE /settings/:key
   * Delete setting
   */
  router.delete('/:key', verifyToken, requireAdmin, async (req, res) => {
    try {
      await db.run('DELETE FROM settings WHERE key = ?', [req.params.key]);

      logger.info('Setting deleted', { key: req.params.key });

      res.json({ success: true, message: 'Setting deleted' });
    } catch (error) {
      logger.error('Failed to delete setting', { error: error.message });
      res.status(500).json({ error: 'Failed to delete setting' });
    }
  });

  /**
   * GET /settings/system/info
   * Get system information
   */
  router.get('/system/info', verifyToken, async (req, res) => {
    try {
      const uptime = process.uptime();
      const memoryUsage = process.memoryUsage();

      const dbStats = await db.get(
        `SELECT 
          (SELECT COUNT(*) FROM sensors) as sensor_count,
          (SELECT COUNT(*) FROM pumps) as pump_count,
          (SELECT COUNT(*) FROM schedules) as schedule_count,
          (SELECT COUNT(*) FROM users) as user_count,
          (SELECT COUNT(*) FROM logs) as log_count`
      );

      res.json({
        success: true,
        system: {
          uptime: Math.floor(uptime),
          memory: {
            heapUsed: Math.round(memoryUsage.heapUsed / 1024 / 1024),
            heapTotal: Math.round(memoryUsage.heapTotal / 1024 / 1024),
            external: Math.round(memoryUsage.external / 1024 / 1024)
          },
          database: dbStats,
          timestamp: new Date().toISOString()
        }
      });
    } catch (error) {
      logger.error('Failed to fetch system info', { error: error.message });
      res.status(500).json({ error: 'Failed to fetch system info' });
    }
  });

  /**
   * GET /settings/farm/info
   * Get farm information
   */
  router.get('/farm/info', verifyToken, async (req, res) => {
    try {
      const farmName = await db.get(
        'SELECT value FROM settings WHERE key = ?',
        ['farm_name']
      );

      const stats = await db.get(
        `SELECT 
          (SELECT COUNT(*) FROM sensors WHERE is_active = 1) as active_sensors,
          (SELECT COUNT(*) FROM pumps WHERE is_active = 1) as active_pumps,
          (SELECT COUNT(*) FROM schedules WHERE is_enabled = 1) as enabled_schedules,
          (SELECT SUM(total_runtime_seconds) FROM pumps) as total_pump_runtime`
      );

      res.json({
        success: true,
        farm: {
          name: farmName?.value || 'SmartFarm',
          ...stats
        }
      });
    } catch (error) {
      logger.error('Failed to fetch farm info', { error: error.message });
      res.status(500).json({ error: 'Failed to fetch farm info' });
    }
  });

  return router;
}

module.exports = createSettingsRoutes;
