/**
 * Weather Routes
 * Handles weather data retrieval, caching, offline support, and forecasts
 */

const express = require('express');
const axios = require('axios');
const Logger = require('../utils/logger');
const Validator = require('../utils/validation');
const { verifyToken } = require('../middleware/auth');

const logger = new Logger('WeatherRoutes');

class WeatherService {
  constructor(db) {
    this.db = db;
    this.cache = new Map();
    this.cacheTimeout = (process.env.WEATHER_CACHE_MINUTES || 30) * 60 * 1000;
  }

  /**
   * Fetch weather data from Open Meteo API
   */
  async fetchWeatherData(latitude, longitude) {
    try {
      const cacheKey = `${latitude},${longitude}`;
      const cached = this.cache.get(cacheKey);

      if (cached && Date.now() - cached.timestamp < this.cacheTimeout) {
        logger.debug('Weather data from cache', { latitude, longitude });
        return cached.data;
      }

      const url = `${process.env.WEATHER_API_URL}?latitude=${latitude}&longitude=${longitude}&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m,cloud_cover,rain&daily=temperature_2m_max,temperature_2m_min,precipitation_sum,weather_code,uv_index_max,sunrise,sunset&timezone=Asia/Bangkok`;

      const response = await axios.get(url, { timeout: 10000 });
      const data = response.data;

      this.cache.set(cacheKey, {
        data,
        timestamp: Date.now()
      });

      logger.info('Weather data fetched', { latitude, longitude });
      return data;
    } catch (error) {
      logger.error('Failed to fetch weather data', { error: error.message });
      throw error;
    }
  }

  /**
   * Parse weather data
   */
  parseWeatherData(data) {
    const current = data.current;
    const daily = data.daily;

    return {
      current: {
        temperature: current.temperature_2m,
        humidity: current.relative_humidity_2m,
        weatherCode: current.weather_code,
        windSpeed: current.wind_speed_10m,
        cloudCover: current.cloud_cover,
        rain: current.rain,
        timestamp: current.time
      },
      forecast: daily.time.map((date, index) => ({
        date,
        tempMax: daily.temperature_2m_max[index],
        tempMin: daily.temperature_2m_min[index],
        precipitation: daily.precipitation_sum[index],
        weatherCode: daily.weather_code[index],
        uvIndex: daily.uv_index_max[index],
        sunrise: daily.sunrise[index],
        sunset: daily.sunset[index]
      }))
    };
  }

  /**
   * Interpret weather code (WMO)
   */
  interpretWeatherCode(code) {
    const codes = {
      0: 'Clear sky',
      1: 'Mainly clear',
      2: 'Partly cloudy',
      3: 'Overcast',
      45: 'Foggy',
      48: 'Depositing rime fog',
      51: 'Light drizzle',
      53: 'Moderate drizzle',
      55: 'Dense drizzle',
      61: 'Slight rain',
      63: 'Moderate rain',
      65: 'Heavy rain',
      71: 'Slight snow',
      73: 'Moderate snow',
      75: 'Heavy snow',
      77: 'Snow grains',
      80: 'Slight rain showers',
      81: 'Moderate rain showers',
      82: 'Violent rain showers',
      85: 'Slight snow showers',
      86: 'Heavy snow showers',
      95: 'Thunderstorm',
      96: 'Thunderstorm with slight hail',
      99: 'Thunderstorm with heavy hail'
    };

    return codes[code] || 'Unknown';
  }
}

function createWeatherRoutes(db) {
  const router = express.Router();
  const weatherService = new WeatherService(db);

  /**
   * GET /weather/current
   * Get current weather
   */
  router.get('/current', verifyToken, async (req, res) => {
    try {
      const latitude = parseFloat(req.query.latitude) || parseFloat(process.env.WEATHER_LATITUDE);
      const longitude = parseFloat(req.query.longitude) || parseFloat(process.env.WEATHER_LONGITUDE);

      const validation = Validator.validateWeather({ latitude, longitude });
      if (!validation.valid) {
        return res.status(400).json({ error: validation.errors });
      }

      const data = await weatherService.fetchWeatherData(latitude, longitude);
      const parsed = weatherService.parseWeatherData(data);

      res.json({
        success: true,
        weather: {
          ...parsed.current,
          description: weatherService.interpretWeatherCode(parsed.current.weatherCode)
        }
      });
    } catch (error) {
      logger.error('Failed to fetch current weather', { error: error.message });
      res.status(500).json({ error: 'Failed to fetch weather data' });
    }
  });

  /**
   * GET /weather/forecast
   * Get weather forecast
   */
  router.get('/forecast', verifyToken, async (req, res) => {
    try {
      const latitude = parseFloat(req.query.latitude) || parseFloat(process.env.WEATHER_LATITUDE);
      const longitude = parseFloat(req.query.longitude) || parseFloat(process.env.WEATHER_LONGITUDE);
      const days = parseInt(req.query.days) || 7;

      const validation = Validator.validateWeather({ latitude, longitude });
      if (!validation.valid) {
        return res.status(400).json({ error: validation.errors });
      }

      const data = await weatherService.fetchWeatherData(latitude, longitude);
      const parsed = weatherService.parseWeatherData(data);

      const forecast = parsed.forecast.slice(0, days).map(day => ({
        ...day,
        description: weatherService.interpretWeatherCode(day.weatherCode)
      }));

      res.json({ success: true, forecast });
    } catch (error) {
      logger.error('Failed to fetch weather forecast', { error: error.message });
      res.status(500).json({ error: 'Failed to fetch forecast' });
    }
  });

  /**
   * GET /weather/settings
   * Get weather settings
   */
  router.get('/settings', verifyToken, async (req, res) => {
    try {
      const settings = await db.all(
        `SELECT key, value FROM settings WHERE key LIKE 'weather_%'`
      );

      const weatherSettings = {};
      settings.forEach(s => {
        weatherSettings[s.key] = s.value;
      });

      res.json({ success: true, settings: weatherSettings });
    } catch (error) {
      logger.error('Failed to fetch weather settings', { error: error.message });
      res.status(500).json({ error: 'Failed to fetch settings' });
    }
  });

  /**
   * PUT /weather/settings
   * Update weather settings
   */
  router.put('/settings', verifyToken, async (req, res) => {
    try {
      const { latitude, longitude, cache_minutes } = req.body;

      const validation = Validator.validateWeather({ latitude, longitude, cache_minutes });
      if (!validation.valid) {
        return res.status(400).json({ error: validation.errors });
      }

      if (latitude) {
        await db.run(
          `INSERT OR REPLACE INTO settings (key, value, type, description)
           VALUES (?, ?, ?, ?)`,
          ['weather_latitude', latitude.toString(), 'number', 'Weather latitude']
        );
      }

      if (longitude) {
        await db.run(
          `INSERT OR REPLACE INTO settings (key, value, type, description)
           VALUES (?, ?, ?, ?)`,
          ['weather_longitude', longitude.toString(), 'number', 'Weather longitude']
        );
      }

      if (cache_minutes) {
        await db.run(
          `INSERT OR REPLACE INTO settings (key, value, type, description)
           VALUES (?, ?, ?, ?)`,
          ['weather_cache_minutes', cache_minutes.toString(), 'number', 'Weather cache duration']
        );
      }

      logger.info('Weather settings updated');

      res.json({ success: true, message: 'Settings updated' });
    } catch (error) {
      logger.error('Failed to update weather settings', { error: error.message });
      res.status(500).json({ error: 'Failed to update settings' });
    }
  });

  /**
   * GET /weather/offline
   * Get offline weather data (last cached)
   */
  router.get('/offline', verifyToken, async (req, res) => {
    try {
      // Return cached data if available
      if (weatherService.cache.size > 0) {
        const cached = Array.from(weatherService.cache.values())[0];
        const parsed = weatherService.parseWeatherData(cached.data);

        return res.json({
          success: true,
          offline: true,
          weather: parsed.current,
          cachedAt: new Date(cached.timestamp).toISOString()
        });
      }

      res.json({ success: true, offline: true, weather: null });
    } catch (error) {
      logger.error('Failed to fetch offline weather', { error: error.message });
      res.status(500).json({ error: 'Failed to fetch offline data' });
    }
  });

  return router;
}

module.exports = createWeatherRoutes;
