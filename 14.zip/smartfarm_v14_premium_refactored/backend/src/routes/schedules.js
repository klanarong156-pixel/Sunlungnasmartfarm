/**
 * Schedule Routes
 * Handles pump scheduling, enable/disable, edit, delete, pause, resume, and rain skip
 */

const express = require('express');
const Logger = require('../utils/logger');
const Validator = require('../utils/validation');
const { verifyToken, requireOperator } = require('../middleware/auth');

const logger = new Logger('ScheduleRoutes');

function createScheduleRoutes(db, mqtt) {
  const router = express.Router();

  /**
   * GET /schedules
   * Get all schedules
   */
  router.get('/', verifyToken, async (req, res) => {
    try {
      const schedules = await db.all(
        `SELECT s.id, s.pump_id, p.name as pump_name, s.name, s.start_time, s.duration_seconds,
                s.days_of_week, s.is_enabled, s.is_paused, s.rain_skip, s.holiday_mode,
                s.last_run, s.next_run, s.created_at
         FROM schedules s
         JOIN pumps p ON s.pump_id = p.id
         ORDER BY s.start_time`
      );

      res.json({ success: true, schedules });
    } catch (error) {
      logger.error('Failed to fetch schedules', { error: error.message });
      res.status(500).json({ error: 'Failed to fetch schedules' });
    }
  });

  /**
   * GET /schedules/:id
   * Get schedule details
   */
  router.get('/:id', verifyToken, async (req, res) => {
    try {
      const schedule = await db.get(
        'SELECT * FROM schedules WHERE id = ?',
        [req.params.id]
      );

      if (!schedule) {
        return res.status(404).json({ error: 'Schedule not found' });
      }

      res.json({ success: true, schedule });
    } catch (error) {
      logger.error('Failed to fetch schedule', { error: error.message });
      res.status(500).json({ error: 'Failed to fetch schedule' });
    }
  });

  /**
   * POST /schedules
   * Create new schedule
   */
  router.post('/', verifyToken, requireOperator, async (req, res) => {
    try {
      const { pump_id, name, start_time, duration_seconds, days_of_week, rain_skip, holiday_mode } = req.body;

      const validation = Validator.validateSchedule({ name, start_time, duration_seconds, days_of_week });
      if (!validation.valid) {
        return res.status(400).json({ error: validation.errors });
      }

      const pump = await db.get('SELECT * FROM pumps WHERE id = ?', [pump_id]);
      if (!pump) {
        return res.status(404).json({ error: 'Pump not found' });
      }

      const result = await db.run(
        `INSERT INTO schedules (pump_id, name, start_time, duration_seconds, days_of_week, rain_skip, holiday_mode)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [pump_id, name, start_time, duration_seconds, days_of_week, rain_skip ?? 1, holiday_mode ?? 0]
      );

      logger.info('Schedule created', { scheduleId: result.id, pumpId: pump_id, name });

      res.status(201).json({
        success: true,
        message: 'Schedule created',
        scheduleId: result.id
      });
    } catch (error) {
      logger.error('Failed to create schedule', { error: error.message });
      res.status(500).json({ error: 'Failed to create schedule' });
    }
  });

  /**
   * PUT /schedules/:id
   * Update schedule
   */
  router.put('/:id', verifyToken, requireOperator, async (req, res) => {
    try {
      const { name, start_time, duration_seconds, days_of_week, rain_skip, holiday_mode } = req.body;

      const validation = Validator.validateSchedule({ name, start_time, duration_seconds, days_of_week });
      if (!validation.valid) {
        return res.status(400).json({ error: validation.errors });
      }

      await db.run(
        `UPDATE schedules SET name = ?, start_time = ?, duration_seconds = ?, 
                days_of_week = ?, rain_skip = ?, holiday_mode = ?, updated_at = CURRENT_TIMESTAMP
         WHERE id = ?`,
        [name, start_time, duration_seconds, days_of_week, rain_skip, holiday_mode, req.params.id]
      );

      logger.info('Schedule updated', { scheduleId: req.params.id });

      res.json({ success: true, message: 'Schedule updated' });
    } catch (error) {
      logger.error('Failed to update schedule', { error: error.message });
      res.status(500).json({ error: 'Failed to update schedule' });
    }
  });

  /**
   * DELETE /schedules/:id
   * Delete schedule
   */
  router.delete('/:id', verifyToken, requireOperator, async (req, res) => {
    try {
      await db.run('DELETE FROM schedules WHERE id = ?', [req.params.id]);

      logger.info('Schedule deleted', { scheduleId: req.params.id });

      res.json({ success: true, message: 'Schedule deleted' });
    } catch (error) {
      logger.error('Failed to delete schedule', { error: error.message });
      res.status(500).json({ error: 'Failed to delete schedule' });
    }
  });

  /**
   * POST /schedules/:id/enable
   * Enable schedule
   */
  router.post('/:id/enable', verifyToken, requireOperator, async (req, res) => {
    try {
      await db.run(
        'UPDATE schedules SET is_enabled = 1, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
        [req.params.id]
      );

      logger.info('Schedule enabled', { scheduleId: req.params.id });

      res.json({ success: true, message: 'Schedule enabled' });
    } catch (error) {
      logger.error('Failed to enable schedule', { error: error.message });
      res.status(500).json({ error: 'Failed to enable schedule' });
    }
  });

  /**
   * POST /schedules/:id/disable
   * Disable schedule
   */
  router.post('/:id/disable', verifyToken, requireOperator, async (req, res) => {
    try {
      await db.run(
        'UPDATE schedules SET is_enabled = 0, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
        [req.params.id]
      );

      logger.info('Schedule disabled', { scheduleId: req.params.id });

      res.json({ success: true, message: 'Schedule disabled' });
    } catch (error) {
      logger.error('Failed to disable schedule', { error: error.message });
      res.status(500).json({ error: 'Failed to disable schedule' });
    }
  });

  /**
   * POST /schedules/:id/pause
   * Pause schedule
   */
  router.post('/:id/pause', verifyToken, requireOperator, async (req, res) => {
    try {
      await db.run(
        'UPDATE schedules SET is_paused = 1, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
        [req.params.id]
      );

      logger.info('Schedule paused', { scheduleId: req.params.id });

      res.json({ success: true, message: 'Schedule paused' });
    } catch (error) {
      logger.error('Failed to pause schedule', { error: error.message });
      res.status(500).json({ error: 'Failed to pause schedule' });
    }
  });

  /**
   * POST /schedules/:id/resume
   * Resume schedule
   */
  router.post('/:id/resume', verifyToken, requireOperator, async (req, res) => {
    try {
      await db.run(
        'UPDATE schedules SET is_paused = 0, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
        [req.params.id]
      );

      logger.info('Schedule resumed', { scheduleId: req.params.id });

      res.json({ success: true, message: 'Schedule resumed' });
    } catch (error) {
      logger.error('Failed to resume schedule', { error: error.message });
      res.status(500).json({ error: 'Failed to resume schedule' });
    }
  });

  /**
   * POST /schedules/:id/duplicate
   * Duplicate schedule (with protection against duplicates)
   */
  router.post('/:id/duplicate', verifyToken, requireOperator, async (req, res) => {
    try {
      const schedule = await db.get('SELECT * FROM schedules WHERE id = ?', [req.params.id]);
      if (!schedule) {
        return res.status(404).json({ error: 'Schedule not found' });
      }

      const result = await db.run(
        `INSERT INTO schedules (pump_id, name, start_time, duration_seconds, days_of_week, rain_skip, holiday_mode)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [
          schedule.pump_id,
          `${schedule.name} (Copy)`,
          schedule.start_time,
          schedule.duration_seconds,
          schedule.days_of_week,
          schedule.rain_skip,
          schedule.holiday_mode
        ]
      );

      logger.info('Schedule duplicated', { originalId: req.params.id, newId: result.id });

      res.status(201).json({
        success: true,
        message: 'Schedule duplicated',
        scheduleId: result.id
      });
    } catch (error) {
      logger.error('Failed to duplicate schedule', { error: error.message });
      res.status(500).json({ error: 'Failed to duplicate schedule' });
    }
  });

  /**
   * GET /schedules/pump/:pumpId
   * Get schedules for specific pump
   */
  router.get('/pump/:pumpId', verifyToken, async (req, res) => {
    try {
      const schedules = await db.all(
        `SELECT * FROM schedules WHERE pump_id = ? ORDER BY start_time`,
        [req.params.pumpId]
      );

      res.json({ success: true, schedules });
    } catch (error) {
      logger.error('Failed to fetch pump schedules', { error: error.message });
      res.status(500).json({ error: 'Failed to fetch schedules' });
    }
  });

  return router;
}

module.exports = createScheduleRoutes;
