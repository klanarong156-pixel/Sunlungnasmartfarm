/**
 * Admin Routes
 * Handles user management, device tracking, OTA, and system administration
 */

const express = require('express');
const { verifyToken, requireAdmin } = require('../middleware/auth');
const { hasRole } = require('../middleware/rbac');

const createAdminRoutes = (db, otaService, backupService) => {
  const router = express.Router();

  // Apply admin protection to all routes
  router.use(verifyToken);
  router.use(requireAdmin);

  // --- User Management ---
  router.get('/users', async (req, res) => {
    try {
      const users = await db.all(`
        SELECT u.id, u.username, u.email, u.full_name, u.is_active, u.last_login, r.name as role
        FROM users u
        LEFT JOIN roles r ON u.role_id = r.id
      `);
      res.json({ success: true, users });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  router.post('/users', async (req, res) => {
    // Logic for creating new user
  });

  // --- Device Management ---
  router.get('/devices', async (req, res) => {
    try {
      const devices = await db.all('SELECT * FROM devices ORDER BY last_seen DESC');
      res.json({ success: true, devices });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // --- OTA Management ---
  router.get('/firmware', async (req, res) => {
    try {
      const firmware = await db.all('SELECT * FROM firmware ORDER BY created_at DESC');
      res.json({ success: true, firmware });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  router.post('/ota/trigger', async (req, res) => {
    try {
      const { deviceId, version } = req.body;
      const result = await otaService.triggerUpdate(deviceId, version);
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // --- Backup & Restore ---
  router.get('/backups', async (req, res) => {
    try {
      const backups = await backupService.listBackups();
      res.json({ success: true, backups });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  router.post('/backups/create', async (req, res) => {
    try {
      const result = await backupService.createBackup(req.user.id);
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // --- Audit Logs ---
  router.get('/audit-logs', async (req, res) => {
    try {
      const { limit = 100, offset = 0 } = req.query;
      const logs = await db.all(`
        SELECT a.*, u.username 
        FROM audit_logs a
        LEFT JOIN users u ON a.user_id = u.id
        ORDER BY a.created_at DESC
        LIMIT ? OFFSET ?
      `, [limit, offset]);
      res.json({ success: true, logs });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  return router;
};

module.exports = createAdminRoutes;
