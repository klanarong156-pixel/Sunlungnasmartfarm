/**
 * Sensor Routes
 * Handles sensor data retrieval, history, validation, and real-time updates
 */

const express = require('express');
const Logger = require('../utils/logger');
const Validator = require('../utils/validation');
const { verifyToken, requireOperator } = require('../middleware/auth');

const logger = new Logger('SensorRoutes');

function createSensorRoutes(db, mqtt) {
  const router = express.Router();

  /**
   * GET /sensors
   * Get all sensors
   */
  router.get('/', verifyToken, async (req, res) => {
    try {
      const sensors = await db.all(
        `SELECT id, device_id, sensor_type, name, unit, min_value, max_value, 
                last_value, last_update, is_active, created_at 
         FROM sensors ORDER BY sensor_type, name`
      );

      res.json({ success: true, sensors });
    } catch (error) {
      logger.error('Failed to fetch sensors', { error: error.message });
      res.status(500).json({ error: 'Failed to fetch sensors' });
    }
  });

  /**
   * GET /sensors/:id
   * Get sensor details
   */
  router.get('/:id', verifyToken, async (req, res) => {
    try {
      const sensor = await db.get(
        `SELECT * FROM sensors WHERE id = ?`,
        [req.params.id]
      );

      if (!sensor) {
        return res.status(404).json({ error: 'Sensor not found' });
      }

      res.json({ success: true, sensor });
    } catch (error) {
      logger.error('Failed to fetch sensor', { error: error.message });
      res.status(500).json({ error: 'Failed to fetch sensor' });
    }
  });

  /**
   * POST /sensors
   * Create new sensor
   */
  router.post('/', verifyToken, requireOperator, async (req, res) => {
    try {
      const { device_id, sensor_type, name, unit, min_value, max_value } = req.body;

      const validation = Validator.validateSensor({ sensor_type, name });
      if (!validation.valid) {
        return res.status(400).json({ error: validation.errors });
      }

      const result = await db.run(
        `INSERT INTO sensors (device_id, sensor_type, name, unit, min_value, max_value)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [device_id, sensor_type, name, unit, min_value, max_value]
      );

      logger.info('Sensor created', { sensorId: result.id, name, sensorType: sensor_type });

      res.status(201).json({
        success: true,
        message: 'Sensor created',
        sensorId: result.id
      });
    } catch (error) {
      logger.error('Failed to create sensor', { error: error.message });
      res.status(500).json({ error: 'Failed to create sensor' });
    }
  });

  /**
   * PUT /sensors/:id
   * Update sensor
   */
  router.put('/:id', verifyToken, requireOperator, async (req, res) => {
    try {
      const { name, unit, min_value, max_value, is_active } = req.body;

      await db.run(
        `UPDATE sensors SET name = ?, unit = ?, min_value = ?, max_value = ?, 
                is_active = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`,
        [name, unit, min_value, max_value, is_active, req.params.id]
      );

      logger.info('Sensor updated', { sensorId: req.params.id });

      res.json({ success: true, message: 'Sensor updated' });
    } catch (error) {
      logger.error('Failed to update sensor', { error: error.message });
      res.status(500).json({ error: 'Failed to update sensor' });
    }
  });

  /**
   * DELETE /sensors/:id
   * Delete sensor
   */
  router.delete('/:id', verifyToken, requireOperator, async (req, res) => {
    try {
      await db.run('DELETE FROM sensors WHERE id = ?', [req.params.id]);

      logger.info('Sensor deleted', { sensorId: req.params.id });

      res.json({ success: true, message: 'Sensor deleted' });
    } catch (error) {
      logger.error('Failed to delete sensor', { error: error.message });
      res.status(500).json({ error: 'Failed to delete sensor' });
    }
  });

  /**
   * POST /sensors/:id/data
   * Record sensor data
   */
  router.post('/:id/data', async (req, res) => {
    try {
      const { value } = req.body;

      if (value === undefined || isNaN(value)) {
        return res.status(400).json({ error: 'Invalid sensor value' });
      }

      const sensor = await db.get('SELECT * FROM sensors WHERE id = ?', [req.params.id]);
      if (!sensor) {
        return res.status(404).json({ error: 'Sensor not found' });
      }

      // Validate sensor value
      const validation = Validator.validateSensor({ ...sensor, value });
      if (!validation.valid) {
        logger.warn('Invalid sensor data', { sensorId: req.params.id, errors: validation.errors });
        return res.status(400).json({ error: validation.errors });
      }

      // Record history
      await db.run(
        'INSERT INTO sensor_history (sensor_id, value) VALUES (?, ?)',
        [req.params.id, value]
      );

      // Update sensor last value
      await db.run(
        'UPDATE sensors SET last_value = ?, last_update = CURRENT_TIMESTAMP WHERE id = ?',
        [value, req.params.id]
      );

      logger.debug('Sensor data recorded', { sensorId: req.params.id, value });

      res.json({ success: true, message: 'Data recorded' });
    } catch (error) {
      logger.error('Failed to record sensor data', { error: error.message });
      res.status(500).json({ error: 'Failed to record data' });
    }
  });

  /**
   * GET /sensors/:id/history
   * Get sensor history
   */
  router.get('/:id/history', verifyToken, async (req, res) => {
    try {
      const { startDate, endDate, limit = 1000 } = req.query;

      let query = 'SELECT value, timestamp FROM sensor_history WHERE sensor_id = ?';
      const params = [req.params.id];

      if (startDate) {
        query += ' AND timestamp >= ?';
        params.push(startDate);
      }

      if (endDate) {
        query += ' AND timestamp <= ?';
        params.push(endDate);
      }

      query += ' ORDER BY timestamp DESC LIMIT ?';
      params.push(parseInt(limit));

      const history = await db.all(query, params);

      res.json({ success: true, history: history.reverse() });
    } catch (error) {
      logger.error('Failed to fetch sensor history', { error: error.message });
      res.status(500).json({ error: 'Failed to fetch history' });
    }
  });

  /**
   * GET /sensors/:id/statistics
   * Get sensor statistics
   */
  router.get('/:id/statistics', verifyToken, async (req, res) => {
    try {
      const { days = 7 } = req.query;

      const stats = await db.get(
        `SELECT 
          COUNT(*) as count,
          AVG(value) as average,
          MIN(value) as minimum,
          MAX(value) as maximum,
          STDDEV(value) as stddev
         FROM sensor_history 
         WHERE sensor_id = ? AND timestamp >= datetime('now', '-' || ? || ' days')`,
        [req.params.id, days]
      );

      res.json({ success: true, statistics: stats });
    } catch (error) {
      logger.error('Failed to fetch sensor statistics', { error: error.message });
      res.status(500).json({ error: 'Failed to fetch statistics' });
    }
  });

  /**
   * GET /sensors/realtime/status
   * Get all sensors real-time status
   */
  router.get('/realtime/status', verifyToken, async (req, res) => {
    try {
      const sensors = await db.all(
        `SELECT id, name, sensor_type, last_value, unit, last_update, is_active 
         FROM sensors WHERE is_active = 1 ORDER BY sensor_type`
      );

      res.json({ 
        success: true, 
        sensors,
        timestamp: new Date().toISOString(),
        mqttStatus: mqtt.getStatus()
      });
    } catch (error) {
      logger.error('Failed to fetch realtime status', { error: error.message });
      res.status(500).json({ error: 'Failed to fetch status' });
    }
  });

  return router;
}

module.exports = createSensorRoutes;
