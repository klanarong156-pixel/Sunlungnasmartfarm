/**
 * Pump Routes - SmartFarm V14 Premium Enterprise
 * Handles pump control, status, history, runtime tracking, and advanced logic
 */

const express = require('express');
const Logger = require('../utils/logger');
const { verifyToken, requireOperator } = require('../middleware/auth');

const logger = new Logger('PumpRoutes');

function createPumpRoutes(db, mqtt) {
  const router = express.Router();

  /**
   * GET /pumps
   * Get all pumps
   */
  router.get('/', verifyToken, async (req, res) => {
    try {
      const pumps = await db.all(
        `SELECT id, device_id, name, is_active, is_running, runtime_seconds, 
                total_runtime_seconds, last_run, created_at 
         FROM pumps ORDER BY name`
      );
      res.json({ success: true, pumps });
    } catch (error) {
      logger.error('Failed to fetch pumps', { error: error.message });
      res.status(500).json({ error: 'Failed to fetch pumps' });
    }
  });

  /**
   * EMERGENCY STOP ALL PUMPS
   * Immediately sends stop command to all running pumps
   */
  router.post('/emergency-stop', verifyToken, requireOperator, async (req, res) => {
    try {
      const activePumps = await db.all('SELECT id, device_id FROM pumps WHERE is_running = 1');
      
      for (const pump of activePumps) {
        if (mqtt.isConnected) {
          await mqtt.publish(`smartfarm/pump/${pump.device_id}/command`, { action: 'stop', reason: 'EMERGENCY' }, 1);
        }
        await db.run('UPDATE pumps SET is_running = 0 WHERE id = ?', [pump.id]);
        await db.run(
          'INSERT INTO pump_history (pump_id, action, reason) VALUES (?, ?, ?)',
          [pump.id, 'stop', 'EMERGENCY_STOP']
        );
      }

      logger.warn('EMERGENCY STOP TRIGGERED', { user: req.user.username, count: activePumps.length });
      res.json({ success: true, message: 'All pumps stopped immediately' });
    } catch (error) {
      logger.error('Emergency stop failed', { error: error.message });
      res.status(500).json({ error: 'Emergency stop failed' });
    }
  });

  /**
   * POST /pumps/:id/start
   * Start pump with Advanced Logic (Rain Skip)
   */
  router.post('/:id/start', verifyToken, requireOperator, async (req, res) => {
    try {
      const { duration_seconds = 300, skip_if_rain = true } = req.body;
      const pump = await db.get('SELECT * FROM pumps WHERE id = ?', [req.params.id]);
      
      if (!pump) return res.status(404).json({ error: 'Pump not found' });

      // Rain Protection Logic
      if (skip_if_rain) {
        const rainSensor = await db.get("SELECT last_value FROM sensors WHERE sensor_type = 'rain' AND is_active = 1");
        if (rainSensor && rainSensor.last_value > 0) {
          logger.info('Watering skipped: Rain detected', { pumpId: pump.id });
          return res.json({ success: false, code: 'RAIN_SKIP', message: 'Rain detected, watering skipped' });
        }
      }

      // Update DB and send MQTT
      await db.run('UPDATE pumps SET is_running = 1, runtime_seconds = ?, last_run = CURRENT_TIMESTAMP WHERE id = ?', [duration_seconds, pump.id]);
      if (mqtt.isConnected) {
        await mqtt.publish(`smartfarm/pump/${pump.device_id}/command`, { action: 'start', duration: duration_seconds }, 1);
      }

      await db.run('INSERT INTO pump_history (pump_id, action, runtime_seconds, reason) VALUES (?, ?, ?, ?)', [pump.id, 'start', duration_seconds, 'Manual Start']);
      
      res.json({ success: true, message: 'Pump started' });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  /**
   * POST /pumps/:id/stop
   */
  router.post('/:id/stop', verifyToken, requireOperator, async (req, res) => {
    try {
      const pump = await db.get('SELECT * FROM pumps WHERE id = ?', [req.params.id]);
      if (!pump) return res.status(404).json({ error: 'Pump not found' });

      await db.run('UPDATE pumps SET is_running = 0 WHERE id = ?', [pump.id]);
      if (mqtt.isConnected) {
        await mqtt.publish(`smartfarm/pump/${pump.device_id}/command`, { action: 'stop' }, 1);
      }
      await db.run('INSERT INTO pump_history (pump_id, action, reason) VALUES (?, ?, ?)', [pump.id, 'stop', 'Manual Stop']);

      res.json({ success: true, message: 'Pump stopped' });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // Keep existing routes for CRUD...
  router.get('/:id', verifyToken, async (req, res) => {
    const pump = await db.get('SELECT * FROM pumps WHERE id = ?', [req.params.id]);
    res.json({ success: true, pump });
  });

  router.get('/:id/history', verifyToken, async (req, res) => {
    const history = await db.all('SELECT * FROM pump_history WHERE pump_id = ? ORDER BY timestamp DESC LIMIT 100', [req.params.id]);
    res.json({ success: true, history });
  });

  return router;
}

module.exports = createPumpRoutes;
