/**
 * SmartFarm V14 Premium - Auth Routes
 * IMPROVED: Added refresh token endpoint, input validation, better security
 */

'use strict';

const express = require('express');
const jwt = require('jsonwebtoken');
const bcryptjs = require('bcryptjs');
const { body, validationResult } = require('express-validator');
const Logger = require('../utils/logger');
const { verifyToken, verifyRefreshToken } = require('../middleware/auth');

const logger = new Logger('Auth-Route');

const SALT_ROUNDS = 12;

function createAuthRoutes(db) {
  const router = express.Router();

  // Validation schemas
  const loginValidation = [
    body('username').trim().notEmpty().withMessage('Username is required').isLength({ max: 50 }),
    body('password').notEmpty().withMessage('Password is required').isLength({ max: 128 })
  ];

  const registerValidation = [
    body('username').trim().notEmpty().isLength({ min: 3, max: 50 })
      .matches(/^[a-zA-Z0-9_]+$/).withMessage('Username must be alphanumeric'),
    body('email').optional().isEmail().normalizeEmail(),
    body('password').isLength({ min: 8, max: 128 })
      .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
      .withMessage('Password must contain uppercase, lowercase, and number'),
    body('full_name').optional().trim().isLength({ max: 100 })
  ];

  /**
   * POST /api/auth/login
   */
  router.post('/login', loginValidation, async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ error: 'Validation failed', details: errors.array() });
    }

    try {
      const { username, password } = req.body;

      const user = await db.get(
        'SELECT id, username, email, password_hash, role, full_name, is_active FROM users WHERE username = ?',
        [username]
      );

      if (!user || !user.is_active) {
        logger.warn('Login failed - user not found or inactive', { username });
        return res.status(401).json({ error: 'Invalid credentials', code: 'INVALID_CREDENTIALS' });
      }

      const passwordMatch = await bcryptjs.compare(password, user.password_hash);
      if (!passwordMatch) {
        logger.warn('Login failed - wrong password', { username });
        return res.status(401).json({ error: 'Invalid credentials', code: 'INVALID_CREDENTIALS' });
      }

      const tokenPayload = {
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role
      };

      const accessToken = jwt.sign(tokenPayload, process.env.JWT_SECRET, {
        expiresIn: process.env.JWT_EXPIRY || '7d'
      });

      const refreshToken = jwt.sign(
        { id: user.id, type: 'refresh' },
        process.env.JWT_REFRESH_SECRET || process.env.JWT_SECRET,
        { expiresIn: process.env.JWT_REFRESH_EXPIRY || '30d' }
      );

      // Store session
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + 7);

      await db.run(
        `INSERT INTO sessions (user_id, token, refresh_token, ip_address, user_agent, expires_at)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [user.id, accessToken, refreshToken, req.ip, req.get('user-agent'), expiresAt.toISOString()]
      );

      await db.run(
        'UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?',
        [user.id]
      );

      logger.info('User logged in', { userId: user.id, username: user.username });

      res.json({
        success: true,
        token: accessToken,
        refreshToken,
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          role: user.role,
          full_name: user.full_name
        }
      });
    } catch (error) {
      logger.error('Login error', { error: error.message });
      res.status(500).json({ error: 'Login failed', code: 'LOGIN_FAILED' });
    }
  });

  /**
   * POST /api/auth/refresh
   * Refresh access token using refresh token
   */
  router.post('/refresh', verifyRefreshToken, async (req, res) => {
    try {
      const session = await db.get(
        'SELECT * FROM sessions WHERE user_id = ? AND refresh_token = ? AND expires_at > CURRENT_TIMESTAMP',
        [req.user.id, req.refreshToken]
      );

      if (!session) {
        return res.status(401).json({ error: 'Invalid or expired refresh token', code: 'REFRESH_TOKEN_INVALID' });
      }

      const user = await db.get(
        'SELECT id, username, email, role, is_active FROM users WHERE id = ?',
        [req.user.id]
      );

      if (!user || !user.is_active) {
        return res.status(401).json({ error: 'User not found or inactive', code: 'USER_INACTIVE' });
      }

      const newAccessToken = jwt.sign(
        { id: user.id, username: user.username, email: user.email, role: user.role },
        process.env.JWT_SECRET,
        { expiresIn: process.env.JWT_EXPIRY || '7d' }
      );

      // Update session with new access token
      await db.run(
        'UPDATE sessions SET token = ? WHERE id = ?',
        [newAccessToken, session.id]
      );

      logger.info('Token refreshed', { userId: user.id });

      res.json({
        success: true,
        token: newAccessToken
      });
    } catch (error) {
      logger.error('Token refresh error', { error: error.message });
      res.status(500).json({ error: 'Token refresh failed', code: 'REFRESH_FAILED' });
    }
  });

  /**
   * POST /api/auth/logout
   */
  router.post('/logout', verifyToken, async (req, res) => {
    try {
      const token = req.headers.authorization?.split(' ')[1];
      if (token) {
        await db.run('DELETE FROM sessions WHERE token = ?', [token]);
      }
      logger.info('User logged out', { userId: req.user.id });
      res.json({ success: true, message: 'Logged out successfully' });
    } catch (error) {
      logger.error('Logout error', { error: error.message });
      res.status(500).json({ error: 'Logout failed', code: 'LOGOUT_FAILED' });
    }
  });

  /**
   * POST /api/auth/logout-all
   * Logout from all sessions
   */
  router.post('/logout-all', verifyToken, async (req, res) => {
    try {
      await db.run('DELETE FROM sessions WHERE user_id = ?', [req.user.id]);
      logger.info('User logged out from all sessions', { userId: req.user.id });
      res.json({ success: true, message: 'Logged out from all sessions' });
    } catch (error) {
      logger.error('Logout-all error', { error: error.message });
      res.status(500).json({ error: 'Logout failed', code: 'LOGOUT_FAILED' });
    }
  });

  /**
   * GET /api/auth/profile
   */
  router.get('/profile', verifyToken, async (req, res) => {
    try {
      const user = await db.get(
        'SELECT id, username, email, role, full_name, last_login, created_at FROM users WHERE id = ?',
        [req.user.id]
      );
      if (!user) {
        return res.status(404).json({ error: 'User not found', code: 'USER_NOT_FOUND' });
      }
      res.json({ success: true, user });
    } catch (error) {
      logger.error('Profile fetch error', { error: error.message });
      res.status(500).json({ error: 'Failed to fetch profile', code: 'FETCH_FAILED' });
    }
  });

  /**
   * PUT /api/auth/profile
   */
  router.put('/profile', verifyToken, [
    body('full_name').optional().trim().isLength({ max: 100 }),
    body('email').optional().isEmail().normalizeEmail()
  ], async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ error: 'Validation failed', details: errors.array() });
    }

    try {
      const { full_name, email } = req.body;

      // Check email uniqueness
      if (email) {
        const existing = await db.get(
          'SELECT id FROM users WHERE email = ? AND id != ?',
          [email, req.user.id]
        );
        if (existing) {
          return res.status(409).json({ error: 'Email already in use', code: 'EMAIL_CONFLICT' });
        }
      }

      await db.run(
        'UPDATE users SET full_name = COALESCE(?, full_name), email = COALESCE(?, email), updated_at = CURRENT_TIMESTAMP WHERE id = ?',
        [full_name || null, email || null, req.user.id]
      );

      logger.info('User profile updated', { userId: req.user.id });
      res.json({ success: true, message: 'Profile updated successfully' });
    } catch (error) {
      logger.error('Profile update error', { error: error.message });
      res.status(500).json({ error: 'Failed to update profile', code: 'UPDATE_FAILED' });
    }
  });

  /**
   * POST /api/auth/change-password
   */
  router.post('/change-password', verifyToken, [
    body('currentPassword').notEmpty().withMessage('Current password is required'),
    body('newPassword').isLength({ min: 8, max: 128 })
      .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
      .withMessage('New password must contain uppercase, lowercase, and number')
  ], async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ error: 'Validation failed', details: errors.array() });
    }

    try {
      const { currentPassword, newPassword } = req.body;

      const user = await db.get(
        'SELECT password_hash FROM users WHERE id = ?',
        [req.user.id]
      );

      if (!user) {
        return res.status(404).json({ error: 'User not found', code: 'USER_NOT_FOUND' });
      }

      const passwordMatch = await bcryptjs.compare(currentPassword, user.password_hash);
      if (!passwordMatch) {
        return res.status(401).json({ error: 'Current password is incorrect', code: 'WRONG_PASSWORD' });
      }

      const hashedPassword = await bcryptjs.hash(newPassword, SALT_ROUNDS);
      await db.run(
        'UPDATE users SET password_hash = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
        [hashedPassword, req.user.id]
      );

      // Invalidate all sessions except current
      const currentToken = req.headers.authorization?.split(' ')[1];
      await db.run(
        'DELETE FROM sessions WHERE user_id = ? AND token != ?',
        [req.user.id, currentToken]
      );

      logger.info('User password changed', { userId: req.user.id });
      res.json({ success: true, message: 'Password changed successfully' });
    } catch (error) {
      logger.error('Password change error', { error: error.message });
      res.status(500).json({ error: 'Failed to change password', code: 'CHANGE_FAILED' });
    }
  });

  /**
   * GET /api/auth/sessions
   */
  router.get('/sessions', verifyToken, async (req, res) => {
    try {
      const sessions = await db.all(
        `SELECT id, ip_address, user_agent, created_at, expires_at
         FROM sessions WHERE user_id = ? ORDER BY created_at DESC`,
        [req.user.id]
      );
      res.json({ success: true, sessions });
    } catch (error) {
      logger.error('Sessions fetch error', { error: error.message });
      res.status(500).json({ error: 'Failed to fetch sessions', code: 'FETCH_FAILED' });
    }
  });

  /**
   * DELETE /api/auth/sessions/:sessionId
   */
  router.delete('/sessions/:sessionId', verifyToken, async (req, res) => {
    try {
      const { sessionId } = req.params;
      if (!/^\d+$/.test(sessionId)) {
        return res.status(400).json({ error: 'Invalid session ID', code: 'INVALID_ID' });
      }

      await db.run(
        'DELETE FROM sessions WHERE id = ? AND user_id = ?',
        [sessionId, req.user.id]
      );

      logger.info('Session terminated', { userId: req.user.id, sessionId });
      res.json({ success: true, message: 'Session terminated' });
    } catch (error) {
      logger.error('Session termination error', { error: error.message });
      res.status(500).json({ error: 'Failed to terminate session', code: 'TERMINATE_FAILED' });
    }
  });

  return router;
}

module.exports = createAuthRoutes;
