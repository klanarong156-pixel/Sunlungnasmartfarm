/**
 * Analytics Service
 * Handles data aggregation for sensors and pump statistics
 */

const Logger = require('../utils/logger');
const logger = new Logger('Analytics-Service');

class AnalyticsService {
  constructor(db) {
    this.db = db;
  }

  /**
   * Get sensor statistics for a specific period
   */
  async getSensorStats(sensorId, days = 7) {
    try {
      const query = `
        SELECT 
          DATE(timestamp) as date,
          AVG(value) as avg_value,
          MIN(value) as min_value,
          MAX(value) as max_value
        FROM sensor_history
        WHERE sensor_id = ? AND timestamp >= date('now', ?)
        GROUP BY DATE(timestamp)
        ORDER BY date ASC
      `;
      return await this.db.all(query, [sensorId, `-${days} days`]);
    } catch (error) {
      logger.error('Failed to fetch sensor stats', { error: error.message });
      throw error;
    }
  }

  /**
   * Get pump runtime statistics
   */
  async getPumpStats(pumpId, days = 30) {
    try {
      const query = `
        SELECT 
          DATE(timestamp) as date,
          SUM(runtime_seconds) as total_runtime,
          COUNT(*) as start_count
        FROM pump_history
        WHERE pump_id = ? AND timestamp >= date('now', ?)
        GROUP BY DATE(timestamp)
        ORDER BY date ASC
      `;
      return await this.db.all(query, [pumpId, `-${days} days`]);
    } catch (error) {
      logger.error('Failed to fetch pump stats', { error: error.message });
      throw error;
    }
  }

  /**
   * Get overall farm summary
   */
  async getFarmSummary() {
    try {
      const stats = {
        total_runtime_today: await this.db.get("SELECT SUM(runtime_seconds) as total FROM pump_history WHERE DATE(timestamp) = DATE('now')"),
        avg_soil_moisture: await this.db.get("SELECT AVG(last_value) as avg FROM sensors WHERE sensor_type = 'soil_moisture'"),
        active_alerts: await this.db.get("SELECT COUNT(*) as count FROM notifications WHERE is_read = 0 AND type = 'error'"),
        system_uptime: process.uptime()
      };
      return stats;
    } catch (error) {
      logger.error('Failed to fetch farm summary', { error: error.message });
      throw error;
    }
  }
}

module.exports = AnalyticsService;
