/**
 * Backup and Restore Service
 * Handles database backups and data migration
 */

const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');
const Logger = require('../utils/logger');
const logger = new Logger('Backup-Service');

class BackupService {
  constructor(db) {
    this.db = db;
    this.backupDir = path.join(__dirname, '../../backups');
    
    if (!fs.existsSync(this.backupDir)) {
      fs.mkdirSync(this.backupDir, { recursive: true });
    }
  }

  /**
   * Create a full database backup
   */
  async createBackup(userId, type = 'manual') {
    return new Promise((resolve, reject) => {
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const fileName = `smartfarm_backup_${timestamp}.sql`;
      const filePath = path.join(this.backupDir, fileName);
      const dbPath = process.env.DB_PATH || './data/smartfarm.db';

      // Use sqlite3 CLI to dump database
      exec(`sqlite3 ${dbPath} .dump > ${filePath}`, async (error) => {
        if (error) {
          logger.error('Backup failed', { error: error.message });
          return reject(error);
        }

        try {
          const stats = fs.statSync(filePath);
          const query = `
            INSERT INTO backups (file_name, file_path, file_size, backup_type, created_by)
            VALUES (?, ?, ?, ?, ?)
          `;
          
          await this.db.run(query, [fileName, filePath, stats.size, type, userId]);
          
          logger.info('Backup created successfully', { fileName, size: stats.size });
          resolve({ success: true, fileName, size: stats.size });
        } catch (dbError) {
          logger.error('Failed to record backup in database', { error: dbError.message });
          reject(dbError);
        }
      });
    });
  }

  /**
   * Restore database from backup
   */
  async restoreBackup(backupId) {
    const backup = await this.db.get('SELECT * FROM backups WHERE id = ?', [backupId]);
    if (!backup) throw new Error('Backup not found');

    return new Promise((resolve, reject) => {
      const dbPath = process.env.DB_PATH || './data/smartfarm.db';
      
      // Caution: This replaces the current database
      exec(`sqlite3 ${dbPath} < ${backup.file_path}`, (error) => {
        if (error) {
          logger.error('Restore failed', { error: error.message });
          return reject(error);
        }
        
        logger.info('Database restored successfully', { backupId });
        resolve({ success: true });
      });
    });
  }

  /**
   * List available backups
   */
  async listBackups() {
    return await this.db.all('SELECT * FROM backups ORDER BY created_at DESC');
  }

  /**
   * Delete a backup file
   */
  async deleteBackup(backupId) {
    const backup = await this.db.get('SELECT * FROM backups WHERE id = ?', [backupId]);
    if (!backup) throw new Error('Backup not found');

    if (fs.existsSync(backup.file_path)) {
      fs.unlinkSync(backup.file_path);
    }

    await this.db.run('DELETE FROM backups WHERE id = ?', [backupId]);
    logger.info('Backup deleted', { backupId });
    return { success: true };
  }
}

module.exports = BackupService;
