/**
 * OTA (Over-The-Air) Update Service
 * Manages firmware versions and device updates
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const Logger = require('../utils/logger');
const logger = new Logger('OTA-Service');

class OTAService {
  constructor(db, mqtt) {
    this.db = db;
    this.mqtt = mqtt;
    this.firmwareDir = path.join(__dirname, '../../uploads/firmware');
    
    // Ensure firmware directory exists
    if (!fs.existsSync(this.firmwareDir)) {
      fs.mkdirSync(this.firmwareDir, { recursive: true });
    }
  }

  /**
   * Upload new firmware version
   */
  async uploadFirmware(version, file, description) {
    try {
      const checksum = this.calculateChecksum(file.path);
      const destPath = path.join(this.firmwareDir, `${version}.bin`);
      
      // Move file to firmware directory
      fs.renameSync(file.path, destPath);

      const query = `
        INSERT INTO firmware (version, file_path, checksum, release_notes)
        VALUES (?, ?, ?, ?)
      `;
      
      await this.db.run(query, [version, destPath, checksum, description]);
      logger.info('Firmware uploaded', { version, checksum });
      
      return { success: true, version, checksum };
    } catch (error) {
      logger.error('Firmware upload failed', { error: error.message });
      throw error;
    }
  }

  /**
   * Trigger OTA update for a device
   */
  async triggerUpdate(deviceId, firmwareVersion) {
    try {
      const firmware = await this.db.get(
        'SELECT * FROM firmware WHERE version = ?', 
        [firmwareVersion]
      );

      if (!firmware) {
        throw new Error('Firmware version not found');
      }

      // Record update status
      const updateId = await this.db.run(
        'INSERT INTO ota_updates (device_id, firmware_id, status) VALUES (?, ?, ?)',
        [deviceId, firmware.id, 'pending']
      );

      // Send MQTT command to device
      const topic = `smartfarm/device/${deviceId}/ota`;
      const payload = {
        action: 'update',
        version: firmwareVersion,
        url: `${process.env.BASE_URL}/api/ota/download/${firmwareVersion}`,
        checksum: firmware.checksum,
        update_id: updateId
      };

      await this.mqtt.publish(topic, payload, 1);
      
      logger.info('OTA update triggered', { deviceId, version: firmwareVersion });
      return { success: true, updateId };
    } catch (error) {
      logger.error('Failed to trigger OTA update', { error: error.message });
      throw error;
    }
  }

  /**
   * Update OTA status from device
   */
  async updateStatus(updateId, status, error = null) {
    try {
      await this.db.run(
        'UPDATE ota_updates SET status = ?, error_message = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
        [status, error, updateId]
      );
      
      if (status === 'completed') {
        // Get update info to update device table
        const update = await this.db.get('SELECT * FROM ota_updates WHERE id = ?', [updateId]);
        const firmware = await this.db.get('SELECT version FROM firmware WHERE id = ?', [update.firmware_id]);
        
        await this.db.run(
          'UPDATE devices SET firmware_version = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
          [firmware.version, update.device_id]
        );
      }
      
      logger.info('OTA status updated', { updateId, status });
    } catch (error) {
      logger.error('Failed to update OTA status', { error: error.message });
    }
  }

  calculateChecksum(filePath) {
    const fileBuffer = fs.readFileSync(filePath);
    const hashSum = crypto.createHash('sha256');
    hashSum.update(fileBuffer);
    return hashSum.digest('hex');
  }
}

module.exports = OTAService;
