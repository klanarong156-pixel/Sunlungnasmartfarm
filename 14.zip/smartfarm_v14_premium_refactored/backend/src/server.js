/**
 * SmartFarm V14 Premium Enterprise - Main Server
 * Production-grade Node.js/Express server with WebSocket, MQTT Bridge, and full middleware stack
 * IMPROVED: Added compression, WebSocket, health check, proper rate limiting, graceful shutdown
 */

'use strict';

require('dotenv').config();

const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const path = require('path');
const compression = require('compression');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');

const Logger = require('./utils/logger');
const Database = require('./database/init');
const MQTTClient = require('./mqtt/client');
const { verifyToken, requestLogger, errorHandler } = require('./middleware/auth');
const createAuditLogMiddleware = require('./middleware/auditLog');
const OTAService = require('./services/ota');
const BackupService = require('./services/backup');

const createAuthRoutes = require('./routes/auth');
const createSensorRoutes = require('./routes/sensors');
const createPumpRoutes = require('./routes/pumps');
const createScheduleRoutes = require('./routes/schedules');
const createWeatherRoutes = require('./routes/weather');
const createSettingsRoutes = require('./routes/settings');
const createAdminRoutes = require('./routes/admin');

const logger = new Logger('Server');

class SmartFarmServer {
  constructor() {
    this.app = express();
    this.server = null;
    this.wss = null;
    this.db = null;
    this.mqtt = null;
    this.wsClients = new Set();
  }

  async initialize() {
    try {
      logger.info('Initializing SmartFarm Backend Server V14 Premium');

      // 1. Database
      const dbPath = process.env.DB_PATH || path.join(__dirname, '../data/smartfarm.db');
      this.db = new Database(dbPath);
      await this.db.initialize();

      // 2. MQTT Client
      this.mqtt = new MQTTClient(
        process.env.MQTT_BROKER || 'mqtt://localhost:1883',
        {
          clientId: process.env.MQTT_CLIENT_ID || `smartfarm_server_${Date.now()}`,
          username: process.env.MQTT_USERNAME,
          password: process.env.MQTT_PASSWORD,
          topicPrefix: process.env.MQTT_TOPIC_PREFIX || 'smartfarm'
        }
      );

      // 3. Services
      this.otaService = new OTAService(this.db, this.mqtt);
      this.backupService = new BackupService(this.db);

      // 4. Middleware
      this.setupMiddleware();

      // 5. Routes
      this.setupRoutes();

      // 6. HTTP server (needed for WebSocket)
      this.server = http.createServer(this.app);

      // 7. WebSocket
      this.setupWebSocket();

      // 8. MQTT Bridge
      this.setupMQTTBridge();

      logger.info('Server initialization completed');
    } catch (error) {
      logger.error('Server initialization failed', { error: error.message });
      throw error;
    }
  }

  setupMiddleware() {
    // Security headers
    this.app.use(helmet({
      contentSecurityPolicy: {
        directives: {
          defaultSrc: ["'self'"],
          scriptSrc: ["'self'", "'unsafe-inline'", 'cdn.tailwindcss.com', 'cdn.jsdelivr.net'],
          styleSrc: ["'self'", "'unsafe-inline'", 'fonts.googleapis.com'],
          fontSrc: ["'self'", 'fonts.gstatic.com'],
          imgSrc: ["'self'", 'data:', 'blob:', 'openweathermap.org'],
          connectSrc: ["'self'", 'ws:', 'wss:']
        }
      },
      crossOriginEmbedderPolicy: false
    }));

    // Compression (gzip/brotli)
    this.app.use(compression({ level: 6, threshold: 1024 }));

    // CORS
    const corsOrigins = (process.env.CORS_ORIGIN || 'http://localhost:3001').split(',');
    this.app.use(cors({
      origin: (origin, callback) => {
        if (!origin || corsOrigins.includes(origin) || corsOrigins.includes('*')) {
          callback(null, true);
        } else {
          callback(new Error('Not allowed by CORS'));
        }
      },
      credentials: true,
      methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
      allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With']
    }));

    // Body parsing
    this.app.use(express.json({ limit: '10mb' }));
    this.app.use(express.urlencoded({ extended: true, limit: '10mb' }));

    // Request logging
    this.app.use(requestLogger);

    // Global rate limiter
    this.app.use('/api/', rateLimit({
      windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS || '900000', 10),
      max: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS || '300', 10),
      standardHeaders: true,
      legacyHeaders: false,
      message: { error: 'Too many requests, please try again later.' }
    }));

    // Serve static frontend
    const frontendPath = path.join(__dirname, '../../frontend');
    this.app.use(express.static(frontendPath, {
      maxAge: process.env.NODE_ENV === 'production' ? '1d' : 0
    }));

    logger.info('Middleware configured');
  }

  setupRoutes() {
    const auditMiddleware = createAuditLogMiddleware(this.db);

    // Auth routes (stricter rate limit)
    const authLimiter = rateLimit({
      windowMs: 15 * 60 * 1000,
      max: 20,
      message: { error: 'Too many authentication attempts.' }
    });
    this.app.use('/api/auth', authLimiter, createAuthRoutes(this.db));

    // Protected API routes
    this.app.use('/api/sensors', verifyToken, auditMiddleware, createSensorRoutes(this.db, this.mqtt));
    this.app.use('/api/pumps', verifyToken, auditMiddleware, createPumpRoutes(this.db, this.mqtt));
    this.app.use('/api/schedules', verifyToken, auditMiddleware, createScheduleRoutes(this.db, this.mqtt));
    this.app.use('/api/weather', verifyToken, createWeatherRoutes(this.db));
    this.app.use('/api/settings', verifyToken, auditMiddleware, createSettingsRoutes(this.db));
    this.app.use('/api/admin', verifyToken, auditMiddleware, createAdminRoutes(this.db, this.otaService, this.backupService));

    // Health check (no auth)
    this.app.get('/api/health', (req, res) => {
      const mem = process.memoryUsage();
      res.json({
        status: 'ok',
        version: '14.0.0',
        uptime: Math.floor(process.uptime()),
        timestamp: new Date().toISOString(),
        environment: process.env.NODE_ENV || 'development',
        memory: {
          heapUsed: Math.round(mem.heapUsed / 1024 / 1024) + 'MB',
          heapTotal: Math.round(mem.heapTotal / 1024 / 1024) + 'MB',
          rss: Math.round(mem.rss / 1024 / 1024) + 'MB'
        },
        services: {
          mqtt: this.mqtt?.isConnected ? 'online' : 'offline',
          database: this.db?.db ? 'online' : 'offline',
          websocket: this.wss ? `${this.wsClients.size} clients` : 'offline'
        }
      });
    });

    // Version endpoint
    this.app.get('/api/version', (req, res) => {
      res.json({
        version: '14.0.0',
        name: 'SmartFarm V14 Premium Enterprise',
        environment: process.env.NODE_ENV || 'development'
      });
    });

    // SPA fallback
    this.app.get('*', (req, res) => {
      if (!req.path.startsWith('/api/')) {
        const indexPath = path.join(__dirname, '../../frontend/index.html');
        res.sendFile(indexPath, (err) => {
          if (err) res.status(404).json({ error: 'Not found' });
        });
      } else {
        res.status(404).json({ error: 'Route not found' });
      }
    });

    // Global error handler
    this.app.use(errorHandler);

    logger.info('Routes configured');
  }

  setupWebSocket() {
    this.wss = new WebSocket.Server({
      server: this.server,
      path: '/ws',
      verifyClient: (info, done) => {
        const url = new URL(info.req.url, `http://${info.req.headers.host}`);
        const token = url.searchParams.get('token') ||
          info.req.headers.authorization?.split(' ')[1];

        if (!token) {
          done(false, 401, 'Unauthorized');
          return;
        }

        try {
          const jwt = require('jsonwebtoken');
          const decoded = jwt.verify(token, process.env.JWT_SECRET);
          info.req.user = decoded;
          done(true);
        } catch (err) {
          done(false, 401, 'Invalid token');
        }
      }
    });

    this.wss.on('connection', (ws, req) => {
      ws.user = req.user;
      ws.isAlive = true;
      this.wsClients.add(ws);

      logger.info('WebSocket client connected', { userId: ws.user?.id });

      ws.send(JSON.stringify({
        type: 'CONNECTED',
        payload: {
          userId: ws.user?.id,
          timestamp: new Date().toISOString(),
          mqttStatus: this.mqtt?.isConnected ? 'online' : 'offline'
        }
      }));

      ws.on('pong', () => { ws.isAlive = true; });
      ws.on('message', (data) => {
        try {
          const message = JSON.parse(data.toString());
          this.handleWebSocketMessage(ws, message);
        } catch (err) {
          logger.warn('Invalid WebSocket message', { error: err.message });
        }
      });
      ws.on('close', () => {
        this.wsClients.delete(ws);
        logger.info('WebSocket client disconnected', { userId: ws.user?.id });
      });
      ws.on('error', (err) => {
        logger.error('WebSocket error', { error: err.message });
        this.wsClients.delete(ws);
      });
    });

    // Heartbeat
    const heartbeatInterval = setInterval(() => {
      this.wss.clients.forEach((ws) => {
        if (!ws.isAlive) { ws.terminate(); this.wsClients.delete(ws); return; }
        ws.isAlive = false;
        ws.ping();
      });
    }, 30000);

    this.wss.on('close', () => clearInterval(heartbeatInterval));
    logger.info('WebSocket server configured');
  }

  handleWebSocketMessage(ws, message) {
    switch (message.type) {
      case 'PING':
        ws.send(JSON.stringify({ type: 'PONG', timestamp: new Date().toISOString() }));
        break;
      case 'SUBSCRIBE':
        ws.subscriptions = message.payload?.topics || [];
        break;
      default:
        logger.debug('Unknown WebSocket message type', { type: message.type });
    }
  }

  broadcast(type, payload, filter = null) {
    const message = JSON.stringify({ type, payload, timestamp: new Date().toISOString() });
    this.wsClients.forEach((ws) => {
      if (ws.readyState === WebSocket.OPEN) {
        if (!filter || filter(ws)) ws.send(message);
      }
    });
  }

  setupMQTTBridge() {
    const prefix = process.env.MQTT_TOPIC_PREFIX || 'smartfarm';

    this.mqtt.on('connected', () => {
      logger.info('MQTT connected, subscribing to topics');
      this.mqtt.subscribe(`${prefix}/sensor/+/+`, 1);
      this.mqtt.subscribe(`${prefix}/pump/+/status`, 1);
      this.mqtt.subscribe(`${prefix}/device/+/status`, 1);
      this.mqtt.subscribe(`${prefix}/heartbeat`, 1);
      this.broadcast('MQTT_STATUS', { connected: true });
    });

    this.mqtt.on('disconnected', () => {
      this.broadcast('MQTT_STATUS', { connected: false });
    });

    this.mqtt.on('message', async (message) => {
      try {
        const { topic, data } = message;
        this.broadcast('MQTT_MESSAGE', { topic, data });

        if (topic.includes('/sensor/')) await this.handleSensorData(topic, data);
        if (topic.includes('/pump/') && topic.includes('/status')) await this.handlePumpStatus(topic, data);
        if (topic.includes('/device/') && topic.includes('/status')) await this.handleDeviceStatus(topic, data);
        if (topic.includes('/heartbeat')) await this.handleHeartbeat(topic, data);
      } catch (error) {
        logger.error('Error handling MQTT message', { error: error.message, topic: message.topic });
      }
    });

    this.mqtt.on('error', (error) => logger.error('MQTT error', { error: error.message }));
    this.mqtt.on('offline', () => {
      logger.warn('MQTT offline');
      this.broadcast('MQTT_STATUS', { connected: false });
    });
  }

  async handleSensorData(topic, data) {
    try {
      const parts = topic.split('/');
      const deviceId = parts[2];
      const sensorType = parts[3];
      if (!deviceId || !sensorType) return;

      const sensor = await this.db.get(
        'SELECT id FROM sensors WHERE device_id = ? AND sensor_type = ?',
        [deviceId, sensorType]
      );

      if (sensor && data.value !== undefined) {
        const value = parseFloat(data.value);
        if (isNaN(value)) return;

        await this.db.run('INSERT INTO sensor_history (sensor_id, value) VALUES (?, ?)', [sensor.id, value]);
        await this.db.run(
          'UPDATE sensors SET last_value = ?, last_update = CURRENT_TIMESTAMP WHERE id = ?',
          [value, sensor.id]
        );
        this.broadcast('SENSOR_UPDATE', { deviceId, sensorType, value, timestamp: new Date().toISOString() });
        logger.debug('Sensor data stored', { deviceId, sensorType, value });
      }
    } catch (error) {
      logger.error('Failed to handle sensor data', { error: error.message });
    }
  }

  async handlePumpStatus(topic, data) {
    try {
      const parts = topic.split('/');
      const deviceId = parts[2];
      if (!deviceId) return;

      const pump = await this.db.get('SELECT id FROM pumps WHERE device_id = ?', [deviceId]);
      if (pump) {
        const updates = [];
        const params = [];

        if (data.is_running !== undefined) {
          updates.push('is_running = ?');
          params.push(data.is_running ? 1 : 0);
        }
        if (data.runtime_seconds !== undefined) {
          updates.push('runtime_seconds = ?', 'total_runtime_seconds = total_runtime_seconds + ?');
          params.push(data.runtime_seconds, data.runtime_seconds);
        }

        if (updates.length > 0) {
          updates.push('updated_at = CURRENT_TIMESTAMP');
          params.push(pump.id);
          await this.db.run(`UPDATE pumps SET ${updates.join(', ')} WHERE id = ?`, params);
        }

        this.broadcast('PUMP_UPDATE', { deviceId, status: data, timestamp: new Date().toISOString() });
        logger.debug('Pump status updated', { deviceId, status: data });
      }
    } catch (error) {
      logger.error('Failed to handle pump status', { error: error.message });
    }
  }

  async handleDeviceStatus(topic, data) {
    try {
      const parts = topic.split('/');
      const deviceId = parts[2];
      logger.debug('Device status received', { topic, data });

      if (data.error && deviceId) {
        await this.db.run(
          'INSERT INTO notifications (type, title, message) VALUES (?, ?, ?)',
          ['error', 'Device Error', `Device: ${deviceId}, Error: ${data.error}`]
        );
        this.broadcast('NOTIFICATION', { type: 'error', title: 'Device Error', message: `Device ${deviceId}: ${data.error}` });
      }

      if (deviceId) {
        await this.db.run(
          'UPDATE devices SET last_seen = CURRENT_TIMESTAMP WHERE id = ?',
          [deviceId]
        ).catch(() => {});
      }
    } catch (error) {
      logger.error('Failed to handle device status', { error: error.message });
    }
  }

  async handleHeartbeat(topic, data) {
    try {
      if (data.device_id) {
        await this.db.run(
          'UPDATE devices SET last_seen = CURRENT_TIMESTAMP, firmware_version = COALESCE(?, firmware_version) WHERE id = ?',
          [data.version || null, data.device_id]
        ).catch(() => {});

        this.broadcast('HEARTBEAT', {
          deviceId: data.device_id,
          rssi: data.rssi,
          heap: data.heap,
          uptime: data.uptime,
          version: data.version,
          timestamp: new Date().toISOString()
        });
      }
    } catch (error) {
      logger.error('Failed to handle heartbeat', { error: error.message });
    }
  }

  async start() {
    try {
      const port = parseInt(process.env.PORT || '3000', 10);
      const host = process.env.HOST || '0.0.0.0';

      // Connect MQTT (non-blocking)
      this.mqtt.connect().catch((error) => {
        logger.warn('MQTT connection failed, continuing without MQTT', { error: error.message });
      });

      // Start HTTP + WebSocket server
      this.server.listen(port, host, () => {
        logger.info('Server started', {
          host,
          port,
          env: process.env.NODE_ENV || 'development',
          websocket: `ws://${host}:${port}/ws`
        });
      });

      // Graceful shutdown handlers
      process.on('SIGTERM', () => this.shutdown('SIGTERM'));
      process.on('SIGINT', () => this.shutdown('SIGINT'));
      process.on('uncaughtException', (err) => {
        logger.error('Uncaught exception', { error: err.message, stack: err.stack });
        this.shutdown('uncaughtException');
      });
      process.on('unhandledRejection', (reason) => {
        logger.error('Unhandled rejection', { reason: String(reason) });
      });
    } catch (error) {
      logger.error('Failed to start server', { error: error.message });
      throw error;
    }
  }

  async shutdown(signal = 'SIGTERM') {
    logger.info('Shutting down server', { signal });
    try {
      if (this.wss) {
        this.wss.clients.forEach((ws) => ws.terminate());
        this.wss.close();
      }
      if (this.server) {
        await new Promise((resolve) => this.server.close(resolve));
      }
      if (this.mqtt) {
        await this.mqtt.disconnect().catch(() => {});
      }
      if (this.db) {
        await this.db.close();
      }
      logger.info('Server shutdown completed');
      process.exit(0);
    } catch (error) {
      logger.error('Error during shutdown', { error: error.message });
      process.exit(1);
    }
  }
}

if (require.main === module) {
  const server = new SmartFarmServer();
  server.initialize()
    .then(() => server.start())
    .catch((error) => {
      logger.error('Fatal error during initialization', { error: error.message, stack: error.stack });
      process.exit(1);
    });
}

module.exports = SmartFarmServer;
