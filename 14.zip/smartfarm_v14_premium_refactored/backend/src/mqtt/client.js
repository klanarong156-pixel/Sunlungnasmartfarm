/**
 * MQTT Client Module
 * Handles MQTT broker connection, auto-reconnect, offline queue, and message handling
 */

const mqtt = require('mqtt');
const EventEmitter = require('events');
const Logger = require('../utils/logger');

const logger = new Logger('MQTT');

class MQTTClient extends EventEmitter {
  constructor(brokerUrl, options = {}) {
    super();
    this.brokerUrl = brokerUrl;
    this.client = null;
    this.isConnected = false;
    this.offlineQueue = [];
    this.subscriptions = new Map();
    this.reconnectAttempts = 0;
    this.maxReconnectAttempts = options.maxReconnectAttempts || 10;
    this.reconnectDelay = options.reconnectDelay || 5000;
    this.heartbeatInterval = options.heartbeatInterval || 30000;
    this.heartbeatTimer = null;

    this.options = {
      clientId: options.clientId || `smartfarm_${Date.now()}`,
      username: options.username,
      password: options.password,
      clean: true,
      reconnectPeriod: this.reconnectDelay,
      qos: options.qos || 1,
      will: {
        topic: `${options.topicPrefix || 'smartfarm'}/status`,
        payload: JSON.stringify({ status: 'offline', timestamp: new Date().toISOString() }),
        qos: 1,
        retain: true
      }
    };
  }

  /**
   * Connect to MQTT broker
   */
  async connect() {
    return new Promise((resolve, reject) => {
      try {
        logger.info('Connecting to MQTT broker', { broker: this.brokerUrl });

        this.client = mqtt.connect(this.brokerUrl, this.options);

        this.client.on('connect', () => {
          this.isConnected = true;
          this.reconnectAttempts = 0;
          logger.info('Connected to MQTT broker');
          this.emit('connected');
          this.startHeartbeat();
          this.processOfflineQueue();
          resolve();
        });

        this.client.on('disconnect', () => {
          this.isConnected = false;
          logger.warn('Disconnected from MQTT broker');
          this.emit('disconnected');
          this.stopHeartbeat();
        });

        this.client.on('message', (topic, message) => {
          this.handleMessage(topic, message);
        });

        this.client.on('error', (error) => {
          logger.error('MQTT error', { error: error.message });
          this.emit('error', error);
        });

        this.client.on('offline', () => {
          logger.warn('MQTT client offline');
          this.emit('offline');
        });

        setTimeout(() => {
          if (!this.isConnected) {
            reject(new Error('MQTT connection timeout'));
          }
        }, 10000);
      } catch (error) {
        logger.error('Failed to connect to MQTT broker', { error: error.message });
        reject(error);
      }
    });
  }

  /**
   * Handle incoming MQTT messages
   */
  handleMessage(topic, message) {
    try {
      const payload = message.toString();
      logger.debug('MQTT message received', { topic, payload: payload.substring(0, 100) });

      let data;
      try {
        data = JSON.parse(payload);
      } catch (e) {
        data = payload;
      }

      this.emit('message', { topic, data, timestamp: new Date().toISOString() });
    } catch (error) {
      logger.error('Error handling MQTT message', { error: error.message, topic });
    }
  }

  /**
   * Subscribe to topic
   */
  subscribe(topic, qos = 1) {
    return new Promise((resolve, reject) => {
      if (!this.isConnected) {
        this.offlineQueue.push({ action: 'subscribe', topic, qos });
        logger.warn('MQTT offline, queued subscription', { topic });
        resolve();
        return;
      }

      this.client.subscribe(topic, { qos }, (error) => {
        if (error) {
          logger.error('Failed to subscribe', { topic, error: error.message });
          reject(error);
        } else {
          this.subscriptions.set(topic, qos);
          logger.info('Subscribed to topic', { topic, qos });
          resolve();
        }
      });
    });
  }

  /**
   * Unsubscribe from topic
   */
  unsubscribe(topic) {
    return new Promise((resolve, reject) => {
      if (!this.isConnected) {
        logger.warn('MQTT offline, cannot unsubscribe', { topic });
        resolve();
        return;
      }

      this.client.unsubscribe(topic, (error) => {
        if (error) {
          logger.error('Failed to unsubscribe', { topic, error: error.message });
          reject(error);
        } else {
          this.subscriptions.delete(topic);
          logger.info('Unsubscribed from topic', { topic });
          resolve();
        }
      });
    });
  }

  /**
   * Publish message
   */
  publish(topic, message, qos = 1, retain = false) {
    return new Promise((resolve, reject) => {
      const payload = typeof message === 'string' ? message : JSON.stringify(message);

      if (!this.isConnected) {
        this.offlineQueue.push({ action: 'publish', topic, message: payload, qos, retain });
        logger.warn('MQTT offline, queued publish', { topic });
        resolve();
        return;
      }

      this.client.publish(topic, payload, { qos, retain }, (error) => {
        if (error) {
          logger.error('Failed to publish', { topic, error: error.message });
          reject(error);
        } else {
          logger.debug('Message published', { topic, qos, retain });
          resolve();
        }
      });
    });
  }

  /**
   * Process offline queue when reconnected
   */
  processOfflineQueue() {
    while (this.offlineQueue.length > 0) {
      const item = this.offlineQueue.shift();
      
      if (item.action === 'publish') {
        this.publish(item.topic, item.message, item.qos, item.retain)
          .catch(error => logger.error('Failed to process queued publish', { error: error.message }));
      } else if (item.action === 'subscribe') {
        this.subscribe(item.topic, item.qos)
          .catch(error => logger.error('Failed to process queued subscribe', { error: error.message }));
      }
    }
  }

  /**
   * Start heartbeat to monitor connection
   */
  startHeartbeat() {
    this.stopHeartbeat();
    
    this.heartbeatTimer = setInterval(() => {
      if (this.isConnected) {
        this.publish('smartfarm/heartbeat', { 
          timestamp: new Date().toISOString(),
          uptime: process.uptime()
        }, 0)
          .catch(error => logger.warn('Heartbeat publish failed', { error: error.message }));
      }
    }, this.heartbeatInterval);
  }

  /**
   * Stop heartbeat
   */
  stopHeartbeat() {
    if (this.heartbeatTimer) {
      clearInterval(this.heartbeatTimer);
      this.heartbeatTimer = null;
    }
  }

  /**
   * Reconnect strategy
   */
  reconnect() {
    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      logger.error('Max reconnection attempts reached');
      this.emit('reconnect_failed');
      return;
    }

    this.reconnectAttempts++;
    logger.info('Attempting to reconnect', { attempt: this.reconnectAttempts });
    
    setTimeout(() => {
      this.connect()
        .catch(error => {
          logger.warn('Reconnection failed', { error: error.message });
          this.reconnect();
        });
    }, this.reconnectDelay * this.reconnectAttempts);
  }

  /**
   * Get connection status
   */
  getStatus() {
    return {
      isConnected: this.isConnected,
      broker: this.brokerUrl,
      clientId: this.options.clientId,
      subscriptions: Array.from(this.subscriptions.keys()),
      offlineQueueSize: this.offlineQueue.length,
      reconnectAttempts: this.reconnectAttempts
    };
  }

  /**
   * Disconnect from broker
   */
  async disconnect() {
    return new Promise((resolve) => {
      this.stopHeartbeat();
      
      if (this.client) {
        this.client.end(false, () => {
          logger.info('Disconnected from MQTT broker');
          this.isConnected = false;
          resolve();
        });
      } else {
        resolve();
      }
    });
  }
}

module.exports = MQTTClient;
