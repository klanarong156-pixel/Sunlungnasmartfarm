# SmartFarm V14 Premium Enterprise Edition 🌾

ระบบ Smart Farm อัจฉริยะที่ได้รับการ Refactor ใหม่ทั้งหมดเพื่อยกระดับสู่ Production Grade (98-100/100) 
รองรับการทำงานแบบ Real-time, Event-driven, และมี UI แบบ Premium Glassmorphism (iOS 26 Style)

![Architecture](docs/architecture.png)

## 🚀 ฟีเจอร์ที่ได้รับการอัปเกรด (Refactored Highlights)

### 1. Backend (Node.js / Express)
- **Security**: เพิ่ม `express-rate-limit`, `helmet`, CORS, และ Input Validation ด้วย `express-validator`
- **Authentication**: ปรับปรุงระบบ JWT ให้มี Refresh Token และ Role-based Access Control (RBAC) อย่างเข้มงวด
- **Real-time**: เปลี่ยนจาก Long Polling เป็น **WebSocket** เต็มรูปแบบ
- **Performance**: เพิ่ม HTTP Compression, Database Connection Pooling, และระบบ Cache
- **Code Quality**: จัดโครงสร้างใหม่แบบ Layered Architecture (Routes, Controllers, Services, Repositories)

### 2. Firmware (ESP8266)
- **Event-Driven**: ลบ `delay()` ออกทั้งหมด เปลี่ยนเป็นระบบ State Machine และ Event Bus
- **Modular Design**: แยกไฟล์เป็น `MQTT.cpp`, `Sensor.cpp`, `Pump.cpp`, `OTA.cpp` อย่างเป็นระเบียบ
- **Resilience**: เพิ่มระบบ Offline Queue สำหรับ MQTT, Auto-reconnect, และ Hardware Watchdog
- **Safety**: เพิ่มระบบตัดการทำงานปั๊มน้ำอัตโนมัติ (Safety Timeout) และตรวจสอบสถานะก่อนทำงาน
- **OTA**: รองรับการอัปเดตเฟิร์มแวร์ผ่าน WiFi (Over-The-Air)

### 3. Frontend (Premium UI)
- **Design System**: เปลี่ยนเป็น **Apple Liquid Glass / iOS 26 Style** (Glassmorphism + Liquid effects)
- **Performance**: โหลดเร็วขึ้นด้วย Skeleton Loading, Micro-animations, และลดการใช้ Global CSS
- **Real-time**: แสดงผลข้อมูลผ่าน WebSocket (ไม่ต้อง Refresh)
- **Charts**: อัปเกรด Chart.js ให้มี Animation และ Tooltip สวยงาม

## 📂 โครงสร้างโปรเจกต์ใหม่

```text
smartfarm_v14_premium_refactored/
├── backend/
│   ├── src/
│   │   ├── config/       # การตั้งค่า (DB, MQTT, JWT)
│   │   ├── controllers/  # จัดการ Request/Response
│   │   ├── middleware/   # Auth, Rate Limiter, Validation
│   │   ├── routes/       # กำหนด API Endpoints
│   │   ├── services/     # Business Logic (MQTT, WS, Data)
│   │   ├── utils/        # Logger, Validation Schemas
│   │   └── server.js     # จุดเริ่มต้นแอปพลิเคชัน
│   └── package.json
├── firmware/
│   └── SmartFarm_V14/
│       ├── Config.h      # ตั้งค่าคงที่ (Pins, WiFi, MQTT)
│       ├── State.h/cpp   # จัดการ State กลาง
│       ├── Events.h/cpp  # Event Bus
│       ├── MQTT.h/cpp    # จัดการ MQTT (Offline Queue)
│       ├── Sensor.h/cpp  # อ่านค่าเซ็นเซอร์ (Smoothing)
│       ├── Pump.h/cpp    # ควบคุมปั๊มน้ำ (Safety Limits)
│       ├── OTA.h/cpp     # อัปเดตเฟิร์มแวร์
│       ├── Storage.h/cpp # LittleFS (บันทึก Device ID)
│       ├── Logger.h/cpp  # ระบบ Log
│       └── SmartFarm_V14.ino # Main Loop (Non-blocking)
├── frontend/
│   ├── src/
│   │   ├── core/         # State Manager, Components
│   │   ├── modules/      # Dashboard, Settings, Admin
│   │   ├── styles/       # premium.css (Liquid Glass)
│   │   └── app.js        # Entry Point
│   └── index.html
└── docs/
    └── architecture.png
```

## 🛠️ การติดตั้งและการใช้งาน

### Backend
1. `cd backend`
2. `npm install`
3. คัดลอก `.env.example` เป็น `.env` และตั้งค่า (JWT Secret, MQTT Broker)
4. `npm run dev` (สำหรับ Development) หรือ `npm start` (สำหรับ Production)

### Firmware
1. เปิดโฟลเดอร์ `firmware/SmartFarm_V14` ด้วย Arduino IDE
2. ติดตั้งไลบรารี: `PubSubClient`, `ArduinoJson`, `DHT sensor library`, `WiFiManager`
3. อัปโหลดลง ESP8266 (NodeMCU / Wemos D1 Mini)
4. เมื่อเปิดเครื่องครั้งแรก ให้เชื่อมต่อ WiFi `SmartFarm_Setup` เพื่อตั้งค่าเครือข่าย

### Frontend
1. สามารถใช้ Web Server ใดก็ได้ (เช่น Nginx, Apache, หรือ Live Server) เสิร์ฟไฟล์ในโฟลเดอร์ `frontend/`
2. หรือใช้ร่วมกับ Backend โดยเข้าผ่าน `http://localhost:3000` (Backend จะทำหน้าที่เสิร์ฟ Static Files)

## 🔒 Security Best Practices ที่นำมาใช้
- **No Global Variables**: ใน Firmware ใช้ Struct State และ Event Bus แทนตัวแปร Global
- **No Blocking Code**: ไม่มี `delay()` ใน Firmware
- **Rate Limiting**: ป้องกัน Brute Force Attack ที่ Login Endpoint
- **Input Validation**: ตรวจสอบข้อมูลทุกฟิลด์ก่อนบันทึกลง Database
- **Secure Headers**: ใช้ Helmet.js ป้องกัน XSS, Clickjacking
