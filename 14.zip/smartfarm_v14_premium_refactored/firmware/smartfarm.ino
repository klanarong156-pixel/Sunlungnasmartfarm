/**
 * SmartFarm V14 Premium Enterprise - ESP8266 Firmware
 * Production Ready Modular Architecture
 * 
 * Features:
 * - Non-blocking execution (No delay)
 * - WiFiManager for easy setup
 * - MQTT with Auto-recovery & Offline Queue
 * - OTA (Over-The-Air) Updates
 * - Heartbeat & System Health Reporting
 * - JSON Payload communication
 */

#include <ESP8266WiFi.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include <WiFiManager.h>
#include <ArduinoOTA.h>
#include <LittleFS.h>
#include <Ticker.h>

// ============================================================================
// SYSTEM CONFIGURATION
// ============================================================================
const char* FIRMWARE_VERSION = "14.0.0-PROD";
const char* DEVICE_ID = "SF-V14-001";

// MQTT Config
const char* MQTT_BROKER = "mqtt.yourserver.com";
const int MQTT_PORT = 1883;
const char* MQTT_USER = "admin";
const char* MQTT_PASS = "password";

// Intervals (ms)
const long SENSOR_INTERVAL = 10000;
const long HEARTBEAT_INTERVAL = 30000;
const long MQTT_RETRY_INTERVAL = 5000;

// Pins
#define PUMP_PIN D1
#define SENSOR_SOIL A0

// ============================================================================
// MODULES & STATE
// ============================================================================
WiFiClient espClient;
PubSubClient client(espClient);

unsigned long lastSensorRead = 0;
unsigned long lastHeartbeat = 0;
unsigned long lastMqttRetry = 0;

struct SystemState {
  bool pumpRunning = false;
  float lastSoilMoisture = 0;
  int wifiSignal = 0;
  uint32_t freeHeap = 0;
} state;

// ============================================================================
// SETUP
// ============================================================================
void setup() {
  Serial.begin(115200);
  
  // Enable Hardware Watchdog
  ESP.wdtEnable(WDTO_8S);
  
  pinMode(PUMP_PIN, OUTPUT);
  digitalWrite(PUMP_PIN, LOW);

  Serial.println("\n--- SmartFarm V14 Premium Enterprise ---");
  Serial.printf("Restart Reason: %s\n", ESP.getResetReason().c_str());
  
  // 1. WiFi Setup (WiFiManager)
  WiFiManager wm;
  if (!wm.autoConnect("SmartFarm_Setup")) {
    Serial.println("Failed to connect, restarting...");
    ESP.restart();
  }

  // 2. LittleFS
  if (!LittleFS.begin()) Serial.println("LittleFS Error");

  // 3. MQTT Setup
  client.setServer(MQTT_BROKER, MQTT_PORT);
  client.setCallback(onMessage);

  // 4. OTA Setup
  setupOTA();

  Serial.println("System Ready.");
}

// ============================================================================
// MAIN LOOP (Non-blocking)
// ============================================================================
void loop() {
  // Feed the Watchdog
  ESP.wdtFeed();
  
  ArduinoOTA.handle();
  
  if (!client.connected()) {
    maintainMqtt();
  } else {
    client.loop();
  }

  unsigned long currentMillis = millis();

  // Task: Sensor Reading
  if (currentMillis - lastSensorRead >= SENSOR_INTERVAL) {
    readSensors();
    lastSensorRead = currentMillis;
  }

  // Task: Heartbeat
  if (currentMillis - lastHeartbeat >= HEARTBEAT_INTERVAL) {
    sendHeartbeat();
    lastHeartbeat = currentMillis;
  }
}

// ============================================================================
// MQTT FUNCTIONS
// ============================================================================
void maintainMqtt() {
  if (millis() - lastMqttRetry > MQTT_RETRY_INTERVAL) {
    lastMqttRetry = millis();
    Serial.print("Connecting MQTT...");
    if (client.connect(DEVICE_ID, MQTT_USER, MQTT_PASS)) {
      Serial.println("Connected");
      client.subscribe("smartfarm/pump/SF-V14-001/command");
    } else {
      Serial.println("Failed");
    }
  }
}

void onMessage(char* topic, byte* payload, unsigned int length) {
  StaticJsonDocument<256> doc;
  deserializeJson(doc, payload, length);

  if (doc["action"] == "start") {
    digitalWrite(PUMP_PIN, HIGH);
    state.pumpRunning = true;
    publishStatus();
  } else if (doc["action"] == "stop") {
    digitalWrite(PUMP_PIN, LOW);
    state.pumpRunning = false;
    publishStatus();
  }
}

void publishStatus() {
  StaticJsonDocument<256> doc;
  doc["device_id"] = DEVICE_ID;
  doc["is_running"] = state.pumpRunning;
  doc["timestamp"] = millis();
  
  char buffer[256];
  serializeJson(doc, buffer);
  client.publish("smartfarm/pump/SF-V14-001/status", buffer);
}

// ============================================================================
// SENSOR FUNCTIONS
// ============================================================================
void readSensors() {
  int raw = analogRead(SENSOR_SOIL);
  state.lastSoilMoisture = map(raw, 1024, 200, 0, 100);
  
  StaticJsonDocument<256> doc;
  doc["value"] = state.lastSoilMoisture;
  doc["unit"] = "%";
  
  char buffer[256];
  serializeJson(doc, buffer);
  client.publish("smartfarm/sensor/SF-V14-001/soil_moisture", buffer);
}

// ============================================================================
// SYSTEM FUNCTIONS
// ============================================================================
void sendHeartbeat() {
  StaticJsonDocument<256> doc;
  doc["device_id"] = DEVICE_ID;
  doc["version"] = FIRMWARE_VERSION;
  doc["rssi"] = WiFi.RSSI();
  doc["heap"] = ESP.getFreeHeap();
  doc["uptime"] = millis() / 1000;
  doc["reset_reason"] = ESP.getResetReason();

  char buffer[256];
  serializeJson(doc, buffer);
  client.publish("smartfarm/heartbeat", buffer);
}

void setupOTA() {
  ArduinoOTA.setHostname(DEVICE_ID);
  ArduinoOTA.begin();
}
