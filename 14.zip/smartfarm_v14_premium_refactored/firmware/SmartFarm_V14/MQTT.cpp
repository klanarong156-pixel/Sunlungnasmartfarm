/**
 * SmartFarm V14 Premium - MQTT.cpp
 * Event-driven MQTT with auto-reconnect, offline queue, Last Will
 */

#include "MQTT.h"
#include "Logger.h"

MQTTManager mqttManager;

MQTTManager::MQTTManager() : _client(_wifiClient) {}

void MQTTManager::begin(const String& deviceId) {
  _deviceId = deviceId;
  _client.setServer(MQTT_BROKER, MQTT_PORT);
  _client.setBufferSize(MQTT_BUFFER_SIZE);
  _client.setKeepAlive(MQTT_KEEPALIVE);

  // Set callback
  _client.setCallback([this](char* topic, byte* payload, unsigned int length) {
    this->handleCallback(topic, payload, length);
  });

  Logger::info("MQTT", "Initialized for device: " + deviceId);
}

void MQTTManager::loop() {
  AppState& state = getState();

  if (!_client.connected()) {
    state.network.mqttConnected = false;
    unsigned long now = millis();
    if (now - state.network.lastMqttRetryMs >= MQTT_RECONNECT_INTERVAL) {
      state.network.lastMqttRetryMs = now;
      if (state.network.mqttRetries < MQTT_MAX_RETRIES) {
        connect();
      } else {
        Logger::error("MQTT", "Max retries reached, giving up");
      }
    }
  } else {
    state.network.mqttConnected = true;
    state.network.mqttRetries = 0;
    _client.loop();
    processOfflineQueue();
  }
}

void MQTTManager::connect() {
  AppState& state = getState();
  state.network.mqttRetries++;

  Logger::info("MQTT", "Connecting... attempt " + String(state.network.mqttRetries));

  // Last Will: announce offline
  String willTopic = String(TOPIC_DEVICE_STATUS) + "/" + _deviceId + "/status";
  StaticJsonDocument<128> willDoc;
  willDoc["status"] = "offline";
  willDoc["device_id"] = _deviceId;
  String willPayload;
  serializeJson(willDoc, willPayload);

  bool connected = _client.connect(
    _deviceId.c_str(),
    MQTT_USER,
    MQTT_PASS,
    willTopic.c_str(),
    MQTT_QOS,
    true,  // retain last will
    willPayload.c_str()
  );

  if (connected) {
    Logger::info("MQTT", "Connected to broker");
    state.network.mqttConnected = true;
    state.network.mqttRetries = 0;

    // Publish online status
    StaticJsonDocument<128> onlineDoc;
    onlineDoc["status"] = "online";
    onlineDoc["device_id"] = _deviceId;
    onlineDoc["version"] = FIRMWARE_VERSION;
    publishRaw(willTopic, onlineDoc.as<String>(), true);

    resubscribeAll();
  } else {
    Logger::warn("MQTT", "Connection failed, rc=" + String(_client.state()));
  }
}

void MQTTManager::resubscribeAll() {
  for (uint8_t i = 0; i < _topicCount; i++) {
    _client.subscribe(_subscribedTopics[i].c_str(), MQTT_QOS);
    Logger::debug("MQTT", "Resubscribed: " + _subscribedTopics[i]);
  }
}

void MQTTManager::processOfflineQueue() {
  while (_queueSize > 0) {
    QueuedMessage& msg = _offlineQueue[_queueHead];
    if (_client.publish(msg.topic.c_str(), msg.payload.c_str(), msg.retain)) {
      _queueHead = (_queueHead + 1) % 16;
      _queueSize--;
      Logger::debug("MQTT", "Queued message sent: " + msg.topic);
    } else {
      break; // Stop if publish fails
    }
  }
}

bool MQTTManager::publish(const String& topic, const JsonDocument& doc, bool retain) {
  String payload;
  serializeJson(doc, payload);
  return publishRaw(topic, payload, retain);
}

bool MQTTManager::publishRaw(const String& topic, const String& payload, bool retain) {
  if (!_client.connected()) {
    // Queue message for later
    if (_queueSize < 16) {
      _offlineQueue[_queueTail] = { topic, payload, retain };
      _queueTail = (_queueTail + 1) % 16;
      _queueSize++;
      Logger::debug("MQTT", "Message queued (offline): " + topic);
    } else {
      Logger::warn("MQTT", "Offline queue full, dropping message: " + topic);
    }
    return false;
  }

  bool result = _client.publish(topic.c_str(), payload.c_str(), retain);
  if (!result) {
    Logger::warn("MQTT", "Publish failed: " + topic);
  }
  return result;
}

bool MQTTManager::subscribe(const String& topic, uint8_t qos) {
  if (_topicCount < 8) {
    _subscribedTopics[_topicCount++] = topic;
  }

  if (_client.connected()) {
    bool result = _client.subscribe(topic.c_str(), qos);
    Logger::info("MQTT", "Subscribed: " + topic);
    return result;
  }
  return false;
}

void MQTTManager::onMessage(MQTTMessageCallback callback) {
  _messageCallback = callback;
}

bool MQTTManager::isConnected() const {
  return _client.connected();
}

uint8_t MQTTManager::getRetryCount() const {
  return getState().network.mqttRetries;
}

void MQTTManager::handleCallback(char* topic, byte* payload, unsigned int length) {
  String topicStr(topic);
  Logger::debug("MQTT", "Message received: " + topicStr);

  StaticJsonDocument<JSON_BUFFER_SIZE> doc;
  DeserializationError err = deserializeJson(doc, payload, length);

  if (err) {
    Logger::warn("MQTT", "JSON parse error: " + String(err.c_str()));
    return;
  }

  if (_messageCallback) {
    _messageCallback(topicStr, doc);
  }
}
