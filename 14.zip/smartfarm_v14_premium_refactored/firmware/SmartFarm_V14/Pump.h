/**
 * SmartFarm V14 Premium - Pump.h
 * Pump control with safety limits and event-driven architecture
 */

#pragma once
#include <Arduino.h>
#include "Config.h"
#include "State.h"

typedef std::function<void(bool isRunning, unsigned long runtimeMs)> PumpStatusCallback;

class PumpController {
public:
  void begin(uint8_t pin);
  void loop();

  bool start(uint16_t durationSec = 0, const String& action = "manual");
  bool stop(const String& reason = "manual");
  bool toggle();

  bool isRunning() const;
  unsigned long getRuntimeMs() const;
  unsigned long getTotalRuntimeMs() const;

  void onStatusChange(PumpStatusCallback callback);

private:
  uint8_t _pin = PIN_PUMP;
  uint16_t _maxDurationSec = 0;
  PumpStatusCallback _statusCallback;

  void setRelay(bool on);
  bool isSafeToStart() const;
};

extern PumpController pumpController;
