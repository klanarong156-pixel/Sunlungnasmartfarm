/**
 * SmartFarm V14 Premium - State.cpp
 */

#include "State.h"
#include "Config.h"

static AppState appState;

AppState& getState() {
  return appState;
}

void resetState() {
  appState = AppState();
}
