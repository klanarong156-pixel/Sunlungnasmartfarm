/**
 * SmartFarm V14 Premium - Logger.h
 * Structured logging to Serial and LittleFS
 */

#pragma once
#include <Arduino.h>

enum LogLevel {
  LOG_DEBUG = 0,
  LOG_INFO  = 1,
  LOG_WARN  = 2,
  LOG_ERROR = 3
};

class Logger {
public:
  static void begin(LogLevel minLevel = LOG_INFO);
  static void debug(const String& module, const String& message);
  static void info(const String& module, const String& message);
  static void warn(const String& module, const String& message);
  static void error(const String& module, const String& message);

private:
  static void log(LogLevel level, const String& module, const String& message);
  static String levelToString(LogLevel level);
  static LogLevel _minLevel;
};
