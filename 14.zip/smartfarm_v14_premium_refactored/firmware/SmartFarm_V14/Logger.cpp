/**
 * SmartFarm V14 Premium - Logger.cpp
 */

#include "Logger.h"
#include "Config.h"
#include <LittleFS.h>

LogLevel Logger::_minLevel = LOG_INFO;

void Logger::begin(LogLevel minLevel) {
  _minLevel = minLevel;
}

void Logger::debug(const String& module, const String& message) {
  log(LOG_DEBUG, module, message);
}

void Logger::info(const String& module, const String& message) {
  log(LOG_INFO, module, message);
}

void Logger::warn(const String& module, const String& message) {
  log(LOG_WARN, module, message);
}

void Logger::error(const String& module, const String& message) {
  log(LOG_ERROR, module, message);
}

void Logger::log(LogLevel level, const String& module, const String& message) {
  if (level < _minLevel) return;

  String entry = "[" + String(millis()) + "] [" + levelToString(level) + "] [" + module + "] " + message;
  Serial.println(entry);

  // Write to LittleFS log file (only WARN and above to save flash)
  if (level >= LOG_WARN && LittleFS.begin()) {
    String logPath = String(STORAGE_LOG_DIR) + "system.log";
    File logFile = LittleFS.open(logPath, "a");
    if (logFile) {
      logFile.println(entry);
      logFile.close();
    }
  }
}

String Logger::levelToString(LogLevel level) {
  switch (level) {
    case LOG_DEBUG: return "DEBUG";
    case LOG_INFO:  return "INFO";
    case LOG_WARN:  return "WARN";
    case LOG_ERROR: return "ERROR";
    default:        return "UNKNOWN";
  }
}
