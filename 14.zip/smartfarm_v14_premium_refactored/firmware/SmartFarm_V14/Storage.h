/**
 * SmartFarm V14 Premium - Storage.h
 * LittleFS-based persistent storage
 */

#pragma once
#include <Arduino.h>

class StorageManager {
public:
  bool begin();
  String readFile(const String& path);
  bool writeFile(const String& path, const String& content);
  bool appendFile(const String& path, const String& content);
  bool deleteFile(const String& path);
  bool exists(const String& path);
  String getDeviceId();
  bool saveDeviceId(const String& id);
};

extern StorageManager storageManager;
