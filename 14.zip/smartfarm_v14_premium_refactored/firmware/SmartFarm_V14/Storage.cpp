/**
 * SmartFarm V14 Premium - Storage.cpp
 */

#include "Storage.h"
#include "Logger.h"
#include "Config.h"
#include <LittleFS.h>
#include <ESP8266WiFi.h>

StorageManager storageManager;

bool StorageManager::begin() {
  if (!LittleFS.begin()) {
    Logger::error("Storage", "LittleFS mount failed, formatting...");
    LittleFS.format();
    if (!LittleFS.begin()) {
      Logger::error("Storage", "LittleFS format failed");
      return false;
    }
  }

  // Create directories
  if (!LittleFS.exists("/config")) LittleFS.mkdir("/config");
  if (!LittleFS.exists("/logs"))   LittleFS.mkdir("/logs");

  Logger::info("Storage", "LittleFS ready");
  return true;
}

String StorageManager::readFile(const String& path) {
  if (!LittleFS.exists(path)) return "";
  File f = LittleFS.open(path, "r");
  if (!f) return "";
  String content = f.readString();
  f.close();
  return content;
}

bool StorageManager::writeFile(const String& path, const String& content) {
  File f = LittleFS.open(path, "w");
  if (!f) {
    Logger::error("Storage", "Cannot open for write: " + path);
    return false;
  }
  f.print(content);
  f.close();
  return true;
}

bool StorageManager::appendFile(const String& path, const String& content) {
  File f = LittleFS.open(path, "a");
  if (!f) return false;
  f.println(content);
  f.close();
  return true;
}

bool StorageManager::deleteFile(const String& path) {
  return LittleFS.remove(path);
}

bool StorageManager::exists(const String& path) {
  return LittleFS.exists(path);
}

String StorageManager::getDeviceId() {
  String id = readFile(STORAGE_DEVICE_ID);
  id.trim();
  if (id.isEmpty()) {
    // Generate from MAC address
    id = "SF-V14-" + WiFi.macAddress();
    id.replace(":", "");
    saveDeviceId(id);
  }
  return id;
}

bool StorageManager::saveDeviceId(const String& id) {
  return writeFile(STORAGE_DEVICE_ID, id);
}
