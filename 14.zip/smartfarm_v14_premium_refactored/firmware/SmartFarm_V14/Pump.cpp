/**
 * SmartFarm V14 Premium - Pump.cpp
 * Non-blocking pump control with safety limits
 */

#include "Pump.h"
#include "Logger.h"

PumpController pumpController;

void PumpController::begin(uint8_t pin) {
  _pin = pin;
  pinMode(_pin, OUTPUT);
  setRelay(false);
  Logger::info("Pump", "Initialized on pin " + String(_pin));
}

void PumpController::loop() {
  PumpState& pump = getState().pump;

  if (!pump.isRunning) return;

  unsigned long now = millis();
  pump.runtimeMs = now - pump.startMs;

  // Safety: auto-stop if max duration exceeded
  bool timeoutReached = (_maxDurationSec > 0) &&
    (pump.runtimeMs >= (unsigned long)_maxDurationSec * 1000UL);
  bool safetyReached = pump.runtimeMs >= PUMP_SAFETY_TIMEOUT_MS;

  if (timeoutReached || safetyReached) {
    String reason = safetyReached ? "safety_timeout" : "duration_complete";
    stop(reason);
  }
}

bool PumpController::start(uint16_t durationSec, const String& action) {
  if (!isSafeToStart()) {
    Logger::warn("Pump", "Cannot start - safety check failed");
    return false;
  }

  PumpState& pump = getState().pump;
  _maxDurationSec = durationSec;
  pump.isRunning = true;
  pump.startMs = millis();
  pump.runtimeMs = 0;
  pump.lastAction = action;

  setRelay(true);
  Logger::info("Pump", "Started - action=" + action + " duration=" + String(durationSec) + "s");

  if (_statusCallback) {
    _statusCallback(true, 0);
  }
  return true;
}

bool PumpController::stop(const String& reason) {
  PumpState& pump = getState().pump;

  if (!pump.isRunning) return false;

  unsigned long runtime = millis() - pump.startMs;
  pump.isRunning = false;
  pump.runtimeMs = runtime;
  pump.totalRuntimeMs += runtime;
  pump.lastStopMs = millis();
  pump.lastAction = reason;

  setRelay(false);
  Logger::info("Pump", "Stopped - reason=" + reason + " runtime=" + String(runtime / 1000) + "s");

  if (_statusCallback) {
    _statusCallback(false, runtime);
  }
  return true;
}

bool PumpController::toggle() {
  return getState().pump.isRunning ? stop("toggle") : start(0, "toggle");
}

bool PumpController::isRunning() const {
  return getState().pump.isRunning;
}

unsigned long PumpController::getRuntimeMs() const {
  PumpState& pump = getState().pump;
  if (pump.isRunning) {
    return millis() - pump.startMs;
  }
  return pump.runtimeMs;
}

unsigned long PumpController::getTotalRuntimeMs() const {
  return getState().pump.totalRuntimeMs;
}

void PumpController::onStatusChange(PumpStatusCallback callback) {
  _statusCallback = callback;
}

void PumpController::setRelay(bool on) {
  digitalWrite(_pin, on ? HIGH : LOW);
}

bool PumpController::isSafeToStart() const {
  PumpState& pump = getState().pump;

  if (pump.isRunning) return false;

  // Check minimum interval between runs
  if (pump.lastStopMs > 0) {
    unsigned long elapsed = millis() - pump.lastStopMs;
    if (elapsed < (unsigned long)PUMP_MIN_INTERVAL_SEC * 1000UL) {
      Logger::warn("Pump", "Too soon since last run: " + String(elapsed / 1000) + "s");
      return false;
    }
  }

  return true;
}
