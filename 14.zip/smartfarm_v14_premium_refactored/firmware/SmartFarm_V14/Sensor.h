/**
 * SmartFarm V14 Premium - Sensor.h
 * Multi-sensor reading with smoothing and calibration
 */

#pragma once
#include <Arduino.h>
#include "Config.h"
#include "State.h"

typedef std::function<void(const SensorData& data)> SensorReadCallback;

class SensorManager {
public:
  void begin();
  void loop();
  void onReady(SensorReadCallback callback);

  float readSoilMoisture();
  bool  readDHT(float& temperature, float& humidity);

private:
  SensorReadCallback _callback;
  unsigned long _lastReadMs = 0;

  // Smoothing buffer
  float _soilBuffer[SOIL_SMOOTH_SAMPLES];
  uint8_t _soilBufIdx = 0;
  bool _soilBufFull = false;

  float smoothedSoil();
};

extern SensorManager sensorManager;
