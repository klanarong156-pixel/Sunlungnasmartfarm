/**
 * SmartFarm V14 Premium - MQTT.h
 * Event-driven MQTT module with auto-reconnect, offline queue, Last Will
 */

#pragma once
#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include "Config.h"
#include "State.h"

// Callback type for incoming messages
typedef std::function<void(const String& topic, const JsonDocument& doc)> MQTTMessageCallback;

struct QueuedMessage {
  String topic;
  String payload;
  bool retain;
};

class MQTTManager {
public:
  MQTTManager();
  void begin(const String& deviceId);
  void loop();

  bool publish(const String& topic, const JsonDocument& doc, bool retain = false);
  bool publishRaw(const String& topic, const String& payload, bool retain = false);
  bool subscribe(const String& topic, uint8_t qos = 1);

  void onMessage(MQTTMessageCallback callback);
  bool isConnected() const;
  uint8_t getRetryCount() const;

private:
  WiFiClient _wifiClient;
  PubSubClient _client;
  String _deviceId;
  MQTTMessageCallback _messageCallback;
  QueuedMessage _offlineQueue[16];
  uint8_t _queueHead = 0;
  uint8_t _queueTail = 0;
  uint8_t _queueSize = 0;

  void connect();
  void resubscribeAll();
  void processOfflineQueue();
  void handleCallback(char* topic, byte* payload, unsigned int length);
  void publishLastWill();

  String _subscribedTopics[8];
  uint8_t _topicCount = 0;
};

extern MQTTManager mqttManager;
