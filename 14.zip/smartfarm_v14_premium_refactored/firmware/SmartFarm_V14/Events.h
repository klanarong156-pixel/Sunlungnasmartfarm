/**
 * SmartFarm V14 Premium - Events.h
 * Simple event bus for decoupled module communication
 */

#pragma once
#include <Arduino.h>
#include <functional>

enum EventType {
  EVT_SENSOR_READY,
  EVT_PUMP_STARTED,
  EVT_PUMP_STOPPED,
  EVT_MQTT_CONNECTED,
  EVT_MQTT_DISCONNECTED,
  EVT_MQTT_MESSAGE,
  EVT_WIFI_CONNECTED,
  EVT_WIFI_DISCONNECTED,
  EVT_OTA_START,
  EVT_OTA_END,
  EVT_SCHEDULE_TRIGGER,
  EVT_HEARTBEAT
};

struct Event {
  EventType type;
  String    payload;
  unsigned long timestamp;
};

typedef std::function<void(const Event&)> EventHandler;

class EventBus {
public:
  void subscribe(EventType type, EventHandler handler);
  void publish(EventType type, const String& payload = "");
  void clear();

private:
  struct Subscription {
    EventType type;
    EventHandler handler;
  };
  static const uint8_t MAX_SUBS = 32;
  Subscription _subs[MAX_SUBS];
  uint8_t _subCount = 0;
};

extern EventBus eventBus;
