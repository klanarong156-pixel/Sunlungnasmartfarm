/**
 * SmartFarm V14 Premium - Config.h
 * Centralized configuration constants
 */

#pragma once

// ============================================================
// FIRMWARE VERSION
// ============================================================
#define FIRMWARE_VERSION    "14.0.0-PROD"
#define FIRMWARE_BUILD      __DATE__ " " __TIME__

// ============================================================
// HARDWARE PINS
// ============================================================
#define PIN_PUMP            D1      // Relay for pump control
#define PIN_SENSOR_SOIL     A0      // Soil moisture sensor (analog)
#define PIN_LED_STATUS      D4      // Built-in LED (active LOW)
#define PIN_SENSOR_DHT      D2      // DHT22 temperature/humidity

// ============================================================
// WIFI
// ============================================================
#define WIFI_AP_SSID        "SmartFarm_Setup"
#define WIFI_AP_PASSWORD    ""
#define WIFI_CONNECT_TIMEOUT_MS  30000
#define WIFI_RECONNECT_INTERVAL  10000

// ============================================================
// MQTT
// ============================================================
#define MQTT_BROKER         "mqtt.yourserver.com"
#define MQTT_PORT           1883
#define MQTT_USER           "admin"
#define MQTT_PASS           "password"
#define MQTT_QOS            1
#define MQTT_RETAIN         false
#define MQTT_KEEPALIVE      60
#define MQTT_RECONNECT_INTERVAL  5000
#define MQTT_MAX_RETRIES    10

// ============================================================
// MQTT TOPICS (use device_id as prefix)
// ============================================================
#define TOPIC_PREFIX        "smartfarm"
#define TOPIC_SENSOR        TOPIC_PREFIX "/sensor"
#define TOPIC_PUMP_CMD      TOPIC_PREFIX "/pump"
#define TOPIC_PUMP_STATUS   TOPIC_PREFIX "/pump"
#define TOPIC_HEARTBEAT     TOPIC_PREFIX "/heartbeat"
#define TOPIC_DEVICE_STATUS TOPIC_PREFIX "/device"
#define TOPIC_OTA           TOPIC_PREFIX "/ota"

// ============================================================
// TIMING INTERVALS (milliseconds)
// ============================================================
#define INTERVAL_SENSOR_READ    10000   // 10 seconds
#define INTERVAL_HEARTBEAT      30000   // 30 seconds
#define INTERVAL_MQTT_RETRY     5000    // 5 seconds
#define INTERVAL_WIFI_CHECK     15000   // 15 seconds
#define INTERVAL_SCHEDULE_CHECK 60000   // 1 minute

// ============================================================
// SENSOR CALIBRATION
// ============================================================
#define SOIL_ADC_DRY        1024    // ADC value when soil is dry
#define SOIL_ADC_WET        200     // ADC value when soil is wet
#define SOIL_SMOOTH_SAMPLES 5       // Number of samples for smoothing

// ============================================================
// PUMP SAFETY
// ============================================================
#define PUMP_MAX_RUNTIME_SEC    3600    // Max 1 hour continuous run
#define PUMP_MIN_INTERVAL_SEC   300     // Min 5 minutes between runs
#define PUMP_SAFETY_TIMEOUT_MS  3600000 // Auto-stop after 1 hour

// ============================================================
// STORAGE KEYS (LittleFS)
// ============================================================
#define STORAGE_DEVICE_ID   "/config/device_id.txt"
#define STORAGE_SCHEDULE    "/config/schedule.json"
#define STORAGE_SETTINGS    "/config/settings.json"
#define STORAGE_LOG_DIR     "/logs/"

// ============================================================
// WATCHDOG
// ============================================================
#define WDT_TIMEOUT_SEC     8       // Hardware watchdog timeout

// ============================================================
// OTA
// ============================================================
#define OTA_HOSTNAME        "SmartFarm-V14"
#define OTA_PORT            8266
#define OTA_PASSWORD        ""      // Set in production

// ============================================================
// BUFFER SIZES
// ============================================================
#define JSON_BUFFER_SIZE    512
#define MQTT_BUFFER_SIZE    1024
#define LOG_BUFFER_SIZE     256
