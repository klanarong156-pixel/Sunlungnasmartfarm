/**
 * SmartFarm V14 Premium - State.h
 * Centralized system state (no global spaghetti variables)
 */

#pragma once
#include <Arduino.h>

struct SensorData {
  float soilMoisture    = 0.0f;
  float temperature     = 0.0f;
  float humidity        = 0.0f;
  float light           = 0.0f;
  bool  hasTemperature  = false;
  bool  hasHumidity     = false;
  unsigned long lastReadMs = 0;
};

struct PumpState {
  bool  isRunning       = false;
  unsigned long startMs = 0;
  unsigned long runtimeMs = 0;
  unsigned long totalRuntimeMs = 0;
  unsigned long lastStopMs = 0;
  String lastAction     = "";
};

struct NetworkState {
  bool  wifiConnected   = false;
  bool  mqttConnected   = false;
  int   wifiRssi        = 0;
  uint8_t mqttRetries   = 0;
  unsigned long lastMqttRetryMs = 0;
  unsigned long lastWifiCheckMs = 0;
};

struct SystemState {
  String  deviceId      = "";
  String  firmwareVersion = FIRMWARE_VERSION;
  uint32_t freeHeap     = 0;
  unsigned long uptimeMs = 0;
  String  resetReason   = "";
  bool    otaInProgress = false;
};

struct ScheduleEntry {
  bool    active        = false;
  uint8_t hour          = 0;
  uint8_t minute        = 0;
  uint16_t durationSec  = 0;
  bool    triggered     = false;
};

// Global state container (single instance, no scattered globals)
struct AppState {
  SensorData    sensors;
  PumpState     pump;
  NetworkState  network;
  SystemState   system;
  ScheduleEntry schedule[8]; // Up to 8 schedules
  uint8_t       scheduleCount = 0;
};

// Accessor (defined in State.cpp)
AppState& getState();
void resetState();
