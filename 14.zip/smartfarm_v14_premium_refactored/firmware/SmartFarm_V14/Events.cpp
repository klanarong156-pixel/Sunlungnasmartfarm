/**
 * SmartFarm V14 Premium - Events.cpp
 */

#include "Events.h"

EventBus eventBus;

void EventBus::subscribe(EventType type, EventHandler handler) {
  if (_subCount < MAX_SUBS) {
    _subs[_subCount++] = { type, handler };
  }
}

void EventBus::publish(EventType type, const String& payload) {
  Event evt = { type, payload, millis() };
  for (uint8_t i = 0; i < _subCount; i++) {
    if (_subs[i].type == type) {
      _subs[i].handler(evt);
    }
  }
}

void EventBus::clear() {
  _subCount = 0;
}
