/**
 * SmartFarm V14 Premium - OTA.cpp
 */

#include "OTA.h"
#include "Logger.h"
#include "State.h"

OTAManager otaManager;

void OTAManager::begin(const String& hostname) {
  ArduinoOTA.setHostname(hostname.c_str());
  ArduinoOTA.setPort(OTA_PORT);

  if (strlen(OTA_PASSWORD) > 0) {
    ArduinoOTA.setPassword(OTA_PASSWORD);
  }

  ArduinoOTA.onStart([this]() {
    _updating = true;
    getState().system.otaInProgress = true;
    String type = (ArduinoOTA.getCommand() == U_FLASH) ? "firmware" : "filesystem";
    Logger::info("OTA", "Update started: " + type);
  });

  ArduinoOTA.onEnd([this]() {
    _updating = false;
    getState().system.otaInProgress = false;
    Logger::info("OTA", "Update completed, restarting...");
  });

  ArduinoOTA.onProgress([](unsigned int progress, unsigned int total) {
    static uint8_t lastPct = 0;
    uint8_t pct = (progress * 100) / total;
    if (pct != lastPct && pct % 10 == 0) {
      Logger::debug("OTA", "Progress: " + String(pct) + "%");
      lastPct = pct;
    }
  });

  ArduinoOTA.onError([this](ota_error_t error) {
    _updating = false;
    getState().system.otaInProgress = false;
    String errMsg;
    switch (error) {
      case OTA_AUTH_ERROR:    errMsg = "Auth failed"; break;
      case OTA_BEGIN_ERROR:   errMsg = "Begin failed"; break;
      case OTA_CONNECT_ERROR: errMsg = "Connect failed"; break;
      case OTA_RECEIVE_ERROR: errMsg = "Receive failed"; break;
      case OTA_END_ERROR:     errMsg = "End failed"; break;
      default:                errMsg = "Unknown error";
    }
    Logger::error("OTA", "Error: " + errMsg);
  });

  ArduinoOTA.begin();
  Logger::info("OTA", "Ready on hostname: " + hostname);
}

void OTAManager::loop() {
  ArduinoOTA.handle();
}

bool OTAManager::isUpdating() const {
  return _updating;
}
