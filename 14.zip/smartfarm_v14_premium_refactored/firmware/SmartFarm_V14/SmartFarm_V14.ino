/**
 * ============================================================
 * SmartFarm V14 Premium Enterprise - Main Firmware
 * ============================================================
 * Architecture: Event-driven, modular, non-blocking
 * Platform:     ESP8266 (NodeMCU / Wemos D1 Mini)
 * Version:      14.0.0-PROD
 * 
 * Modules:
 *   Config.h/cpp    - Centralized configuration
 *   State.h/cpp     - System state (no global spaghetti)
 *   Events.h/cpp    - Event bus for decoupled communication
 *   Logger.h/cpp    - Structured logging
 *   Storage.h/cpp   - LittleFS persistent storage
 *   MQTT.h/cpp      - MQTT client with offline queue
 *   Sensor.h/cpp    - Multi-sensor reading with smoothing
 *   Pump.h/cpp      - Pump control with safety limits
 *   OTA.h/cpp       - Over-The-Air firmware update
 * ============================================================
 */

#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <WiFiManager.h>
#include <ArduinoJson.h>

#include "Config.h"
#include "State.h"
#include "Events.h"
#include "Logger.h"
#include "Storage.h"
#include "MQTT.h"
#include "Sensor.h"
#include "Pump.h"
#include "OTA.h"

// ============================================================
// TASK TIMERS (non-blocking millis-based)
// ============================================================
static unsigned long lastHeartbeatMs = 0;
static unsigned long lastWifiCheckMs = 0;

// ============================================================
// FORWARD DECLARATIONS
// ============================================================
void setupWiFi();
void setupMQTT();
void setupEvents();
void publishSensorData(const SensorData& data);
void publishHeartbeat();
void publishPumpStatus(bool isRunning, unsigned long runtimeMs);
void handleMQTTMessage(const String& topic, const JsonDocument& doc);

// ============================================================
// SETUP
// ============================================================
void setup() {
  Serial.begin(115200);
  delay(100);

  // Enable hardware watchdog
  ESP.wdtEnable(WDT_TIMEOUT_SEC * 1000);

  Logger::begin(LOG_INFO);
  Logger::info("Main", "=== SmartFarm V14 Premium ===");
  Logger::info("Main", "Version: " + String(FIRMWARE_VERSION));
  Logger::info("Main", "Reset reason: " + ESP.getResetReason());

  // Initialize storage
  storageManager.begin();

  // Load device ID
  AppState& state = getState();
  state.system.deviceId = storageManager.getDeviceId();
  state.system.resetReason = ESP.getResetReason();
  Logger::info("Main", "Device ID: " + state.system.deviceId);

  // Setup pin modes
  pinMode(PIN_LED_STATUS, OUTPUT);
  digitalWrite(PIN_LED_STATUS, HIGH); // LED off (active LOW)

  // Setup events
  setupEvents();

  // Setup WiFi
  setupWiFi();

  // Setup sensors
  sensorManager.begin();
  sensorManager.onReady([](const SensorData& data) {
    publishSensorData(data);
    eventBus.publish(EVT_SENSOR_READY);
  });

  // Setup pump
  pumpController.begin(PIN_PUMP);
  pumpController.onStatusChange([](bool isRunning, unsigned long runtimeMs) {
    publishPumpStatus(isRunning, runtimeMs);
    eventBus.publish(isRunning ? EVT_PUMP_STARTED : EVT_PUMP_STOPPED);
  });

  // Setup MQTT
  setupMQTT();

  // Setup OTA
  otaManager.begin(OTA_HOSTNAME);

  Logger::info("Main", "System ready.");
  digitalWrite(PIN_LED_STATUS, LOW); // LED on = ready
}

// ============================================================
// MAIN LOOP (non-blocking)
// ============================================================
void loop() {
  // Feed watchdog
  ESP.wdtFeed();

  // Skip all processing during OTA
  if (otaManager.isUpdating()) {
    otaManager.loop();
    return;
  }

  // OTA handle
  otaManager.loop();

  // MQTT handle
  mqttManager.loop();

  // Sensor reading (non-blocking, timer-based)
  sensorManager.loop();

  // Pump safety check (non-blocking)
  pumpController.loop();

  // WiFi monitoring
  unsigned long now = millis();
  if (now - lastWifiCheckMs >= INTERVAL_WIFI_CHECK) {
    lastWifiCheckMs = now;
    AppState& state = getState();
    state.network.wifiConnected = WiFi.isConnected();
    state.network.wifiRssi = WiFi.RSSI();

    if (!state.network.wifiConnected) {
      Logger::warn("Main", "WiFi disconnected, attempting reconnect...");
      WiFi.reconnect();
      eventBus.publish(EVT_WIFI_DISCONNECTED);
    }
  }

  // Heartbeat
  if (now - lastHeartbeatMs >= INTERVAL_HEARTBEAT) {
    lastHeartbeatMs = now;
    publishHeartbeat();
    eventBus.publish(EVT_HEARTBEAT);
  }

  // Update system state
  AppState& state = getState();
  state.system.freeHeap = ESP.getFreeHeap();
  state.system.uptimeMs = millis();
}

// ============================================================
// WIFI SETUP
// ============================================================
void setupWiFi() {
  Logger::info("WiFi", "Starting WiFiManager...");
  WiFiManager wm;
  wm.setConfigPortalTimeout(180);
  wm.setConnectTimeout(30);

  if (!wm.autoConnect(WIFI_AP_SSID, WIFI_AP_PASSWORD)) {
    Logger::error("WiFi", "Failed to connect, restarting...");
    delay(1000);
    ESP.restart();
  }

  getState().network.wifiConnected = true;
  Logger::info("WiFi", "Connected! IP: " + WiFi.localIP().toString());
  eventBus.publish(EVT_WIFI_CONNECTED, WiFi.localIP().toString());
}

// ============================================================
// MQTT SETUP
// ============================================================
void setupMQTT() {
  String deviceId = getState().system.deviceId;
  mqttManager.begin(deviceId);

  // Subscribe to pump command topic
  String pumpCmdTopic = String(TOPIC_PUMP_CMD) + "/" + deviceId + "/command";
  mqttManager.subscribe(pumpCmdTopic);

  // Subscribe to OTA topic
  String otaTopic = String(TOPIC_OTA) + "/" + deviceId + "/update";
  mqttManager.subscribe(otaTopic);

  // Set message handler
  mqttManager.onMessage([](const String& topic, const JsonDocument& doc) {
    handleMQTTMessage(topic, doc);
  });

  Logger::info("MQTT", "Setup complete");
}

// ============================================================
// EVENT SUBSCRIPTIONS
// ============================================================
void setupEvents() {
  eventBus.subscribe(EVT_PUMP_STARTED, [](const Event& evt) {
    Logger::info("Event", "Pump started");
    digitalWrite(PIN_LED_STATUS, HIGH); // LED blink pattern
  });

  eventBus.subscribe(EVT_PUMP_STOPPED, [](const Event& evt) {
    Logger::info("Event", "Pump stopped");
    digitalWrite(PIN_LED_STATUS, LOW);
  });

  eventBus.subscribe(EVT_MQTT_CONNECTED, [](const Event& evt) {
    Logger::info("Event", "MQTT connected");
  });
}

// ============================================================
// MQTT MESSAGE HANDLER
// ============================================================
void handleMQTTMessage(const String& topic, const JsonDocument& doc) {
  String deviceId = getState().system.deviceId;
  String pumpCmdTopic = String(TOPIC_PUMP_CMD) + "/" + deviceId + "/command";

  if (topic == pumpCmdTopic) {
    String action = doc["action"].as<String>();
    uint16_t duration = doc["duration"] | 0;

    Logger::info("MQTT", "Pump command: " + action + " duration=" + String(duration));

    if (action == "start") {
      pumpController.start(duration, "mqtt");
    } else if (action == "stop") {
      pumpController.stop("mqtt");
    } else if (action == "toggle") {
      pumpController.toggle();
    }
  }
}

// ============================================================
// PUBLISH FUNCTIONS
// ============================================================
void publishSensorData(const SensorData& data) {
  String deviceId = getState().system.deviceId;

  // Soil moisture
  StaticJsonDocument<256> soilDoc;
  soilDoc["value"] = round(data.soilMoisture * 10) / 10.0;
  soilDoc["unit"] = "%";
  soilDoc["device_id"] = deviceId;
  soilDoc["timestamp"] = millis();
  mqttManager.publish(String(TOPIC_SENSOR) + "/" + deviceId + "/soil_moisture", soilDoc);

  // Temperature
  if (data.hasTemperature) {
    StaticJsonDocument<256> tempDoc;
    tempDoc["value"] = round(data.temperature * 10) / 10.0;
    tempDoc["unit"] = "C";
    tempDoc["device_id"] = deviceId;
    tempDoc["timestamp"] = millis();
    mqttManager.publish(String(TOPIC_SENSOR) + "/" + deviceId + "/temperature", tempDoc);
  }

  // Humidity
  if (data.hasHumidity) {
    StaticJsonDocument<256> humDoc;
    humDoc["value"] = round(data.humidity * 10) / 10.0;
    humDoc["unit"] = "%";
    humDoc["device_id"] = deviceId;
    humDoc["timestamp"] = millis();
    mqttManager.publish(String(TOPIC_SENSOR) + "/" + deviceId + "/humidity", humDoc);
  }
}

void publishHeartbeat() {
  AppState& state = getState();
  StaticJsonDocument<512> doc;
  doc["device_id"]    = state.system.deviceId;
  doc["version"]      = state.system.firmwareVersion;
  doc["rssi"]         = state.network.wifiRssi;
  doc["heap"]         = state.system.freeHeap;
  doc["uptime"]       = state.system.uptimeMs / 1000;
  doc["reset_reason"] = state.system.resetReason;
  doc["pump_running"] = state.pump.isRunning;
  doc["mqtt_retries"] = state.network.mqttRetries;
  mqttManager.publish(TOPIC_HEARTBEAT, doc);
}

void publishPumpStatus(bool isRunning, unsigned long runtimeMs) {
  AppState& state = getState();
  StaticJsonDocument<256> doc;
  doc["device_id"]       = state.system.deviceId;
  doc["is_running"]      = isRunning;
  doc["runtime_seconds"] = runtimeMs / 1000;
  doc["action"]          = state.pump.lastAction;
  doc["timestamp"]       = millis();
  mqttManager.publish(
    String(TOPIC_PUMP_STATUS) + "/" + state.system.deviceId + "/status",
    doc
  );
}
