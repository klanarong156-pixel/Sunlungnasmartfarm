/**
 * SmartFarm V14 Premium - OTA.h
 * Over-The-Air firmware update module
 */

#pragma once
#include <Arduino.h>
#include <ArduinoOTA.h>

class OTAManager {
public:
  void begin(const String& hostname);
  void loop();
  bool isUpdating() const;

private:
  bool _updating = false;
};

extern OTAManager otaManager;
