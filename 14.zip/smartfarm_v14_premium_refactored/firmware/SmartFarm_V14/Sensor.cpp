/**
 * SmartFarm V14 Premium - Sensor.cpp
 * Non-blocking sensor reading with smoothing
 */

#include "Sensor.h"
#include "Logger.h"
#include <DHT.h>

#define DHT_TYPE DHT22
static DHT dht(PIN_SENSOR_DHT, DHT_TYPE);

SensorManager sensorManager;

void SensorManager::begin() {
  dht.begin();
  memset(_soilBuffer, 0, sizeof(_soilBuffer));
  Logger::info("Sensor", "Initialized (Soil + DHT22)");
}

void SensorManager::loop() {
  unsigned long now = millis();
  if (now - _lastReadMs < INTERVAL_SENSOR_READ) return;
  _lastReadMs = now;

  SensorData& sensors = getState().sensors;

  // Read soil moisture
  sensors.soilMoisture = readSoilMoisture();

  // Read DHT22
  float temp, hum;
  if (readDHT(temp, hum)) {
    sensors.temperature = temp;
    sensors.humidity = hum;
    sensors.hasTemperature = true;
    sensors.hasHumidity = true;
  } else {
    Logger::warn("Sensor", "DHT22 read failed");
  }

  sensors.lastReadMs = now;
  Logger::debug("Sensor", "Soil=" + String(sensors.soilMoisture, 1) +
    "% Temp=" + String(sensors.temperature, 1) +
    "C Hum=" + String(sensors.humidity, 1) + "%");

  if (_callback) {
    _callback(sensors);
  }
}

float SensorManager::readSoilMoisture() {
  int raw = analogRead(PIN_SENSOR_SOIL);
  // Clamp raw value
  raw = constrain(raw, SOIL_ADC_WET, SOIL_ADC_DRY);
  float moisture = map(raw, SOIL_ADC_DRY, SOIL_ADC_WET, 0, 100);
  moisture = constrain(moisture, 0.0f, 100.0f);

  // Add to smoothing buffer
  _soilBuffer[_soilBufIdx] = moisture;
  _soilBufIdx = (_soilBufIdx + 1) % SOIL_SMOOTH_SAMPLES;
  if (_soilBufIdx == 0) _soilBufFull = true;

  return smoothedSoil();
}

float SensorManager::smoothedSoil() {
  uint8_t count = _soilBufFull ? SOIL_SMOOTH_SAMPLES : _soilBufIdx;
  if (count == 0) return 0.0f;

  float sum = 0;
  for (uint8_t i = 0; i < count; i++) {
    sum += _soilBuffer[i];
  }
  return sum / count;
}

bool SensorManager::readDHT(float& temperature, float& humidity) {
  float t = dht.readTemperature();
  float h = dht.readHumidity();

  if (isnan(t) || isnan(h)) return false;

  temperature = t;
  humidity = h;
  return true;
}

void SensorManager::onReady(SensorReadCallback callback) {
  _callback = callback;
}
