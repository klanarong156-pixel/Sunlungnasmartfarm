/**
 * State Management Module
 * Event-driven state management without global variables
 */

class StateManager {
  constructor() {
    this.state = {
      auth: {
        isAuthenticated: false,
        user: null,
        token: null,
        role: null
      },
      sensors: {
        list: [],
        current: null,
        history: {},
        loading: false,
        error: null
      },
      pumps: {
        list: [],
        current: null,
        history: {},
        loading: false,
        error: null
      },
      schedules: {
        list: [],
        current: null,
        loading: false,
        error: null
      },
      weather: {
        current: null,
        forecast: [],
        loading: false,
        error: null,
        lastUpdate: null
      },
      mqtt: {
        connected: false,
        status: 'disconnected',
        subscriptions: []
      },
      ui: {
        theme: 'dark',
        language: 'th',
        sidebarOpen: true,
        notifications: [],
        modals: {}
      },
      system: {
        uptime: 0,
        memory: {},
        database: {},
        loading: false
      }
    };

    this.listeners = new Map();
    this.history = [];
    this.maxHistorySize = 100;
  }

  /**
   * Subscribe to state changes
   */
  subscribe(path, callback) {
    if (!this.listeners.has(path)) {
      this.listeners.set(path, new Set());
    }

    this.listeners.get(path).add(callback);

    // Return unsubscribe function
    return () => {
      this.listeners.get(path).delete(callback);
    };
  }

  /**
   * Emit state change
   */
  emit(path, value) {
    const listeners = this.listeners.get(path);
    if (listeners) {
      listeners.forEach(callback => {
        try {
          callback(value);
        } catch (error) {
          console.error('State listener error:', error);
        }
      });
    }
  }

  /**
   * Get state value
   */
  get(path) {
    const keys = path.split('.');
    let value = this.state;

    for (const key of keys) {
      value = value?.[key];
      if (value === undefined) break;
    }

    return value;
  }

  /**
   * Set state value
   */
  set(path, value) {
    const keys = path.split('.');
    const lastKey = keys.pop();
    let target = this.state;

    for (const key of keys) {
      if (!target[key]) {
        target[key] = {};
      }
      target = target[key];
    }

    const oldValue = target[lastKey];
    target[lastKey] = value;

    // Add to history
    this.addHistory({ path, oldValue, newValue: value, timestamp: Date.now() });

    // Emit change
    this.emit(path, value);

    return value;
  }

  /**
   * Update state object
   */
  update(path, updates) {
    const current = this.get(path);
    const updated = { ...current, ...updates };
    this.set(path, updated);
    return updated;
  }

  /**
   * Add to array in state
   */
  push(path, item) {
    const array = this.get(path) || [];
    const updated = [...array, item];
    this.set(path, updated);
    return updated;
  }

  /**
   * Remove from array in state
   */
  remove(path, predicate) {
    const array = this.get(path) || [];
    const updated = array.filter(item => !predicate(item));
    this.set(path, updated);
    return updated;
  }

  /**
   * Clear state path
   */
  clear(path) {
    this.set(path, null);
  }

  /**
   * Reset to initial state
   */
  reset() {
    this.state = {
      auth: { isAuthenticated: false, user: null, token: null, role: null },
      sensors: { list: [], current: null, history: {}, loading: false, error: null },
      pumps: { list: [], current: null, history: {}, loading: false, error: null },
      schedules: { list: [], current: null, loading: false, error: null },
      weather: { current: null, forecast: [], loading: false, error: null, lastUpdate: null },
      mqtt: { connected: false, status: 'disconnected', subscriptions: [] },
      ui: { theme: 'dark', language: 'th', sidebarOpen: true, notifications: [], modals: {} },
      system: { uptime: 0, memory: {}, database: {}, loading: false }
    };

    this.emit('*', this.state);
  }

  /**
   * Add to history
   */
  addHistory(entry) {
    this.history.push(entry);
    if (this.history.length > this.maxHistorySize) {
      this.history.shift();
    }
  }

  /**
   * Get state history
   */
  getHistory(limit = 10) {
    return this.history.slice(-limit);
  }

  /**
   * Get entire state (for debugging)
   */
  getState() {
    return JSON.parse(JSON.stringify(this.state));
  }

  /**
   * Batch update
   */
  batch(updates) {
    const oldState = JSON.parse(JSON.stringify(this.state));

    for (const [path, value] of Object.entries(updates)) {
      this.set(path, value);
    }

    return { oldState, newState: this.getState() };
  }
}

// Create singleton instance
const stateManager = new StateManager();

export default stateManager;
