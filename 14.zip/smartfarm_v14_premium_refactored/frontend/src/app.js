/**
 * SmartFarm V14 Premium Enterprise
 * Main Application Entry
 */

import state from './core/State.js';
import Dashboard from './modules/Dashboard.js';
import authAPI from './api/auth.js';
import sensorsAPI from './api/sensors.js';
import pumpsAPI from './api/pumps.js';
import weatherAPI from './api/weather.js';

class App {
  constructor() {
    this.root = document.getElementById('root');
    this.modules = {
      dashboard: Dashboard
    };
  }

  async init() {
    console.log('🚀 SmartFarm V14 Premium Initializing...');
    
    // 1. Initialize Core
    state.init();
    
    // 2. Check Auth
    if (!state.get('auth.isAuthenticated')) {
      this.renderLogin();
      return;
    }

    // 3. Render Shell (Header, Sidebar, Content Area)
    this.renderShell();
    
    // 4. Initialize Modules
    this.modules.dashboard.init('main-content');
    
    // 5. Initial Data Load
    await this.loadInitialData();
    
    // 6. Setup Navigation
    document.getElementById('nav-analytics').addEventListener('click', () => {
      import('./modules/Analytics.js').then(m => m.default.init('main-content'));
    });
    document.getElementById('nav-dashboard').addEventListener('click', () => {
      this.modules.dashboard.init('main-content');
    });

    // 7. Emergency Stop Action
    document.getElementById('btn-emergency-stop').addEventListener('click', async () => {
      if (confirm('ยืนยันการหยุดการทำงานของปั๊มน้ำทั้งหมดทันที?')) {
        await pumpsAPI.emergencyStop();
        alert('สั่งหยุดระบบฉุกเฉินเรียบร้อยแล้ว');
      }
    });

    // 8. Setup Global Actions
    window.togglePump = async (id) => {
      try {
        const pump = state.get('pumps.list').find(p => p.id === id);
        if (pump.is_running) {
          await pumpsAPI.stopPump(id);
        } else {
          await pumpsAPI.startPump(id, 300); // Default 5 mins
        }
        await pumpsAPI.getPumps(); // Refresh
      } catch (error) {
        console.error('Failed to toggle pump:', error);
      }
    };
  }

  renderShell() {
    document.body.classList.add('premium-ui');
    if (state.get('ui.theme') === 'dark') document.body.classList.add('dark-mode');

    this.root.innerHTML = `
      <div class="flex h-screen overflow-hidden">
        <!-- Sidebar -->
        <aside class="w-[280px] h-full liquid-glass rounded-none border-r border-gray-100 dark:border-gray-800 z-50">
          <div class="p-8">
            <h1 class="text-2xl font-bold tracking-tight">SmartFarm <span class="text-blue-500">V14</span></h1>
            <p class="text-xs text-gray-400 mt-1 uppercase tracking-widest">Premium Enterprise</p>
          </div>
          <nav class="px-4 space-y-2">
            <a href="#" id="nav-dashboard" class="flex items-center gap-3 px-4 py-3 rounded-2xl bg-blue-500 text-white shadow-lg shadow-blue-500/20">
              <span>📊</span> Dashboard
            </a>
            <a href="#" id="nav-analytics" class="flex items-center gap-3 px-4 py-3 rounded-2xl hover:bg-gray-100 dark:hover:bg-white/5 transition-colors">
              <span>📈</span> Analytics
            </a>
            <a href="#" class="flex items-center gap-3 px-4 py-3 rounded-2xl hover:bg-gray-100 dark:hover:bg-white/5 transition-colors">
              <span>⏰</span> Schedules
            </a>
            <a href="/admin.html" class="flex items-center gap-3 px-4 py-3 rounded-2xl hover:bg-gray-100 dark:hover:bg-white/5 transition-colors">
              <span>⚙️</span> Admin Panel
            </a>
          </nav>

          <div class="mt-auto p-4">
            <button id="btn-emergency-stop" class="w-full py-4 rounded-2xl btn-emergency">
              Emergency Stop
            </button>
          </div>
        </aside>

        <!-- Main Content Area -->
        <div class="flex-1 flex flex-col overflow-hidden">
          <header class="ios-header justify-between">
            <div class="flex items-center gap-4">
              <span class="text-gray-400">/</span>
              <span class="font-medium">Dashboard</span>
            </div>
            <div class="flex items-center gap-6">
              <div id="connection-status" class="flex items-center gap-2 text-xs font-medium px-3 py-1.5 rounded-full bg-green-500/10 text-green-500">
                <span class="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span>
                Connected
              </div>
              <button id="user-profile" class="w-10 h-10 rounded-full bg-gray-200 dark:bg-gray-800 flex items-center justify-center font-bold">
                ${state.get('auth.user')?.username?.charAt(0).toUpperCase() || 'A'}
              </button>
            </div>
          </header>
          <main id="main-content" class="flex-1 overflow-y-auto bg-gray-50/50 dark:bg-black/20">
            <!-- Module content renders here -->
          </main>
        </div>
      </div>
    `;
  }

  async loadInitialData() {
    try {
      const [sensors, pumps, weather] = await Promise.all([
        sensorsAPI.getSensors(),
        pumpsAPI.getPumps(),
        weatherAPI.getCurrentWeather()
      ]);
      
      state.set('sensors.list', sensors);
      state.set('pumps.list', pumps);
      state.set('weather.current', weather);
      state.set('system.mqttStatus', 'online');
      state.set('system.deviceStatus', 'online');
      state.set('system.lastHeartbeat', new Date().toLocaleTimeString());
    } catch (error) {
      console.error('Failed to load initial data:', error);
    }
  }

  renderLogin() {
    // Basic login UI for now, will be upgraded to Premium Login
    this.root.innerHTML = `
      <div class="flex items-center justify-center h-screen bg-gray-100 dark:bg-black">
        <div class="liquid-glass p-10 w-full max-w-md">
          <h2 class="text-3xl font-bold mb-6">Login</h2>
          <form id="login-form" class="space-y-4">
            <input type="text" id="username" placeholder="Username" class="w-full p-4 rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-black/50" required>
            <input type="password" id="password" placeholder="Password" class="w-full p-4 rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-black/50" required>
            <button type="submit" class="w-full py-4 rounded-2xl bg-blue-500 text-white font-bold shadow-lg shadow-blue-500/30">Sign In</button>
          </form>
        </div>
      </div>
    `;

    document.getElementById('login-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const u = document.getElementById('username').value;
      const p = document.getElementById('password').value;
      try {
        await authAPI.login(u, p);
        this.init();
      } catch (err) {
        alert('Login failed');
      }
    });
  }
}

const app = new App();
document.addEventListener('DOMContentLoaded', () => app.init());
