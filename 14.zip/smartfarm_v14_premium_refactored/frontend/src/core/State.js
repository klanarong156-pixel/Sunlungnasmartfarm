/**
 * SmartFarm V14 Premium State Management
 * Event-driven, state-reactive architecture
 */

class State {
  constructor() {
    this.state = {
      user: null,
      auth: {
        isAuthenticated: false,
        token: null,
        loading: false,
        error: null
      },
      sensors: {
        list: [],
        history: {},
        loading: false,
        error: null
      },
      pumps: {
        list: [],
        loading: false,
        error: null
      },
      weather: {
        current: null,
        forecast: [],
        loading: false,
        lastUpdate: null
      },
      ui: {
        theme: 'auto', // light, dark, auto
        sidebarOpen: true,
        activeTab: 'dashboard',
        notifications: []
      },
      system: {
        mqttStatus: 'offline',
        deviceStatus: 'offline',
        lastHeartbeat: null
      }
    };
    
    this.listeners = new Map();
  }

  /**
   * Initialize state from storage
   */
  init() {
    const savedTheme = localStorage.getItem('sf_theme');
    if (savedTheme) this.set('ui.theme', savedTheme);
    
    const savedToken = localStorage.getItem('sf_token');
    if (savedToken) {
      this.set('auth.token', savedToken);
      this.set('auth.isAuthenticated', true);
    }
  }

  /**
   * Get value from state using dot notation
   */
  get(path) {
    return path.split('.').reduce((obj, key) => obj && obj[key], this.state);
  }

  /**
   * Set value in state and notify listeners
   */
  set(path, value) {
    const keys = path.split('.');
    const lastKey = keys.pop();
    const target = keys.reduce((obj, key) => obj[key], this.state);
    
    if (target[lastKey] === value) return;
    
    const oldValue = target[lastKey];
    target[lastKey] = value;
    
    this.notify(path, value, oldValue);
  }

  /**
   * Subscribe to state changes
   */
  subscribe(path, callback) {
    if (!this.listeners.has(path)) {
      this.listeners.set(path, new Set());
    }
    this.listeners.get(path).add(callback);
    
    // Return unsubscribe function
    return () => {
      this.listeners.get(path).delete(callback);
    };
  }

  /**
   * Notify listeners of state changes
   */
  notify(path, newValue, oldValue) {
    // Notify exact path
    if (this.listeners.has(path)) {
      this.listeners.get(path).forEach(callback => callback(newValue, oldValue));
    }
    
    // Notify parent paths
    const keys = path.split('.');
    while (keys.length > 0) {
      const parentPath = keys.join('.');
      if (this.listeners.has(parentPath)) {
        this.listeners.get(parentPath).forEach(callback => callback(this.get(parentPath)));
      }
      keys.pop();
    }
  }

  /**
   * Reset state (e.g., on logout)
   */
  destroy() {
    this.state.auth.isAuthenticated = false;
    this.state.auth.token = null;
    this.state.user = null;
    this.listeners.clear();
  }
}

const stateInstance = new State();
export default stateInstance;
