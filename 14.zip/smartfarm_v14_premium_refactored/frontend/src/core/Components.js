/**
 * SmartFarm V14 Premium - Components.js
 * REWRITE: Premium UI components with Apple Liquid Glass / iOS 26 style
 */

/**
 * Premium Glass Card
 */
export const PremiumCard = ({ title, icon, children, className = '', variant = 'glass' }) => `
  <div class="${variant === 'liquid' ? 'liquid-glass' : 'glass'} ${className}" style="padding: 20px;">
    ${title ? `
      <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 16px;">
        ${icon ? `<span style="font-size: 1.2rem;">${icon}</span>` : ''}
        <h3 style="font-size: 0.95rem; font-weight: 600; margin: 0; color: var(--text-secondary);
                   text-transform: uppercase; letter-spacing: 0.08em;">${title}</h3>
      </div>` : ''}
    ${children}
  </div>`;

/**
 * Animated SVG Gauge
 */
export const AnimatedGauge = (id, value, min = 0, max = 100, unit = '%', color = '#007AFF') => {
  const percentage = Math.min(100, Math.max(0, ((value - min) / (max - min)) * 100));
  const radius = 40;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (percentage / 100) * circumference;

  return `
    <div class="gauge-container" id="gauge-${id}">
      <svg class="gauge-svg" width="100" height="100" viewBox="0 0 100 100">
        <circle class="gauge-track" cx="50" cy="50" r="${radius}" stroke-width="8" transform="rotate(-90 50 50)"/>
        <circle class="gauge-fill" cx="50" cy="50" r="${radius}" stroke-width="8"
          stroke="${color}"
          stroke-dasharray="${circumference}"
          stroke-dashoffset="${offset}"
          transform="rotate(-90 50 50)"
          style="transition: stroke-dashoffset 1.2s cubic-bezier(0.34,1.56,0.64,1);"/>
      </svg>
      <div style="position: absolute; text-align: center;">
        <div class="gauge-value" style="color: ${color};">${value}</div>
        <div class="gauge-label">${unit}</div>
      </div>
    </div>`;
};

/**
 * iOS-style Toggle Switch
 */
export const IOSSwitch = (id, checked = false, onChange = '') => `
  <label class="ios-switch" title="${checked ? 'เปิดอยู่' : 'ปิดอยู่'}">
    <input type="checkbox" id="${id}" ${checked ? 'checked' : ''} ${onChange ? `onchange="${onChange}"` : ''}>
    <span class="ios-slider"></span>
  </label>`;

/**
 * Skeleton Loading
 */
export const Skeleton = (width = '100%', height = '20px', count = 1, borderRadius = '8px') => {
  return Array(count).fill(0).map(() =>
    `<div class="skeleton" style="width: ${width}; height: ${height}; border-radius: ${borderRadius}; margin-bottom: 8px;"></div>`
  ).join('');
};

/**
 * Weather Icon (animated)
 */
export const WeatherIcon = (condition, size = '2rem') => {
  const icons = {
    clear: '☀️', sunny: '☀️', clouds: '☁️', cloudy: '🌤️',
    rain: '🌧️', drizzle: '🌦️', thunderstorm: '⛈️', snow: '❄️',
    mist: '🌫️', fog: '🌫️', default: '🌡️'
  };
  const cond = (condition || '').toLowerCase();
  const icon = Object.keys(icons).find(k => cond.includes(k)) || 'default';
  const animClass = icon.includes('rain') ? 'weather-icon-rain' :
                    icon.includes('cloud') ? 'weather-icon-cloud' : 'weather-icon-sun';
  return `<span class="${animClass}" style="font-size: ${size}; line-height: 1;">${icons[icon]}</span>`;
};

/**
 * KPI Card
 */
export const KPICard = ({ value, label, unit = '', trend = null, color = '#007AFF', icon = '' }) => `
  <div class="liquid-glass kpi-card animate-scale-in">
    <div style="display: flex; align-items: flex-start; justify-content: space-between;">
      <div>
        <div class="kpi-value" style="color: ${color};">${value}<span style="font-size: 1.2rem; font-weight: 500; opacity: 0.7;">${unit}</span></div>
        <div class="kpi-label">${label}</div>
        ${trend !== null ? `
          <div class="kpi-trend ${trend >= 0 ? 'up' : 'down'}" style="margin-top: 8px;">
            ${trend >= 0 ? '↑' : '↓'} ${Math.abs(trend)}%
          </div>` : ''}
      </div>
      ${icon ? `<div style="font-size: 2rem; opacity: 0.6;">${icon}</div>` : ''}
    </div>
  </div>`;

/**
 * MQTT Status Badge
 */
export const MQTTBadge = (connected) => `
  <div class="mqtt-status ${connected ? 'online' : 'offline'}">
    <div class="mqtt-dot"></div>
    <span>MQTT ${connected ? 'Online' : 'Offline'}</span>
  </div>`;

/**
 * Performance Bar
 */
export const PerformanceBar = (value, max = 100, color = '#007AFF', label = '') => {
  const pct = Math.min(100, Math.max(0, (value / max) * 100));
  return `
    <div>
      ${label ? `<div style="display: flex; justify-content: space-between; font-size: 0.8rem; margin-bottom: 6px;">
        <span style="color: var(--text-secondary);">${label}</span>
        <span style="font-weight: 600;">${value}</span>
      </div>` : ''}
      <div class="performance-bar">
        <div class="performance-bar-fill" style="width: ${pct}%; background: linear-gradient(90deg, ${color}, ${color}aa);"></div>
      </div>
    </div>`;
};

/**
 * Toast Notification
 */
export const showToast = (message, type = 'info', duration = 3000) => {
  const colors = {
    success: '#34C759', error: '#FF3B30', warning: '#FF9F0A', info: '#007AFF'
  };
  const icons = { success: '✅', error: '❌', warning: '⚠️', info: 'ℹ️' };

  const toast = document.createElement('div');
  toast.style.cssText = `
    position: fixed; bottom: 24px; right: 24px; z-index: 9999;
    background: rgba(28,28,30,0.95); backdrop-filter: blur(20px);
    border: 1px solid rgba(255,255,255,0.1); border-radius: 14px;
    padding: 12px 20px; display: flex; align-items: center; gap: 10px;
    color: white; font-size: 0.9rem; font-weight: 500;
    box-shadow: 0 8px 32px rgba(0,0,0,0.4);
    animation: slideUp 0.3s cubic-bezier(0.34,1.56,0.64,1) both;
    border-left: 3px solid ${colors[type]};
  `;
  toast.innerHTML = `<span>${icons[type]}</span><span>${message}</span>`;
  document.body.appendChild(toast);

  setTimeout(() => {
    toast.style.animation = 'fadeIn 0.2s ease reverse both';
    setTimeout(() => toast.remove(), 200);
  }, duration);
};

/**
 * Confirm Dialog (iOS style)
 */
export const showConfirm = (title, message) => {
  return new Promise((resolve) => {
    const overlay = document.createElement('div');
    overlay.style.cssText = `
      position: fixed; inset: 0; z-index: 10000;
      background: rgba(0,0,0,0.5); backdrop-filter: blur(8px);
      display: flex; align-items: center; justify-content: center;
      animation: fadeIn 0.2s ease both;
    `;
    overlay.innerHTML = `
      <div class="liquid-glass animate-scale-in" style="padding: 24px; max-width: 320px; width: 90%; text-align: center;">
        <div style="font-size: 1.1rem; font-weight: 700; margin-bottom: 8px;">${title}</div>
        <div style="font-size: 0.9rem; color: var(--text-secondary); margin-bottom: 24px;">${message}</div>
        <div style="display: flex; gap: 12px;">
          <button id="confirm-cancel" style="flex: 1; padding: 12px; border-radius: 12px; border: 1px solid var(--border-color);
            background: rgba(255,255,255,0.05); color: var(--text-primary); cursor: pointer; font-size: 0.95rem; font-weight: 600;">
            ยกเลิก
          </button>
          <button id="confirm-ok" style="flex: 1; padding: 12px; border-radius: 12px; border: none;
            background: var(--color-danger); color: white; cursor: pointer; font-size: 0.95rem; font-weight: 600;">
            ยืนยัน
          </button>
        </div>
      </div>`;

    document.body.appendChild(overlay);

    overlay.querySelector('#confirm-cancel').onclick = () => { overlay.remove(); resolve(false); };
    overlay.querySelector('#confirm-ok').onclick = () => { overlay.remove(); resolve(true); };
    overlay.onclick = (e) => { if (e.target === overlay) { overlay.remove(); resolve(false); } };
  });
};
