/**
 * Frontend Configuration Module
 * Centralized configuration for API endpoints, MQTT, and app settings
 */

const CONFIG = {
  // API Configuration
  API: {
    BASE_URL: process.env.VITE_API_URL || 'http://localhost:3000/api',
    TIMEOUT: 30000,
    RETRY_ATTEMPTS: 3,
    RETRY_DELAY: 1000
  },

  // MQTT Configuration
  MQTT: {
    BROKER: process.env.VITE_MQTT_BROKER || 'ws://localhost:9001',
    CLIENT_ID: `smartfarm_web_${Date.now()}`,
    TOPIC_PREFIX: 'smartfarm',
    RECONNECT_PERIOD: 5000,
    KEEP_ALIVE: 30
  },

  // Storage Configuration
  STORAGE: {
    PREFIX: 'smartfarm_',
    SENSOR_HISTORY_LIMIT: 1000,
    PUMP_HISTORY_LIMIT: 500,
    CACHE_DURATION: 5 * 60 * 1000 // 5 minutes
  },

  // UI Configuration
  UI: {
    THEME: 'dark', // 'dark', 'light', 'auto'
    LANGUAGE: 'th', // 'th', 'en'
    REFRESH_INTERVAL: 5000, // 5 seconds
    CHART_POINTS: 100,
    ANIMATION_DURATION: 300
  },

  // Feature Flags
  FEATURES: {
    MQTT_ENABLED: true,
    WEATHER_ENABLED: true,
    TELEGRAM_ENABLED: false,
    ANALYTICS_ENABLED: true,
    OFFLINE_MODE: true,
    PWA_ENABLED: true
  },

  // Sensor Configuration
  SENSORS: {
    TYPES: {
      TEMPERATURE: 'temperature',
      HUMIDITY: 'humidity',
      SOIL_MOISTURE: 'soil_moisture',
      LIGHT: 'light',
      RAIN: 'rain'
    },
    UNITS: {
      temperature: '°C',
      humidity: '%',
      soil_moisture: '%',
      light: 'lux',
      rain: 'mm'
    },
    COLORS: {
      temperature: '#ef4444',
      humidity: '#3b82f6',
      soil_moisture: '#8b5cf6',
      light: '#f59e0b',
      rain: '#06b6d4'
    }
  },

  // Pump Configuration
  PUMP: {
    MIN_DURATION: 10,
    MAX_DURATION: 3600,
    DEFAULT_DURATION: 300
  },

  // Schedule Configuration
  SCHEDULE: {
    DAYS: ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'],
    DAYS_TH: ['จันทร์', 'อังคาร', 'พุธ', 'พฤหัสบดี', 'ศุกร์', 'เสาร์', 'อาทิตย์']
  },

  // Notification Configuration
  NOTIFICATION: {
    DURATION: 5000,
    MAX_STACK: 5,
    TYPES: {
      SUCCESS: 'success',
      ERROR: 'error',
      WARNING: 'warning',
      INFO: 'info'
    }
  },

  // Chart Configuration
  CHART: {
    COLORS: {
      PRIMARY: '#06b6d4',
      SECONDARY: '#8b5cf6',
      SUCCESS: '#10b981',
      WARNING: '#f59e0b',
      ERROR: '#ef4444'
    },
    FONT_SIZE: 12,
    ANIMATION_DURATION: 750
  },

  // Weather Configuration
  WEATHER: {
    CACHE_DURATION: 30 * 60 * 1000, // 30 minutes
    UPDATE_INTERVAL: 60 * 60 * 1000 // 1 hour
  },

  // Accessibility
  ACCESSIBILITY: {
    FOCUS_VISIBLE_OUTLINE: '2px solid #06b6d4',
    HIGH_CONTRAST_MODE: false,
    REDUCE_MOTION: false
  },

  // Performance
  PERFORMANCE: {
    LAZY_LOAD_IMAGES: true,
    COMPRESS_IMAGES: true,
    MINIFY_CSS: true,
    MINIFY_JS: true
  }
};

/**
 * Get configuration value
 */
export function getConfig(path) {
  const keys = path.split('.');
  let value = CONFIG;

  for (const key of keys) {
    value = value?.[key];
    if (value === undefined) break;
  }

  return value;
}

/**
 * Set configuration value
 */
export function setConfig(path, value) {
  const keys = path.split('.');
  const lastKey = keys.pop();
  let target = CONFIG;

  for (const key of keys) {
    if (!target[key]) {
      target[key] = {};
    }
    target = target[key];
  }

  target[lastKey] = value;
}

/**
 * Merge configuration
 */
export function mergeConfig(updates) {
  Object.assign(CONFIG, updates);
}

export default CONFIG;
