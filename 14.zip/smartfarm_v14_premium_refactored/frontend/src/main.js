/**
 * SmartFarm V14 Frontend - Main Application Entry Point
 * Initializes the application, routes, and core modules
 */

import CONFIG from './config.js';
import stateManager from './state.js';
import authAPI from './api/auth.js';
import sensorsAPI from './api/sensors.js';
import pumpsAPI from './api/pumps.js';
import weatherAPI from './api/weather.js';
import './styles/global.css';

class SmartFarmApp {
  constructor() {
    this.root = document.getElementById('root');
    this.isInitialized = false;
    this.refreshInterval = null;
  }

  /**
   * Initialize application
   */
  async initialize() {
    try {
      console.log('SmartFarm V14 initializing...');

      // Restore session from localStorage
      const sessionRestored = authAPI.restoreSession();

      if (!sessionRestored) {
        this.showLoginPage();
        return;
      }

      // Load initial data
      await this.loadInitialData();

      // Render dashboard
      this.renderDashboard();

      // Setup auto-refresh
      this.setupAutoRefresh();

      this.isInitialized = true;
      console.log('SmartFarm V14 initialized successfully');
    } catch (error) {
      console.error('Initialization error:', error);
      this.showErrorPage(error.message);
    }
  }

  /**
   * Load initial data
   */
  async loadInitialData() {
    try {
      const [sensors, pumps, weather] = await Promise.all([
        sensorsAPI.getSensors().catch(() => []),
        pumpsAPI.getPumps().catch(() => []),
        weatherAPI.getCurrentWeather().catch(() => null)
      ]);

      console.log('Initial data loaded:', { sensors: sensors.length, pumps: pumps.length });
    } catch (error) {
      console.warn('Failed to load some initial data:', error);
    }
  }

  /**
   * Setup auto-refresh
   */
  setupAutoRefresh() {
    this.refreshInterval = setInterval(async () => {
      try {
        await Promise.all([
          sensorsAPI.getRealtimeStatus().catch(() => null),
          pumpsAPI.getRealtimeStatus().catch(() => null),
          weatherAPI.getCurrentWeather().catch(() => null)
        ]);

        this.updateDashboard();
      } catch (error) {
        console.warn('Auto-refresh error:', error);
      }
    }, CONFIG.UI.REFRESH_INTERVAL);
  }

  /**
   * Show login page
   */
  showLoginPage() {
    this.root.innerHTML = `
      <div class="login-container" style="
        display: flex;
        align-items: center;
        justify-content: center;
        height: 100vh;
        background: linear-gradient(135deg, #0f172a 0%, #020617 100%);
      ">
        <div class="glass-lg" style="
          width: 100%;
          max-width: 400px;
          padding: 2rem;
          margin: 1rem;
        ">
          <h1 style="text-align: center; margin-bottom: 2rem; font-size: 1.5rem;">
            SmartFarm V14
          </h1>
          
          <form id="loginForm" style="display: flex; flex-direction: column; gap: 1rem;">
            <div>
              <label style="display: block; margin-bottom: 0.5rem; font-size: 0.875rem;">
                ชื่อผู้ใช้
              </label>
              <input 
                type="text" 
                id="username" 
                placeholder="admin"
                required
                style="width: 100%; padding: 0.75rem; border-radius: 0.5rem; border: 1px solid #334155; background: rgba(30, 41, 59, 0.5); color: #f1f5f9;"
              >
            </div>
            
            <div>
              <label style="display: block; margin-bottom: 0.5rem; font-size: 0.875rem;">
                รหัสผ่าน
              </label>
              <input 
                type="password" 
                id="password" 
                placeholder="••••••••"
                required
                style="width: 100%; padding: 0.75rem; border-radius: 0.5rem; border: 1px solid #334155; background: rgba(30, 41, 59, 0.5); color: #f1f5f9;"
              >
            </div>
            
            <button 
              type="submit"
              style="
                width: 100%;
                padding: 0.75rem;
                background: linear-gradient(135deg, #06b6d4 0%, #0891b2 100%);
                color: white;
                border: none;
                border-radius: 0.5rem;
                font-weight: 600;
                cursor: pointer;
                transition: all 0.3s;
              "
              onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='0 0 20px rgba(6, 182, 212, 0.3)';"
              onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='none';"
            >
              เข้าสู่ระบบ
            </button>
          </form>
          
          <div id="loginError" style="
            margin-top: 1rem;
            padding: 0.75rem;
            background: rgba(239, 68, 68, 0.1);
            color: #ef4444;
            border-radius: 0.5rem;
            display: none;
            font-size: 0.875rem;
          "></div>
        </div>
      </div>
    `;

    document.getElementById('loginForm').addEventListener('submit', (e) => this.handleLogin(e));
  }

  /**
   * Handle login
   */
  async handleLogin(e) {
    e.preventDefault();

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const errorDiv = document.getElementById('loginError');

    try {
      errorDiv.style.display = 'none';
      await authAPI.login(username, password);
      this.initialize();
    } catch (error) {
      errorDiv.textContent = error.message || 'เข้าสู่ระบบล้มเหลว';
      errorDiv.style.display = 'block';
    }
  }

  /**
   * Render dashboard
   */
  renderDashboard() {
    const user = authAPI.getCurrentUser();
    const sensors = stateManager.get('sensors.list') || [];
    const pumps = stateManager.get('pumps.list') || [];
    const weather = stateManager.get('weather.current');

    this.root.innerHTML = `
      <div style="
        display: flex;
        height: 100vh;
        background: linear-gradient(135deg, #0f172a 0%, #020617 100%);
      ">
        <!-- Sidebar -->
        <aside style="
          width: 250px;
          background: rgba(15, 23, 42, 0.8);
          border-right: 1px solid #334155;
          padding: 1.5rem;
          overflow-y: auto;
        ">
          <h2 style="font-size: 1.25rem; margin-bottom: 2rem;">SmartFarm</h2>
          
          <nav style="display: flex; flex-direction: column; gap: 0.5rem;">
            <a href="#" style="padding: 0.75rem; border-radius: 0.5rem; background: rgba(6, 182, 212, 0.1); color: #06b6d4; text-decoration: none;">
              📊 Dashboard
            </a>
            <a href="#" style="padding: 0.75rem; border-radius: 0.5rem; color: #cbd5e1; text-decoration: none;">
              💧 Sensors
            </a>
            <a href="#" style="padding: 0.75rem; border-radius: 0.5rem; color: #cbd5e1; text-decoration: none;">
              💨 Pumps
            </a>
            <a href="#" style="padding: 0.75rem; border-radius: 0.5rem; color: #cbd5e1; text-decoration: none;">
              ⏰ Schedules
            </a>
            <a href="#" style="padding: 0.75rem; border-radius: 0.5rem; color: #cbd5e1; text-decoration: none;">
              ⚙️ Settings
            </a>
          </nav>

          <div style="
            margin-top: 2rem;
            padding-top: 2rem;
            border-top: 1px solid #334155;
          ">
            <div style="font-size: 0.875rem; color: #94a3b8; margin-bottom: 0.5rem;">
              ผู้ใช้: ${user?.username}
            </div>
            <button 
              onclick="location.reload()"
              style="
                width: 100%;
                padding: 0.5rem;
                background: rgba(239, 68, 68, 0.1);
                color: #ef4444;
                border: 1px solid #ef4444;
                border-radius: 0.5rem;
                cursor: pointer;
              "
            >
              ออกจากระบบ
            </button>
          </div>
        </aside>

        <!-- Main Content -->
        <main style="
          flex: 1;
          overflow-y: auto;
          padding: 2rem;
        ">
          <div style="max-width: 1400px; margin: 0 auto;">
            <!-- Header -->
            <div style="margin-bottom: 2rem;">
              <h1 style="font-size: 2rem; margin-bottom: 0.5rem;">Dashboard</h1>
              <p style="color: #cbd5e1;">ยินดีต้อนรับ ${user?.full_name || user?.username}</p>
            </div>

            <!-- Stats Grid -->
            <div style="
              display: grid;
              grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
              gap: 1rem;
              margin-bottom: 2rem;
            ">
              <div class="glass-lg" style="padding: 1.5rem;">
                <div style="font-size: 0.875rem; color: #94a3b8; margin-bottom: 0.5rem;">Sensors</div>
                <div style="font-size: 2rem; font-weight: bold; color: #06b6d4;">${sensors.length}</div>
              </div>
              
              <div class="glass-lg" style="padding: 1.5rem;">
                <div style="font-size: 0.875rem; color: #94a3b8; margin-bottom: 0.5rem;">Pumps</div>
                <div style="font-size: 2rem; font-weight: bold; color: #10b981;">${pumps.length}</div>
              </div>
              
              <div class="glass-lg" style="padding: 1.5rem;">
                <div style="font-size: 0.875rem; color: #94a3b8; margin-bottom: 0.5rem;">Temperature</div>
                <div style="font-size: 2rem; font-weight: bold; color: #f59e0b;">
                  ${weather?.temperature ? weather.temperature.toFixed(1) + '°C' : 'N/A'}
                </div>
              </div>
              
              <div class="glass-lg" style="padding: 1.5rem;">
                <div style="font-size: 0.875rem; color: #94a3b8; margin-bottom: 0.5rem;">Humidity</div>
                <div style="font-size: 2rem; font-weight: bold; color: #3b82f6;">
                  ${weather?.humidity ? weather.humidity + '%' : 'N/A'}
                </div>
              </div>
            </div>

            <!-- Sensors List -->
            <div class="glass-lg" style="padding: 1.5rem; margin-bottom: 2rem;">
              <h2 style="font-size: 1.25rem; margin-bottom: 1rem;">Sensors</h2>
              <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 1rem;">
                ${sensors.slice(0, 6).map(sensor => `
                  <div class="glass-sm" style="padding: 1rem; text-align: center;">
                    <div style="font-size: 0.75rem; color: #94a3b8; margin-bottom: 0.5rem; text-transform: uppercase;">
                      ${sensor.sensor_type}
                    </div>
                    <div style="font-size: 1.5rem; font-weight: bold; color: #06b6d4;">
                      ${sensor.last_value?.toFixed(1) || 'N/A'}
                    </div>
                    <div style="font-size: 0.75rem; color: #94a3b8; margin-top: 0.5rem;">
                      ${sensor.unit || ''}
                    </div>
                  </div>
                `).join('')}
              </div>
            </div>

            <!-- Pumps List -->
            <div class="glass-lg" style="padding: 1.5rem;">
              <h2 style="font-size: 1.25rem; margin-bottom: 1rem;">Pumps</h2>
              <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 1rem;">
                ${pumps.slice(0, 6).map(pump => `
                  <div class="glass-sm" style="padding: 1rem; text-align: center;">
                    <div style="font-size: 1.5rem; margin-bottom: 0.5rem;">
                      ${pump.is_running ? '💨' : '💧'}
                    </div>
                    <div style="font-size: 0.875rem; font-weight: 600; margin-bottom: 0.5rem;">
                      ${pump.name}
                    </div>
                    <div style="
                      display: inline-block;
                      padding: 0.25rem 0.75rem;
                      background: ${pump.is_running ? 'rgba(16, 185, 129, 0.2)' : 'rgba(148, 163, 184, 0.2)'};
                      color: ${pump.is_running ? '#10b981' : '#94a3b8'};
                      border-radius: 9999px;
                      font-size: 0.75rem;
                    ">
                      ${pump.is_running ? 'Running' : 'Idle'}
                    </div>
                  </div>
                `).join('')}
              </div>
            </div>
          </div>
        </main>
      </div>
    `;
  }

  /**
   * Update dashboard
   */
  updateDashboard() {
    // Update stats and data
    console.log('Dashboard updated');
  }

  /**
   * Show error page
   */
  showErrorPage(message) {
    this.root.innerHTML = `
      <div style="
        display: flex;
        align-items: center;
        justify-content: center;
        height: 100vh;
        background: linear-gradient(135deg, #0f172a 0%, #020617 100%);
        flex-direction: column;
        gap: 1rem;
        text-align: center;
      ">
        <div style="font-size: 3rem;">❌</div>
        <h1 style="font-size: 1.5rem;">เกิดข้อผิดพลาด</h1>
        <p style="color: #cbd5e1; max-width: 400px;">${message}</p>
        <button 
          onclick="location.reload()"
          style="
            padding: 0.75rem 1.5rem;
            background: linear-gradient(135deg, #06b6d4 0%, #0891b2 100%);
            color: white;
            border: none;
            border-radius: 0.5rem;
            cursor: pointer;
            font-weight: 600;
          "
        >
          ลองใหม่
        </button>
      </div>
    `;
  }

  /**
   * Cleanup
   */
  destroy() {
    if (this.refreshInterval) {
      clearInterval(this.refreshInterval);
    }
  }
}

// Initialize app when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  const app = new SmartFarmApp();
  app.initialize();

  // Cleanup on page unload
  window.addEventListener('beforeunload', () => {
    app.destroy();
  });
});

export default SmartFarmApp;
