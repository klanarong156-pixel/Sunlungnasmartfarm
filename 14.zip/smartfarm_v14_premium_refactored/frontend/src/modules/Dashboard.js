/**
 * SmartFarm V14 Premium - Dashboard.js
 * REWRITE: Premium Hero Dashboard with Glassmorphism, Animated Weather, Animated Gauges
 */

import state from '../core/State.js';
import { PremiumCard, AnimatedGauge, IOSSwitch, Skeleton, WeatherIcon } from '../core/Components.js';

const WEATHER_ICONS = {
  clear: '☀️', sunny: '☀️', clouds: '☁️', cloudy: '🌤️',
  rain: '🌧️', drizzle: '🌦️', thunderstorm: '⛈️', snow: '❄️',
  mist: '🌫️', fog: '🌫️', default: '🌡️'
};

const SENSOR_CONFIG = {
  soil_moisture:  { label: 'ความชื้นดิน', unit: '%',  icon: '🌱', color: '#34C759', min: 0, max: 100 },
  temperature:    { label: 'อุณหภูมิ',    unit: '°C', icon: '🌡️', color: '#FF9F0A', min: 0, max: 50 },
  humidity:       { label: 'ความชื้นอากาศ', unit: '%', icon: '💧', color: '#5AC8FA', min: 0, max: 100 },
  light:          { label: 'แสงสว่าง',    unit: 'lux', icon: '☀️', color: '#FFD60A', min: 0, max: 100000 },
  rain:           { label: 'ฝน',          unit: 'mm', icon: '🌧️', color: '#0A84FF', min: 0, max: 100 }
};

class Dashboard {
  constructor() {
    this.container = null;
    this.unsubscribeList = [];
    this.charts = {};
    this.wsClient = null;
  }

  init(containerId) {
    this.container = document.getElementById(containerId);
    if (!this.container) return;
    this.render();
    this.setupSubscriptions();
    this.setupWebSocket();
    this.setupMouseTracking();
  }

  destroy() {
    this.unsubscribeList.forEach(fn => fn());
    this.unsubscribeList = [];
    Object.values(this.charts).forEach(chart => chart?.destroy());
    this.charts = {};
  }

  setupSubscriptions() {
    this.unsubscribeList.push(
      state.subscribe('sensors.list', () => this.updateSensors()),
      state.subscribe('weather.current', () => this.updateWeather()),
      state.subscribe('pumps.list', () => this.updatePumps()),
      state.subscribe('system.mqttStatus', (status) => this.updateMQTTStatus(status)),
      state.subscribe('system.lastHeartbeat', () => this.updateSystemHealth())
    );
  }

  setupWebSocket() {
    const token = state.get('auth.token');
    if (!token) return;

    try {
      const wsUrl = `${location.protocol === 'https:' ? 'wss' : 'ws'}://${location.host}/ws?token=${token}`;
      this.wsClient = new WebSocket(wsUrl);

      this.wsClient.onopen = () => {
        state.set('system.mqttStatus', 'online');
      };

      this.wsClient.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);
          this.handleWebSocketMessage(msg);
        } catch (e) {}
      };

      this.wsClient.onclose = () => {
        state.set('system.mqttStatus', 'offline');
        // Reconnect after 5s
        setTimeout(() => this.setupWebSocket(), 5000);
      };

      this.wsClient.onerror = () => {
        state.set('system.mqttStatus', 'offline');
      };
    } catch (e) {}
  }

  handleWebSocketMessage(msg) {
    switch (msg.type) {
      case 'SENSOR_UPDATE': {
        const sensors = state.get('sensors.list') || [];
        const idx = sensors.findIndex(s => s.sensor_type === msg.payload.sensorType);
        if (idx >= 0) {
          sensors[idx].last_value = msg.payload.value;
          state.set('sensors.list', [...sensors]);
        }
        break;
      }
      case 'PUMP_UPDATE': {
        const pumps = state.get('pumps.list') || [];
        const idx = pumps.findIndex(p => p.device_id === msg.payload.deviceId);
        if (idx >= 0) {
          pumps[idx].is_running = msg.payload.status.is_running;
          state.set('pumps.list', [...pumps]);
        }
        break;
      }
      case 'MQTT_STATUS':
        state.set('system.mqttStatus', msg.payload.connected ? 'online' : 'offline');
        break;
      case 'HEARTBEAT':
        state.set('system.lastHeartbeat', msg.payload);
        break;
    }
  }

  render() {
    this.container.innerHTML = `
      <div class="dashboard-wrapper animate-fade-in" style="padding: 24px; max-width: 1400px; margin: 0 auto;">

        <!-- Hero Row: Weather + System Health + MQTT -->
        <div class="stagger-children" style="display: grid; grid-template-columns: 1fr 1fr 280px; gap: 20px; margin-bottom: 24px;">

          <!-- Weather Hero Card -->
          <div id="hero-weather" class="liquid-glass hero-dashboard animate-slide-up" style="grid-column: span 2; min-height: 180px; padding: 28px;">
            ${this.renderWeatherHero()}
          </div>

          <!-- System Health + MQTT -->
          <div style="display: flex; flex-direction: column; gap: 16px;">
            <div id="mqtt-status-card" class="liquid-glass animate-slide-up" style="padding: 20px;">
              ${this.renderMQTTStatus()}
            </div>
            <div id="system-health-card" class="liquid-glass animate-slide-up" style="padding: 20px; flex: 1;">
              ${this.renderSystemHealth()}
            </div>
          </div>
        </div>

        <!-- Sensor KPI Grid -->
        <div style="margin-bottom: 24px;">
          <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px;">
            <h2 style="font-size: 1.4rem; font-weight: 700; margin: 0; letter-spacing: -0.02em;">
              สภาพแวดล้อม Real-time
            </h2>
            <span id="last-update" style="font-size: 0.8rem; color: var(--text-tertiary);"></span>
          </div>
          <div id="sensors-grid" class="stagger-children" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 16px;">
            ${this.renderSensorSkeletons()}
          </div>
        </div>

        <!-- Pump Control + Activity Timeline -->
        <div style="display: grid; grid-template-columns: 1fr 380px; gap: 20px; margin-bottom: 24px;">
          <div id="pumps-section">
            <h2 style="font-size: 1.4rem; font-weight: 700; margin: 0 0 16px; letter-spacing: -0.02em;">ควบคุมปั๊มน้ำ</h2>
            <div id="pumps-grid" class="stagger-children" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 16px;">
              ${this.renderPumpSkeletons()}
            </div>
          </div>

          <!-- Activity Timeline -->
          <div>
            <h2 style="font-size: 1.4rem; font-weight: 700; margin: 0 0 16px; letter-spacing: -0.02em;">กิจกรรมล่าสุด</h2>
            <div id="activity-timeline" class="liquid-glass" style="padding: 20px; max-height: 400px; overflow-y: auto;">
              ${this.renderActivityTimeline()}
            </div>
          </div>
        </div>

        <!-- Analytics Charts Row -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
          <div class="liquid-glass" style="padding: 24px;">
            <h3 style="font-size: 1rem; font-weight: 600; margin: 0 0 16px;">ความชื้นดิน (7 วัน)</h3>
            <div class="chart-container">
              <canvas id="chart-soil"></canvas>
            </div>
          </div>
          <div class="liquid-glass" style="padding: 24px;">
            <h3 style="font-size: 1rem; font-weight: 600; margin: 0 0 16px;">อุณหภูมิ (7 วัน)</h3>
            <div class="chart-container">
              <canvas id="chart-temp"></canvas>
            </div>
          </div>
        </div>

      </div>
    `;

    // Initialize charts after render
    requestAnimationFrame(() => {
      this.initCharts();
      this.updateSensors();
      this.updatePumps();
      this.updateWeather();
    });
  }

  renderWeatherHero() {
    const weather = state.get('weather.current');
    if (!weather) {
      return `
        <div style="display: flex; align-items: center; gap: 24px;">
          <div class="skeleton" style="width: 80px; height: 80px; border-radius: 50%;"></div>
          <div style="flex: 1;">
            <div class="skeleton" style="width: 120px; height: 40px; margin-bottom: 8px;"></div>
            <div class="skeleton" style="width: 200px; height: 20px;"></div>
          </div>
        </div>`;
    }

    const desc = (weather.description || 'clear').toLowerCase();
    const icon = Object.keys(WEATHER_ICONS).find(k => desc.includes(k)) || 'default';
    const weatherIcon = WEATHER_ICONS[icon];

    return `
      <div class="hero-bg"></div>
      <div style="position: relative; z-index: 1; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 20px;">
        <div style="display: flex; align-items: center; gap: 24px;">
          <div class="weather-icon-${icon.includes('rain') ? 'rain' : icon.includes('cloud') ? 'cloud' : 'sun'}"
               style="font-size: 4rem; line-height: 1;">${weatherIcon}</div>
          <div>
            <div style="font-size: 3.5rem; font-weight: 800; letter-spacing: -0.04em; line-height: 1;">
              ${weather.temperature?.toFixed(1) || '--'}°C
            </div>
            <div style="font-size: 1.1rem; color: var(--text-secondary); margin-top: 4px;">
              ${weather.description || 'ท้องฟ้าแจ่มใส'} · ${weather.city || 'Bangkok'}
            </div>
          </div>
        </div>
        <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px;">
          ${this.renderWeatherStat('💧', 'ความชื้น', `${weather.humidity || '--'}%`)}
          ${this.renderWeatherStat('💨', 'ลม', `${weather.wind_speed?.toFixed(1) || '--'} m/s`)}
          ${this.renderWeatherStat('🌡️', 'รู้สึก', `${weather.feels_like?.toFixed(1) || '--'}°C`)}
        </div>
      </div>`;
  }

  renderWeatherStat(icon, label, value) {
    return `
      <div style="text-align: center; padding: 12px 16px; background: rgba(255,255,255,0.06); border-radius: 12px; border: 1px solid rgba(255,255,255,0.1);">
        <div style="font-size: 1.2rem; margin-bottom: 4px;">${icon}</div>
        <div style="font-size: 1rem; font-weight: 700;">${value}</div>
        <div style="font-size: 0.7rem; color: var(--text-tertiary); text-transform: uppercase; letter-spacing: 0.08em;">${label}</div>
      </div>`;
  }

  renderMQTTStatus() {
    const status = state.get('system.mqttStatus') || 'offline';
    const isOnline = status === 'online';
    return `
      <div style="display: flex; align-items: center; justify-content: space-between;">
        <div>
          <div style="font-size: 0.75rem; color: var(--text-tertiary); text-transform: uppercase; letter-spacing: 0.08em; margin-bottom: 6px;">MQTT Status</div>
          <div class="mqtt-status ${isOnline ? 'online' : 'offline'}">
            <div class="mqtt-dot"></div>
            <span>${isOnline ? 'Connected' : 'Offline'}</span>
          </div>
        </div>
        <div style="font-size: 2rem;">${isOnline ? '📡' : '📵'}</div>
      </div>`;
  }

  renderSystemHealth() {
    const heartbeat = state.get('system.lastHeartbeat');
    return `
      <div>
        <div style="font-size: 0.75rem; color: var(--text-tertiary); text-transform: uppercase; letter-spacing: 0.08em; margin-bottom: 12px;">System Health</div>
        ${heartbeat ? `
          <div style="display: flex; flex-direction: column; gap: 8px;">
            <div style="display: flex; justify-content: space-between; font-size: 0.85rem;">
              <span style="color: var(--text-secondary);">RSSI</span>
              <span style="font-weight: 600;">${heartbeat.rssi || '--'} dBm</span>
            </div>
            <div style="display: flex; justify-content: space-between; font-size: 0.85rem;">
              <span style="color: var(--text-secondary);">Heap</span>
              <span style="font-weight: 600;">${heartbeat.heap ? Math.round(heartbeat.heap/1024) + ' KB' : '--'}</span>
            </div>
            <div style="display: flex; justify-content: space-between; font-size: 0.85rem;">
              <span style="color: var(--text-secondary);">Uptime</span>
              <span style="font-weight: 600;">${heartbeat.uptime ? this.formatUptime(heartbeat.uptime) : '--'}</span>
            </div>
          </div>
        ` : `<div class="skeleton" style="height: 80px;"></div>`}
      </div>`;
  }

  renderSensorSkeletons() {
    return Array(4).fill(0).map(() => `
      <div class="liquid-glass sensor-card" style="padding: 20px;">
        <div class="skeleton" style="width: 40px; height: 40px; border-radius: 10px; margin-bottom: 12px;"></div>
        <div class="skeleton" style="width: 80px; height: 32px; margin-bottom: 8px;"></div>
        <div class="skeleton" style="width: 120px; height: 16px;"></div>
      </div>`).join('');
  }

  renderPumpSkeletons() {
    return Array(2).fill(0).map(() => `
      <div class="liquid-glass" style="padding: 20px;">
        <div class="skeleton" style="height: 100px;"></div>
      </div>`).join('');
  }

  renderActivityTimeline() {
    return `
      <div class="timeline">
        <div class="timeline-item">
          <div style="font-size: 0.85rem; font-weight: 600; margin-bottom: 2px;">ระบบพร้อมทำงาน</div>
          <div style="font-size: 0.75rem; color: var(--text-tertiary);">เพิ่งเริ่มต้น</div>
        </div>
      </div>`;
  }

  updateSensors() {
    const sensors = state.get('sensors.list') || [];
    const grid = document.getElementById('sensors-grid');
    if (!grid) return;

    if (sensors.length === 0) {
      grid.innerHTML = this.renderSensorSkeletons();
      return;
    }

    grid.innerHTML = sensors.map((sensor, idx) => {
      const config = SENSOR_CONFIG[sensor.sensor_type] || {
        label: sensor.name, unit: sensor.unit || '', icon: '📊',
        color: '#007AFF', min: 0, max: 100
      };
      const value = parseFloat(sensor.last_value) || 0;
      const percentage = Math.min(100, Math.max(0, ((value - config.min) / (config.max - config.min)) * 100));

      return `
        <div class="liquid-glass sensor-card animate-slide-up" style="padding: 20px; animation-delay: ${idx * 80}ms;">
          <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px;">
            <div style="width: 44px; height: 44px; border-radius: 12px; background: ${config.color}22;
                        display: flex; align-items: center; justify-content: center; font-size: 1.3rem;">
              ${config.icon}
            </div>
            <div style="width: 48px; height: 48px;">
              ${this.renderMiniGauge(percentage, config.color)}
            </div>
          </div>
          <div style="font-size: 2rem; font-weight: 800; letter-spacing: -0.04em; color: ${config.color}; line-height: 1; margin-bottom: 4px;">
            ${value.toFixed(1)}<span style="font-size: 1rem; font-weight: 500; opacity: 0.7;">${config.unit}</span>
          </div>
          <div style="font-size: 0.8rem; color: var(--text-secondary); font-weight: 500;">${config.label}</div>
          <div style="margin-top: 12px;">
            <div class="performance-bar">
              <div class="performance-bar-fill" style="width: ${percentage}%; background: linear-gradient(90deg, ${config.color}, ${config.color}aa);"></div>
            </div>
          </div>
        </div>`;
    }).join('');

    // Update last update time
    const lastUpdate = document.getElementById('last-update');
    if (lastUpdate) {
      lastUpdate.textContent = 'อัปเดต: ' + new Date().toLocaleTimeString('th-TH');
    }
  }

  renderMiniGauge(percentage, color) {
    const radius = 20;
    const circumference = 2 * Math.PI * radius;
    const offset = circumference - (percentage / 100) * circumference;
    return `
      <svg viewBox="0 0 48 48" style="transform: rotate(-90deg);">
        <circle cx="24" cy="24" r="${radius}" fill="none" stroke="rgba(255,255,255,0.1)" stroke-width="4"/>
        <circle cx="24" cy="24" r="${radius}" fill="none" stroke="${color}" stroke-width="4"
          stroke-dasharray="${circumference}" stroke-dashoffset="${offset}"
          stroke-linecap="round" style="transition: stroke-dashoffset 1s cubic-bezier(0.34,1.56,0.64,1);"/>
      </svg>`;
  }

  updatePumps() {
    const pumps = state.get('pumps.list') || [];
    const grid = document.getElementById('pumps-grid');
    if (!grid) return;

    if (pumps.length === 0) {
      grid.innerHTML = this.renderPumpSkeletons();
      return;
    }

    grid.innerHTML = pumps.map((pump, idx) => `
      <div class="liquid-glass pump-card ${pump.is_running ? 'running' : ''} animate-slide-up"
           style="padding: 20px; animation-delay: ${idx * 100}ms;">
        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px;">
          <div>
            <div style="font-size: 1rem; font-weight: 700; margin-bottom: 4px;">${pump.name}</div>
            <div style="font-size: 0.8rem; color: var(--text-tertiary);">Device: ${pump.device_id}</div>
          </div>
          <label class="ios-switch">
            <input type="checkbox" ${pump.is_running ? 'checked' : ''}
              onchange="window.togglePump(${pump.id})">
            <span class="ios-slider"></span>
          </label>
        </div>
        <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 12px;">
          <div style="width: 10px; height: 10px; border-radius: 50%;
                      background: ${pump.is_running ? 'var(--color-success)' : 'var(--text-tertiary)'};
                      ${pump.is_running ? 'animation: mqttPulse 2s ease-in-out infinite;' : ''}"></div>
          <span style="font-size: 0.85rem; font-weight: 600; color: ${pump.is_running ? 'var(--color-success)' : 'var(--text-tertiary)'};">
            ${pump.is_running ? 'กำลังทำงาน' : 'หยุดทำงาน'}
          </span>
        </div>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px;">
          <div style="background: rgba(255,255,255,0.05); border-radius: 8px; padding: 8px 12px;">
            <div style="font-size: 0.7rem; color: var(--text-tertiary); margin-bottom: 2px;">Runtime</div>
            <div style="font-size: 0.9rem; font-weight: 600;">${this.formatRuntime(pump.runtime_seconds || 0)}</div>
          </div>
          <div style="background: rgba(255,255,255,0.05); border-radius: 8px; padding: 8px 12px;">
            <div style="font-size: 0.7rem; color: var(--text-tertiary); margin-bottom: 2px;">รวมทั้งหมด</div>
            <div style="font-size: 0.9rem; font-weight: 600;">${this.formatRuntime(pump.total_runtime_seconds || 0)}</div>
          </div>
        </div>
      </div>`).join('');
  }

  updateWeather() {
    const weatherEl = document.getElementById('hero-weather');
    if (weatherEl) {
      weatherEl.innerHTML = this.renderWeatherHero();
    }
  }

  updateMQTTStatus(status) {
    const card = document.getElementById('mqtt-status-card');
    if (card) {
      card.innerHTML = this.renderMQTTStatus();
    }
  }

  updateSystemHealth() {
    const card = document.getElementById('system-health-card');
    if (card) {
      card.innerHTML = this.renderSystemHealth();
    }
  }

  initCharts() {
    if (typeof Chart === 'undefined') return;

    const chartDefaults = {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: 'rgba(28,28,30,0.9)',
          titleColor: '#fff',
          bodyColor: '#ebebf5',
          borderColor: 'rgba(255,255,255,0.1)',
          borderWidth: 1,
          cornerRadius: 12,
          padding: 12
        }
      },
      scales: {
        x: {
          grid: { color: 'rgba(255,255,255,0.05)', drawBorder: false },
          ticks: { color: 'rgba(255,255,255,0.4)', font: { size: 11 } }
        },
        y: {
          grid: { color: 'rgba(255,255,255,0.05)', drawBorder: false },
          ticks: { color: 'rgba(255,255,255,0.4)', font: { size: 11 } }
        }
      }
    };

    const labels = this.getLast7Days();

    const soilCanvas = document.getElementById('chart-soil');
    if (soilCanvas) {
      this.charts.soil = new Chart(soilCanvas, {
        type: 'line',
        data: {
          labels,
          datasets: [{
            data: Array(7).fill(0).map(() => Math.random() * 40 + 40),
            borderColor: '#34C759',
            backgroundColor: 'rgba(52,199,89,0.1)',
            borderWidth: 2,
            fill: true,
            tension: 0.4,
            pointBackgroundColor: '#34C759',
            pointRadius: 4,
            pointHoverRadius: 6
          }]
        },
        options: { ...chartDefaults, animation: { duration: 1000, easing: 'easeOutQuart' } }
      });
    }

    const tempCanvas = document.getElementById('chart-temp');
    if (tempCanvas) {
      this.charts.temp = new Chart(tempCanvas, {
        type: 'line',
        data: {
          labels,
          datasets: [{
            data: Array(7).fill(0).map(() => Math.random() * 10 + 25),
            borderColor: '#FF9F0A',
            backgroundColor: 'rgba(255,159,10,0.1)',
            borderWidth: 2,
            fill: true,
            tension: 0.4,
            pointBackgroundColor: '#FF9F0A',
            pointRadius: 4,
            pointHoverRadius: 6
          }]
        },
        options: { ...chartDefaults, animation: { duration: 1200, easing: 'easeOutQuart' } }
      });
    }
  }

  setupMouseTracking() {
    document.addEventListener('mousemove', (e) => {
      document.querySelectorAll('.sensor-card').forEach(card => {
        const rect = card.getBoundingClientRect();
        const x = ((e.clientX - rect.left) / rect.width) * 100;
        const y = ((e.clientY - rect.top) / rect.height) * 100;
        card.style.setProperty('--mouse-x', `${x}%`);
        card.style.setProperty('--mouse-y', `${y}%`);
      });
    });
  }

  getLast7Days() {
    return Array(7).fill(0).map((_, i) => {
      const d = new Date();
      d.setDate(d.getDate() - (6 - i));
      return d.toLocaleDateString('th-TH', { month: 'short', day: 'numeric' });
    });
  }

  formatRuntime(seconds) {
    if (!seconds) return '0s';
    if (seconds < 60) return `${seconds}s`;
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m`;
    return `${Math.floor(seconds / 3600)}h ${Math.floor((seconds % 3600) / 60)}m`;
  }

  formatUptime(seconds) {
    if (!seconds) return '--';
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    return h > 0 ? `${h}h ${m}m` : `${m}m`;
  }
}

export default new Dashboard();
