/**
 * SmartFarm V14 Premium Analytics Module
 * Renders interactive charts and statistics
 */

import state from '../core/State.js';
import { Card } from '../core/Components.js';

class Analytics {
  constructor() {
    this.container = null;
    this.charts = {};
  }

  init(containerId) {
    this.container = document.getElementById(containerId);
    this.render();
    this.initCharts();
  }

  render() {
    this.container.innerHTML = `
      <div class="analytics-wrapper p-6 space-y-8 animate-fade-in">
        <h2 class="text-3xl font-bold px-2">Analytics & Insights</h2>
        
        <!-- Summary Cards -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
          ${this.renderSummaryCard('Total Water Saved', '1,240 L', '📈 +12%', 'text-green-500')}
          ${this.renderSummaryCard('Pump Efficiency', '98.2%', '✨ Optimal', 'text-blue-500')}
          ${this.renderSummaryCard('Soil Health Score', '85/100', '🌱 Healthy', 'text-indigo-500')}
        </div>

        <!-- Charts Grid -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
          ${Card({ 
            title: 'Environment Trends (24h)', 
            children: '<div class="chart-container"><canvas id="envChart"></canvas></div>' 
          })}
          ${Card({ 
            title: 'Water Usage by Zone', 
            children: '<div class="chart-container"><canvas id="waterChart"></canvas></div>' 
          })}
        </div>
      </div>
    `;
  }

  renderSummaryCard(title, value, badge, badgeClass) {
    return `
      <div class="liquid-glass p-6">
        <div class="text-sm text-gray-500 mb-2 uppercase tracking-wider">${title}</div>
        <div class="text-3xl font-bold mb-4">${value}</div>
        <div class="inline-block px-3 py-1 rounded-full bg-gray-100 dark:bg-white/5 text-xs font-bold ${badgeClass}">
          ${badge}
        </div>
      </div>
    `;
  }

  initCharts() {
    // Note: Requires Chart.js to be loaded in index.html
    if (typeof Chart === 'undefined') {
      console.warn('Chart.js not loaded');
      return;
    }

    const ctxEnv = document.getElementById('envChart').getContext('2d');
    new Chart(ctxEnv, {
      type: 'line',
      data: {
        labels: ['00:00', '04:00', '08:00', '12:00', '16:00', '20:00'],
        datasets: [{
          label: 'Temperature',
          data: [22, 21, 25, 32, 30, 26],
          borderColor: '#FF9500',
          tension: 0.4,
          fill: true,
          backgroundColor: 'rgba(255, 149, 0, 0.1)'
        }]
      },
      options: this.getChartOptions()
    });
  }

  getChartOptions() {
    return {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        y: { grid: { display: false }, border: { display: false } },
        x: { grid: { display: false }, border: { display: false } }
      }
    };
  }
}

export default new Analytics();
