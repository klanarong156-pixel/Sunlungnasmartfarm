/**
 * Authentication API Module
 * Handles login, logout, token refresh, and user profile
 */

import client from './client.js';
import stateManager from '../state.js';

export const authAPI = {
  /**
   * Login with username and password
   */
  async login(username, password) {
    try {
      const response = await client.post('/auth/login', { username, password });

      if (response.success && response.token) {
        stateManager.set('auth.token', response.token);
        stateManager.set('auth.isAuthenticated', true);
        stateManager.set('auth.user', response.user);
        stateManager.set('auth.role', response.user.role);

        // Store token in localStorage
        localStorage.setItem('smartfarm_token', response.token);
        localStorage.setItem('smartfarm_user', JSON.stringify(response.user));
      }

      return response;
    } catch (error) {
      console.error('Login failed:', error);
      throw error;
    }
  },

  /**
   * Logout
   */
  async logout() {
    try {
      await client.post('/auth/logout', {});

      stateManager.set('auth.isAuthenticated', false);
      stateManager.set('auth.token', null);
      stateManager.set('auth.user', null);
      stateManager.set('auth.role', null);

      localStorage.removeItem('smartfarm_token');
      localStorage.removeItem('smartfarm_user');
    } catch (error) {
      console.error('Logout failed:', error);
      throw error;
    }
  },

  /**
   * Refresh token
   */
  async refreshToken() {
    try {
      const response = await client.post('/auth/refresh', {});

      if (response.success && response.token) {
        stateManager.set('auth.token', response.token);
        localStorage.setItem('smartfarm_token', response.token);
      }

      return response;
    } catch (error) {
      console.error('Token refresh failed:', error);
      stateManager.set('auth.isAuthenticated', false);
      throw error;
    }
  },

  /**
   * Get user profile
   */
  async getProfile() {
    try {
      const response = await client.get('/auth/profile');
      return response.user;
    } catch (error) {
      console.error('Failed to fetch profile:', error);
      throw error;
    }
  },

  /**
   * Update user profile
   */
  async updateProfile(updates) {
    try {
      const response = await client.put('/auth/profile', updates);
      return response;
    } catch (error) {
      console.error('Failed to update profile:', error);
      throw error;
    }
  },

  /**
   * Change password
   */
  async changePassword(currentPassword, newPassword) {
    try {
      const response = await client.post('/auth/change-password', {
        currentPassword,
        newPassword
      });
      return response;
    } catch (error) {
      console.error('Failed to change password:', error);
      throw error;
    }
  },

  /**
   * Get user sessions
   */
  async getSessions() {
    try {
      const response = await client.get('/auth/sessions');
      return response.sessions || [];
    } catch (error) {
      console.error('Failed to fetch sessions:', error);
      throw error;
    }
  },

  /**
   * Terminate session
   */
  async terminateSession(sessionId) {
    try {
      const response = await client.delete(`/auth/sessions/${sessionId}`);
      return response;
    } catch (error) {
      console.error('Failed to terminate session:', error);
      throw error;
    }
  },

  /**
   * Check if user is authenticated
   */
  isAuthenticated() {
    return stateManager.get('auth.isAuthenticated');
  },

  /**
   * Get current user
   */
  getCurrentUser() {
    return stateManager.get('auth.user');
  },

  /**
   * Get user role
   */
  getUserRole() {
    return stateManager.get('auth.role');
  },

  /**
   * Check if user has role
   */
  hasRole(role) {
    const userRole = this.getUserRole();
    if (role === 'admin') return userRole === 'admin';
    if (role === 'operator') return ['admin', 'operator'].includes(userRole);
    return !!userRole;
  },

  /**
   * Restore session from localStorage
   */
  restoreSession() {
    const token = localStorage.getItem('smartfarm_token');
    const user = localStorage.getItem('smartfarm_user');

    if (token && user) {
      try {
        stateManager.set('auth.token', token);
        stateManager.set('auth.user', JSON.parse(user));
        stateManager.set('auth.isAuthenticated', true);
        stateManager.set('auth.role', JSON.parse(user).role);
        return true;
      } catch (error) {
        console.error('Failed to restore session:', error);
        return false;
      }
    }

    return false;
  }
};

export default authAPI;
