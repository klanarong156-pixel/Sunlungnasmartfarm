/**
 * Weather API Module
 * Handles weather data retrieval, caching, and forecasts
 */

import client from './client.js';
import stateManager from '../state.js';
import CONFIG from '../config.js';

export const weatherAPI = {
  /**
   * Get current weather
   */
  async getCurrentWeather(latitude, longitude) {
    try {
      stateManager.set('weather.loading', true);

      const params = new URLSearchParams();
      if (latitude) params.append('latitude', latitude);
      if (longitude) params.append('longitude', longitude);

      const response = await client.get(`/weather/current?${params}`);

      if (response.success) {
        stateManager.set('weather.current', response.weather);
        stateManager.set('weather.lastUpdate', new Date().toISOString());
      }

      stateManager.set('weather.loading', false);
      return response.weather;
    } catch (error) {
      stateManager.set('weather.error', error.message);
      stateManager.set('weather.loading', false);
      throw error;
    }
  },

  /**
   * Get weather forecast
   */
  async getForecast(latitude, longitude, days = 7) {
    try {
      const params = new URLSearchParams();
      if (latitude) params.append('latitude', latitude);
      if (longitude) params.append('longitude', longitude);
      params.append('days', days);

      const response = await client.get(`/weather/forecast?${params}`);

      if (response.success) {
        stateManager.set('weather.forecast', response.forecast || []);
      }

      return response.forecast || [];
    } catch (error) {
      console.error('Failed to fetch weather forecast:', error);
      throw error;
    }
  },

  /**
   * Get weather settings
   */
  async getSettings() {
    try {
      const response = await client.get('/weather/settings');
      return response.settings || {};
    } catch (error) {
      console.error('Failed to fetch weather settings:', error);
      throw error;
    }
  },

  /**
   * Update weather settings
   */
  async updateSettings(settings) {
    try {
      const response = await client.put('/weather/settings', settings);
      return response;
    } catch (error) {
      console.error('Failed to update weather settings:', error);
      throw error;
    }
  },

  /**
   * Get offline weather data
   */
  async getOfflineWeather() {
    try {
      const response = await client.get('/weather/offline');

      if (response.success) {
        return {
          weather: response.weather,
          offline: response.offline,
          cachedAt: response.cachedAt
        };
      }

      return null;
    } catch (error) {
      console.error('Failed to fetch offline weather:', error);
      return null;
    }
  },

  /**
   * Get current weather from state
   */
  getCurrent() {
    return stateManager.get('weather.current');
  },

  /**
   * Get forecast from state
   */
  getForecastFromState() {
    return stateManager.get('weather.forecast') || [];
  },

  /**
   * Get weather description
   */
  getWeatherDescription(weatherCode) {
    const descriptions = {
      0: 'ท้องฟ้าแจ่มใส',
      1: 'ท้องฟ้าส่วนใหญ่แจ่มใส',
      2: 'มีเมฆบางส่วน',
      3: 'มีเมฆมาก',
      45: 'หมอก',
      48: 'หมอกเยือกแข็ง',
      51: 'ฝนเบา',
      53: 'ฝนปานกลาง',
      55: 'ฝนหนัก',
      61: 'ฝนเล็กน้อย',
      63: 'ฝนปานกลาง',
      65: 'ฝนหนัก',
      71: 'หิมะเล็กน้อย',
      73: 'หิมะปานกลาง',
      75: 'หิมะหนัก',
      77: 'เม็ดหิมะ',
      80: 'ฝนเล็กน้อยเป็นเวลา',
      81: 'ฝนปานกลางเป็นเวลา',
      82: 'ฝนหนักเป็นเวลา',
      85: 'หิมะเล็กน้อยเป็นเวลา',
      86: 'หิมะหนักเป็นเวลา',
      95: 'พายุฝนฟ้าคะนอง',
      96: 'พายุฝนฟ้าคะนองมีลูกเห็บเล็กน้อย',
      99: 'พายุฝนฟ้าคะนองมีลูกเห็บหนัก'
    };

    return descriptions[weatherCode] || 'ไม่ทราบ';
  },

  /**
   * Get weather icon
   */
  getWeatherIcon(weatherCode) {
    if (weatherCode === 0) return '☀️';
    if ([1, 2].includes(weatherCode)) return '🌤️';
    if (weatherCode === 3) return '☁️';
    if ([45, 48].includes(weatherCode)) return '🌫️';
    if ([51, 53, 55, 61, 63, 65, 80, 81, 82].includes(weatherCode)) return '🌧️';
    if ([71, 73, 75, 77, 85, 86].includes(weatherCode)) return '❄️';
    if ([95, 96, 99].includes(weatherCode)) return '⛈️';
    return '🌡️';
  },

  /**
   * Check if rain is expected
   */
  isRainExpected(weatherCode) {
    return [51, 53, 55, 61, 63, 65, 80, 81, 82, 95, 96, 99].includes(weatherCode);
  },

  /**
   * Get rain probability
   */
  getRainProbability(weatherCode) {
    if ([51, 53, 55].includes(weatherCode)) return 0.3;
    if ([61, 63, 65].includes(weatherCode)) return 0.6;
    if ([80, 81, 82].includes(weatherCode)) return 0.8;
    if ([95, 96, 99].includes(weatherCode)) return 0.95;
    return 0;
  }
};

export default weatherAPI;
