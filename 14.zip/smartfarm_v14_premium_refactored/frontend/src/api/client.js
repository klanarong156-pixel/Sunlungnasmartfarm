/**
 * API Client Module
 * Handles HTTP requests with retry logic, error handling, and authentication
 */

import CONFIG from '../config.js';
import stateManager from '../state.js';

class APIClient {
  constructor(baseURL = CONFIG.API.BASE_URL) {
    this.baseURL = baseURL;
    this.timeout = CONFIG.API.TIMEOUT;
    this.retryAttempts = CONFIG.API.RETRY_ATTEMPTS;
    this.retryDelay = CONFIG.API.RETRY_DELAY;
  }

  /**
   * Get authorization header
   */
  getAuthHeader() {
    const token = stateManager.get('auth.token');
    if (token) {
      return { 'Authorization': `Bearer ${token}` };
    }
    return {};
  }

  /**
   * Make HTTP request with retry logic
   */
  async request(method, endpoint, data = null, options = {}) {
    const url = `${this.baseURL}${endpoint}`;
    const headers = {
      'Content-Type': 'application/json',
      ...this.getAuthHeader(),
      ...options.headers
    };

    let lastError;
    let attempt = 0;

    while (attempt < this.retryAttempts) {
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), this.timeout);

        const config = {
          method,
          headers,
          signal: controller.signal
        };

        if (data && (method === 'POST' || method === 'PUT' || method === 'PATCH')) {
          config.body = JSON.stringify(data);
        }

        const response = await fetch(url, config);
        clearTimeout(timeoutId);

        if (response.status === 401) {
          stateManager.set('auth.isAuthenticated', false);
          stateManager.set('auth.token', null);
          throw new Error('Unauthorized');
        }

        if (!response.ok) {
          const error = await response.json().catch(() => ({ error: response.statusText }));
          throw new Error(error.error || response.statusText);
        }

        return await response.json();
      } catch (error) {
        lastError = error;
        attempt++;

        if (attempt < this.retryAttempts) {
          await this.delay(this.retryDelay * attempt);
        }
      }
    }

    throw lastError;
  }

  /**
   * Delay helper
   */
  delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  /**
   * GET request
   */
  get(endpoint, options = {}) {
    return this.request('GET', endpoint, null, options);
  }

  /**
   * POST request
   */
  post(endpoint, data, options = {}) {
    return this.request('POST', endpoint, data, options);
  }

  /**
   * PUT request
   */
  put(endpoint, data, options = {}) {
    return this.request('PUT', endpoint, data, options);
  }

  /**
   * PATCH request
   */
  patch(endpoint, data, options = {}) {
    return this.request('PATCH', endpoint, data, options);
  }

  /**
   * DELETE request
   */
  delete(endpoint, options = {}) {
    return this.request('DELETE', endpoint, null, options);
  }

  /**
   * Upload file
   */
  async uploadFile(endpoint, file) {
    const formData = new FormData();
    formData.append('file', file);

    const token = stateManager.get('auth.token');
    const headers = token ? { 'Authorization': `Bearer ${token}` } : {};

    const response = await fetch(`${this.baseURL}${endpoint}`, {
      method: 'POST',
      headers,
      body: formData
    });

    if (!response.ok) {
      throw new Error('Upload failed');
    }

    return await response.json();
  }
}

export default new APIClient();
