/**
 * Pumps API Module
 * Handles pump control, status, history, and runtime tracking
 */

import client from './client.js';
import stateManager from '../state.js';

export const pumpsAPI = {
  /**
   * Get all pumps
   */
  async getPumps() {
    try {
      stateManager.set('pumps.loading', true);
      const response = await client.get('/pumps');

      if (response.success) {
        stateManager.set('pumps.list', response.pumps || []);
      }

      stateManager.set('pumps.loading', false);
      return response.pumps || [];
    } catch (error) {
      stateManager.set('pumps.error', error.message);
      stateManager.set('pumps.loading', false);
      throw error;
    }
  },

  /**
   * Get pump by ID
   */
  async getPump(id) {
    try {
      const response = await client.get(`/pumps/${id}`);
      return response.pump;
    } catch (error) {
      console.error('Failed to fetch pump:', error);
      throw error;
    }
  },

  /**
   * Create pump
   */
  async createPump(pumpData) {
    try {
      const response = await client.post('/pumps', pumpData);

      if (response.success) {
        const pumps = stateManager.get('pumps.list');
        stateManager.set('pumps.list', [...pumps, { id: response.pumpId, ...pumpData }]);
      }

      return response;
    } catch (error) {
      console.error('Failed to create pump:', error);
      throw error;
    }
  },

  /**
   * Update pump
   */
  async updatePump(id, updates) {
    try {
      const response = await client.put(`/pumps/${id}`, updates);

      if (response.success) {
        const pumps = stateManager.get('pumps.list');
        const updated = pumps.map(p => p.id === id ? { ...p, ...updates } : p);
        stateManager.set('pumps.list', updated);
      }

      return response;
    } catch (error) {
      console.error('Failed to update pump:', error);
      throw error;
    }
  },

  /**
   * Delete pump
   */
  async deletePump(id) {
    try {
      const response = await client.delete(`/pumps/${id}`);

      if (response.success) {
        const pumps = stateManager.get('pumps.list');
        stateManager.set('pumps.list', pumps.filter(p => p.id !== id));
      }

      return response;
    } catch (error) {
      console.error('Failed to delete pump:', error);
      throw error;
    }
  },

  /**
   * Start pump
   */
  async startPump(id, durationSeconds = 300) {
    try {
      const response = await client.post(`/pumps/${id}/start`, { duration_seconds: durationSeconds });

      if (response.success) {
        const pumps = stateManager.get('pumps.list');
        const updated = pumps.map(p => p.id === id ? { ...p, is_running: true } : p);
        stateManager.set('pumps.list', updated);
      }

      return response;
    } catch (error) {
      console.error('Failed to start pump:', error);
      throw error;
    }
  },

  /**
   * Stop pump
   */
  async stopPump(id) {
    try {
      const response = await client.post(`/pumps/${id}/stop`, {});

      if (response.success) {
        const pumps = stateManager.get('pumps.list');
        const updated = pumps.map(p => p.id === id ? { ...p, is_running: false } : p);
        stateManager.set('pumps.list', updated);
      }

      return response;
    } catch (error) {
      console.error('Failed to stop pump:', error);
      throw error;
    }
  },

  /**
   * Get pump history
   */
  async getHistory(pumpId, options = {}) {
    try {
      const params = new URLSearchParams();
      if (options.startDate) params.append('startDate', options.startDate);
      if (options.endDate) params.append('endDate', options.endDate);
      if (options.limit) params.append('limit', options.limit);

      const response = await client.get(`/pumps/${pumpId}/history?${params}`);

      if (response.success) {
        const history = stateManager.get('pumps.history') || {};
        history[pumpId] = response.history;
        stateManager.set('pumps.history', history);
      }

      return response.history || [];
    } catch (error) {
      console.error('Failed to fetch pump history:', error);
      throw error;
    }
  },

  /**
   * Get pump statistics
   */
  async getStatistics(pumpId, days = 7) {
    try {
      const response = await client.get(`/pumps/${pumpId}/statistics?days=${days}`);
      return response.statistics;
    } catch (error) {
      console.error('Failed to fetch pump statistics:', error);
      throw error;
    }
  },

  /**
   * Get realtime pump status
   */
  async getRealtimeStatus() {
    try {
      const response = await client.get('/pumps/realtime/status');

      if (response.success) {
        stateManager.set('pumps.list', response.pumps || []);
      }

      return response;
    } catch (error) {
      console.error('Failed to fetch realtime status:', error);
      throw error;
    }
  },

  /**
   * Check if pump is running
   */
  isPumpRunning(pumpId) {
    const pumps = stateManager.get('pumps.list') || [];
    const pump = pumps.find(p => p.id === pumpId);
    return pump?.is_running || false;
  },

  /**
   * Get pump status
   */
  getPumpStatus(pumpId) {
    const pumps = stateManager.get('pumps.list') || [];
    return pumps.find(p => p.id === pumpId);
  },
  async emergencyStop() {
    try {
      const response = await client.post('/pumps/emergency-stop');
      if (response.success) {
        const pumps = stateManager.get('pumps.list');
        const updated = pumps.map(p => ({ ...p, is_running: false }));
        stateManager.set('pumps.list', updated);
      }
      return response;
    } catch (error) {
      console.error('Emergency stop failed:', error);
      throw error;
    }
  }
};

export default pumpsAPI;
