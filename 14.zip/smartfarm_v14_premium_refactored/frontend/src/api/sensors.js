/**
 * Sensors API Module
 * Handles sensor data retrieval, history, and statistics
 */

import client from './client.js';
import stateManager from '../state.js';

export const sensorsAPI = {
  /**
   * Get all sensors
   */
  async getSensors() {
    try {
      stateManager.set('sensors.loading', true);
      const response = await client.get('/sensors');

      if (response.success) {
        stateManager.set('sensors.list', response.sensors || []);
      }

      stateManager.set('sensors.loading', false);
      return response.sensors || [];
    } catch (error) {
      stateManager.set('sensors.error', error.message);
      stateManager.set('sensors.loading', false);
      throw error;
    }
  },

  /**
   * Get sensor by ID
   */
  async getSensor(id) {
    try {
      const response = await client.get(`/sensors/${id}`);
      return response.sensor;
    } catch (error) {
      console.error('Failed to fetch sensor:', error);
      throw error;
    }
  },

  /**
   * Create sensor
   */
  async createSensor(sensorData) {
    try {
      const response = await client.post('/sensors', sensorData);
      
      if (response.success) {
        const sensors = stateManager.get('sensors.list');
        stateManager.set('sensors.list', [...sensors, { id: response.sensorId, ...sensorData }]);
      }

      return response;
    } catch (error) {
      console.error('Failed to create sensor:', error);
      throw error;
    }
  },

  /**
   * Update sensor
   */
  async updateSensor(id, updates) {
    try {
      const response = await client.put(`/sensors/${id}`, updates);

      if (response.success) {
        const sensors = stateManager.get('sensors.list');
        const updated = sensors.map(s => s.id === id ? { ...s, ...updates } : s);
        stateManager.set('sensors.list', updated);
      }

      return response;
    } catch (error) {
      console.error('Failed to update sensor:', error);
      throw error;
    }
  },

  /**
   * Delete sensor
   */
  async deleteSensor(id) {
    try {
      const response = await client.delete(`/sensors/${id}`);

      if (response.success) {
        const sensors = stateManager.get('sensors.list');
        stateManager.set('sensors.list', sensors.filter(s => s.id !== id));
      }

      return response;
    } catch (error) {
      console.error('Failed to delete sensor:', error);
      throw error;
    }
  },

  /**
   * Record sensor data
   */
  async recordData(sensorId, value) {
    try {
      const response = await client.post(`/sensors/${sensorId}/data`, { value });
      return response;
    } catch (error) {
      console.error('Failed to record sensor data:', error);
      throw error;
    }
  },

  /**
   * Get sensor history
   */
  async getHistory(sensorId, options = {}) {
    try {
      const params = new URLSearchParams();
      if (options.startDate) params.append('startDate', options.startDate);
      if (options.endDate) params.append('endDate', options.endDate);
      if (options.limit) params.append('limit', options.limit);

      const response = await client.get(`/sensors/${sensorId}/history?${params}`);
      
      if (response.success) {
        const history = stateManager.get('sensors.history') || {};
        history[sensorId] = response.history;
        stateManager.set('sensors.history', history);
      }

      return response.history || [];
    } catch (error) {
      console.error('Failed to fetch sensor history:', error);
      throw error;
    }
  },

  /**
   * Get sensor statistics
   */
  async getStatistics(sensorId, days = 7) {
    try {
      const response = await client.get(`/sensors/${sensorId}/statistics?days=${days}`);
      return response.statistics;
    } catch (error) {
      console.error('Failed to fetch sensor statistics:', error);
      throw error;
    }
  },

  /**
   * Get realtime sensor status
   */
  async getRealtimeStatus() {
    try {
      const response = await client.get('/sensors/realtime/status');
      
      if (response.success) {
        stateManager.set('sensors.list', response.sensors || []);
      }

      return response;
    } catch (error) {
      console.error('Failed to fetch realtime status:', error);
      throw error;
    }
  },

  /**
   * Get sensor by type
   */
  getSensorsByType(type) {
    const sensors = stateManager.get('sensors.list') || [];
    return sensors.filter(s => s.sensor_type === type);
  },

  /**
   * Get sensor value
   */
  getSensorValue(sensorId) {
    const sensors = stateManager.get('sensors.list') || [];
    const sensor = sensors.find(s => s.id === sensorId);
    return sensor?.last_value;
  }
};

export default sensorsAPI;
