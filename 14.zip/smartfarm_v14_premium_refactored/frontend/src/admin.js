/**
 * SmartFarm V14 Admin Panel Logic
 */

import authAPI from './api/auth.js';
import client from './api/client.js';

class AdminPanel {
  constructor() {
    this.contentArea = document.getElementById('admin-content');
    this.pageTitle = document.getElementById('page-title');
    this.userInfo = document.getElementById('admin-user-info');
  }

  async initialize() {
    if (!authAPI.restoreSession() || authAPI.getUserRole() !== 'admin') {
      window.location.href = '/';
      return;
    }

    this.renderUserInfo();
    this.setupNavigation();
    this.loadDashboard();
  }

  renderUserInfo() {
    const user = authAPI.getCurrentUser();
    this.userInfo.innerHTML = `
      <div style="text-align: right;">
        <div style="font-weight: 600;">${user.full_name || user.username}</div>
        <div style="font-size: 0.75rem; color: var(--accent);">${user.role.toUpperCase()}</div>
      </div>
    `;
  }

  setupNavigation() {
    document.querySelectorAll('.nav-item').forEach(item => {
      item.addEventListener('click', (e) => {
        if (item.getAttribute('href') === '/') return;
        e.preventDefault();
        document.querySelectorAll('.nav-item').forEach(i => i.classList.remove('active'));
        item.classList.add('active');
        
        const route = item.getAttribute('href').substring(1);
        this.navigate(route);
      });
    });
  }

  navigate(route) {
    switch(route) {
      case 'dashboard': this.loadDashboard(); break;
      case 'users': this.loadUsers(); break;
      case 'devices': this.loadDevices(); break;
      case 'logs': this.loadLogs(); break;
      case 'system': this.loadSystem(); break;
      default: this.loadDashboard();
    }
  }

  async loadDashboard() {
    this.pageTitle.textContent = 'Admin Dashboard';
    this.contentArea.innerHTML = '<div class="animate-pulse">กำลังโหลดข้อมูล...</div>';
    
    try {
      const stats = await client.get('/settings/system/info');
      this.contentArea.innerHTML = `
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1.5rem;">
          <div class="card">
            <h4>อุปกรณ์ทั้งหมด</h4>
            <div style="font-size: 2.5rem; font-weight: bold; color: var(--accent);">${stats.system.database.sensor_count + stats.system.database.pump_count}</div>
          </div>
          <div class="card">
            <h4>ผู้ใช้งานระบบ</h4>
            <div style="font-size: 2.5rem; font-weight: bold; color: var(--success);">${stats.system.database.user_count}</div>
          </div>
          <div class="card">
            <h4>รายการ Log</h4>
            <div style="font-size: 2.5rem; font-weight: bold; color: var(--warning);">${stats.system.database.log_count}</div>
          </div>
          <div class="card">
            <h4>Uptime</h4>
            <div style="font-size: 1.5rem; font-weight: bold;">${Math.floor(stats.system.uptime / 3600)} ชั่วโมง</div>
          </div>
        </div>
      `;
    } catch (error) {
      this.contentArea.innerHTML = `<div class="card" style="color: var(--error);">Error: ${error.message}</div>`;
    }
  }

  async loadUsers() {
    this.pageTitle.textContent = 'จัดการผู้ใช้งาน';
    this.contentArea.innerHTML = '<div class="animate-pulse">กำลังโหลดรายชื่อผู้ใช้...</div>';
    // Implementation for user management table
  }

  async loadLogs() {
    this.pageTitle.textContent = 'Audit Logs';
    this.contentArea.innerHTML = '<div class="animate-pulse">กำลังโหลดบันทึกการใช้งาน...</div>';
  }

  async loadSystem() {
    this.pageTitle.textContent = 'System Health';
    this.contentArea.innerHTML = '<div class="animate-pulse">กำลังตรวจสอบระบบ...</div>';
  }
}

document.addEventListener('DOMContentLoaded', () => {
  const admin = new AdminPanel();
  admin.initialize();
});
